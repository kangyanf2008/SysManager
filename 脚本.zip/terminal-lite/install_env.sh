#!/bin/bash

CUR_DIR=$PWD

function load_images() {
    # load docker images
	cd $CUR_DIR/images
    for file in `ls`
    do
        docker load -i $file
    done
}

function start_com_docker(){
    echo "start mysql"
    echo start mysql
    cd $CUR_DIR/docker/mysql
    bash docker.sh restart

    echo start nginx
    cd $CUR_DIR/docker/nginx
    bash docker.sh restart

    echo start redis
    cd $CUR_DIR/docker/redis
    bash docker.sh restart

    echo start mongo
    cd $CUR_DIR/docker/mongo
    bash docker.sh restart

    echo start emqx
    cd $CUR_DIR/docker/emqx
    bash docker.sh restart
	
	echo start terminal-web-tenant
    cd $CUR_DIR/docker/terminal-web-tenant
    bash docker.sh restart
	
	echo start terminal-web-admin
    cd $CUR_DIR/docker/terminal-web-admin
    bash docker.sh restart
}

function init_data(){
	# mongo volume create
	docker volume create --name mongo-single
	cd $CUR_DIR
    sleep 20
    # init mysql
	docker cp sql mysql:/tmp
    winpty docker exec mysql //bin/bash -c "mysql -uroot -pcimevue@1234 < /tmp/sql/terminal_lite.sql"
}


load_images
start_com_docker
init_data
