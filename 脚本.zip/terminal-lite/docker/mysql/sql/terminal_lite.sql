/*
Navicat MySQL Data Transfer

Source Server         : 10.10.1.146
Source Server Version : 50719
Source Host           : 10.10.1.146:3307
Source Database       : terminal_lite

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2020-09-04 13:44:42
*/

DROP DATABASE if EXISTS terminal_lite;
CREATE DATABASE IF NOT EXISTS `terminal_lite` DEFAULT CHARSET utf8 COLLATE utf8_general_ci;
set names utf8;
USE terminal_lite;

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for d_app_access_mode
-- ----------------------------
DROP TABLE IF EXISTS `d_app_access_mode`;
CREATE TABLE `d_app_access_mode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '通行方式名称组合(用&隔开)',
  `dict_ids` varchar(255) NOT NULL DEFAULT '' COMMENT '通行方式id组合(用&隔开)',
  `color` varchar(255) NOT NULL DEFAULT '' COMMENT '颜色',
  `pass_types` varchar(255) NOT NULL DEFAULT '' COMMENT '通行类型组合(多个用&隔开)',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='设备中心-门禁通行模式管理';

-- ----------------------------
-- Records of d_app_access_mode
-- ----------------------------
INSERT INTO `d_app_access_mode` VALUES ('5', '任意方式校验通过即可', '39', '#B7EB8F', '0', '0', '0', '2019-12-20 19:25:57', '0', '2019-12-20 19:25:57', '0');
INSERT INTO `d_app_access_mode` VALUES ('6', '人脸和PIN码双重校验', '40', '#ADC6FF', '1', '0', '0', '2019-12-20 19:26:41', '0', '2019-12-20 19:26:41', '0');
INSERT INTO `d_app_access_mode` VALUES ('7', '人脸和IC卡双重校验', '41', '#FFBB96', '2', '0', '0', '2019-12-20 19:26:54', '0', '2019-12-20 19:26:54', '0');

-- ----------------------------
-- Table structure for d_app_activity
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity`;
CREATE TABLE `d_app_activity` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `seat_temp_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '座位模板ID（外键）',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '底库ID',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '活动名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:会议，2：比赛，3：公共活动',
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '结束时间',
  `activity_unit` varchar(255) NOT NULL DEFAULT '' COMMENT '活动单元',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '活动地址',
  `display_mode` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'app端展现模式(0:标准版，1:座位表，2:九宫格)',
  `sign_photo` varchar(1024) NOT NULL DEFAULT '' COMMENT '打印图片',
  `is_ready` int(4) NOT NULL DEFAULT '0' COMMENT '0  未准备  1已准备',
  `status` int(4) NOT NULL DEFAULT '0' COMMENT '是否开始0未开始，1进行中，2结束',
  `content` varchar(255) NOT NULL DEFAULT '' COMMENT '活动详情',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-活动管理';

-- ----------------------------
-- Records of d_app_activity
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_device
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_device`;
CREATE TABLE `d_app_activity_device` (
  `activity_id` bigint(20) NOT NULL DEFAULT '0',
  `device_id` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of d_app_activity_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_seat
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_seat`;
CREATE TABLE `d_app_activity_seat` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `temp_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '模板ID（外键）',
  `row` int(11) NOT NULL DEFAULT '0' COMMENT '座位行数',
  `col` int(11) NOT NULL DEFAULT '0' COMMENT '座位列数',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '座位状态：0：无座；1：有座；',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-活动座位';

-- ----------------------------
-- Records of d_app_activity_seat
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_seat_subject
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_seat_subject`;
CREATE TABLE `d_app_activity_seat_subject` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `activity_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '活动ID（外键）',
  `feature_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '特征ID（外键）',
  `row` int(11) NOT NULL DEFAULT '0' COMMENT '座位行数',
  `col` int(11) NOT NULL DEFAULT '0' COMMENT '座位列数',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '座位状态：0：无座；1：有座；2：已分配',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-活动座位人';

-- ----------------------------
-- Records of d_app_activity_seat_subject
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_subject
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_subject`;
CREATE TABLE `d_app_activity_subject` (
  `id` bigint(20) NOT NULL,
  `activity_id` bigint(20) NOT NULL,
  `subject_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of d_app_activity_subject
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_subject_rel
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_subject_rel`;
CREATE TABLE `d_app_activity_subject_rel` (
  `id` bigint(20) NOT NULL,
  `activity_id` bigint(20) NOT NULL,
  `subject_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of d_app_activity_subject_rel
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_subject_sign
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_subject_sign`;
CREATE TABLE `d_app_activity_subject_sign` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `activity_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '活动ID（外键）',
  `feature_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '特征ID（外键）',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '签到状态：0：未签到；1：已签到；',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-活动人员签到状态';

-- ----------------------------
-- Records of d_app_activity_subject_sign
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_activity_subject_wait_audit
-- ----------------------------
DROP TABLE IF EXISTS `d_app_activity_subject_wait_audit`;
CREATE TABLE `d_app_activity_subject_wait_audit` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `face_id` bigint(20) NOT NULL DEFAULT '0',
  `th_feature` longblob COMMENT '前端比对特征值',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `photo` varchar(1024) NOT NULL DEFAULT '' COMMENT '照片',
  `sex` tinyint(4) NOT NULL DEFAULT '2' COMMENT '性别（0：女 1：男 2：未知）',
  `phone` varchar(64) NOT NULL DEFAULT '',
  `duty` varchar(255) NOT NULL DEFAULT '' COMMENT '职务',
  `person_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '人员类型（0：员工 1：访客 2 设备上报人员  99黑名单）',
  `open_id` varchar(64) NOT NULL DEFAULT '',
  `system_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '时间戳',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-特征';

-- ----------------------------
-- Records of d_app_activity_subject_wait_audit
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance`;
CREATE TABLE `d_app_attendance` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）',
  `dept_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '机构ID（外键）',
  `day` date NOT NULL DEFAULT '2018-01-01' COMMENT '日',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `first_device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '第一次比对使用设备',
  `first_time` time NOT NULL DEFAULT '00:00:00' COMMENT '首次打卡时间',
  `first_compare_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '首次比对记录',
  `last_device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后一次比对设备id',
  `last_time` time NOT NULL DEFAULT '00:00:00' COMMENT '末次打卡时间',
  `last_compare_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '末次比中记录',
  `is_late` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否迟到（0：否 1：是）',
  `late_minute` int(11) NOT NULL DEFAULT '0' COMMENT '迟到时间',
  `is_early` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否早退（0：否 1：是）',
  `early_minute` int(11) NOT NULL DEFAULT '0' COMMENT '早退时间',
  `is_field_work` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否全勤（0：否 1：是）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤';

-- ----------------------------
-- Records of d_app_attendance
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_device
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_device`;
CREATE TABLE `d_app_attendance_device` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤-设备';

-- ----------------------------
-- Records of d_app_attendance_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_group
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_group`;
CREATE TABLE `d_app_attendance_group` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `number` int(10) NOT NULL DEFAULT '0' COMMENT '人数',
  `type` int(4) NOT NULL DEFAULT '0' COMMENT '类型（未定）',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤组';

-- ----------------------------
-- Records of d_app_attendance_group
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_group_subject
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_group_subject`;
CREATE TABLE `d_app_attendance_group_subject` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '考勤组ID（外键）',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤组-人员';

-- ----------------------------
-- Records of d_app_attendance_group_subject
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_group_time
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_group_time`;
CREATE TABLE `d_app_attendance_group_time` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '考勤组ID（外键）',
  `time_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '班次ID（外键）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤组-班次';

-- ----------------------------
-- Records of d_app_attendance_group_time
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_holiday
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_holiday`;
CREATE TABLE `d_app_attendance_holiday` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `year` int(4) NOT NULL COMMENT '年',
  `month` int(2) NOT NULL COMMENT '月',
  `day` date NOT NULL COMMENT '当前时间',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日历-公司法定节假日';

-- ----------------------------
-- Records of d_app_attendance_holiday
-- ----------------------------
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833269022722', '2020', '4', '2020-04-11', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833277411330', '2020', '4', '2020-04-12', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833277411331', '2020', '4', '2020-04-25', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833281605633', '2020', '4', '2020-04-04', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833281605634', '2020', '4', '2020-04-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833285799938', '2020', '4', '2020-04-06', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833289994241', '2020', '4', '2020-04-18', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833294188546', '2020', '4', '2020-04-19', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833298382850', '2020', '3', '2020-03-22', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833298382851', '2020', '3', '2020-03-01', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833302577153', '2020', '3', '2020-03-14', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833302577154', '2020', '3', '2020-03-15', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833306771458', '2020', '3', '2020-03-28', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833306771459', '2020', '3', '2020-03-07', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833310965761', '2020', '3', '2020-03-29', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833310965762', '2020', '3', '2020-03-08', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833319354370', '2020', '3', '2020-03-21', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833319354371', '2020', '2', '2020-02-22', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833323548673', '2020', '2', '2020-02-23', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833323548674', '2020', '2', '2020-02-02', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833327742977', '2020', '2', '2020-02-15', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833327742978', '2020', '2', '2020-02-16', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833327742979', '2020', '2', '2020-02-29', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833331937281', '2020', '2', '2020-02-08', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833331937282', '2020', '2', '2020-02-09', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833336131585', '2020', '1', '2020-01-11', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833336131586', '2020', '1', '2020-01-01', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833336131587', '2020', '1', '2020-01-12', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833340325889', '2020', '1', '2020-01-24', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833340325890', '2020', '1', '2020-01-25', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833344520194', '2020', '1', '2020-01-04', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833491320833', '2020', '1', '2020-01-26', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903746', '2020', '1', '2020-01-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903747', '2020', '1', '2020-01-27', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903748', '2020', '1', '2020-01-28', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903749', '2020', '1', '2020-01-18', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903750', '2020', '1', '2020-01-29', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903751', '2020', '1', '2020-01-30', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903752', '2020', '12', '2020-12-12', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903753', '2020', '12', '2020-12-13', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903754', '2020', '12', '2020-12-26', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903755', '2020', '12', '2020-12-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903756', '2020', '12', '2020-12-27', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903757', '2020', '12', '2020-12-06', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833503903758', '2020', '12', '2020-12-19', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833537458177', '2020', '12', '2020-12-20', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833537458178', '2020', '11', '2020-11-22', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833537458179', '2020', '11', '2020-11-01', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833537458180', '2020', '11', '2020-11-14', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833541652482', '2020', '11', '2020-11-15', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833541652483', '2020', '11', '2020-11-28', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833545846786', '2020', '11', '2020-11-07', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833545846787', '2020', '11', '2020-11-29', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833550041089', '2020', '11', '2020-11-08', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833550041090', '2020', '11', '2020-11-21', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833554235393', '2020', '10', '2020-10-11', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833554235394', '2020', '10', '2020-10-01', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833558429697', '2020', '10', '2020-10-02', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833558429698', '2020', '10', '2020-10-24', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833562624001', '2020', '10', '2020-10-03', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833566818305', '2020', '10', '2020-10-25', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833680064514', '2020', '10', '2020-10-04', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833684258818', '2020', '10', '2020-10-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833688453122', '2020', '10', '2020-10-06', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833692647425', '2020', '10', '2020-10-17', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833692647426', '2020', '10', '2020-10-07', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833696841729', '2020', '10', '2020-10-18', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833701036033', '2020', '10', '2020-10-08', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833701036034', '2020', '10', '2020-10-31', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833705230337', '2020', '9', '2020-09-12', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833705230338', '2020', '9', '2020-09-13', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833709424642', '2020', '9', '2020-09-26', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833709424643', '2020', '9', '2020-09-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833709424644', '2020', '9', '2020-09-06', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833713618945', '2020', '9', '2020-09-19', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833713618946', '2020', '9', '2020-09-20', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833717813249', '2020', '8', '2020-08-22', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833717813250', '2020', '8', '2020-08-01', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833722007554', '2020', '8', '2020-08-23', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833722007555', '2020', '8', '2020-08-02', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833726201857', '2020', '8', '2020-08-15', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833730396161', '2020', '8', '2020-08-16', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833730396162', '2020', '8', '2020-08-29', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833734590465', '2020', '8', '2020-08-08', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833734590466', '2020', '8', '2020-08-09', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833738784770', '2020', '8', '2020-08-30', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833738784771', '2020', '7', '2020-07-11', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833742979074', '2020', '7', '2020-07-12', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833742979075', '2020', '7', '2020-07-25', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833747173377', '2020', '7', '2020-07-04', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833747173378', '2020', '7', '2020-07-26', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833847836673', '2020', '7', '2020-07-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833852030977', '2020', '7', '2020-07-18', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833856225282', '2020', '7', '2020-07-19', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833856225283', '2020', '6', '2020-06-13', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833860419585', '2020', '6', '2020-06-14', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833864613890', '2020', '6', '2020-06-25', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833868808194', '2020', '6', '2020-06-26', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833868808195', '2020', '6', '2020-06-27', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833873002497', '2020', '6', '2020-06-06', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833873002498', '2020', '6', '2020-06-07', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833877196801', '2020', '6', '2020-06-20', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833881391106', '2020', '6', '2020-06-21', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833881391107', '2020', '5', '2020-05-01', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833885585410', '2020', '5', '2020-05-23', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833885585411', '2020', '5', '2020-05-02', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833889779714', '2020', '5', '2020-05-24', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833889779715', '2020', '5', '2020-05-03', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833893974018', '2020', '5', '2020-05-04', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833893974019', '2020', '5', '2020-05-05', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833893974020', '2020', '5', '2020-05-16', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833898168321', '2020', '5', '2020-05-17', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833898168322', '2020', '5', '2020-05-30', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833902362626', '2020', '5', '2020-05-31', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');
INSERT INTO `d_app_attendance_holiday` VALUES ('1217716833902362627', '2020', '5', '2020-05-10', '0', '2020-01-16 15:54:51', '0', '2020-01-16 15:54:51', '0');

-- ----------------------------
-- Table structure for d_app_attendance_holiday_private
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_holiday_private`;
CREATE TABLE `d_app_attendance_holiday_private` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `year` int(4) NOT NULL COMMENT '年',
  `month` int(2) NOT NULL COMMENT '月',
  `day` date NOT NULL COMMENT '当前时间',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日历-公司节假日';

-- ----------------------------
-- Records of d_app_attendance_holiday_private
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_not_on_subject
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_not_on_subject`;
CREATE TABLE `d_app_attendance_not_on_subject` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工id',
  `start_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '离岗时间',
  `end_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '归岗时间',
  `reason` varchar(512) NOT NULL DEFAULT '0' COMMENT '不在岗原因',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤-不在岗人员';

-- ----------------------------
-- Records of d_app_attendance_not_on_subject
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_outside
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_outside`;
CREATE TABLE `d_app_attendance_outside` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）',
  `day` date NOT NULL DEFAULT '2018-01-01' COMMENT '日',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `time` time NOT NULL DEFAULT '00:00:00' COMMENT '首次打卡时间',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '地址',
  `photo` varchar(256) NOT NULL DEFAULT '' COMMENT '图片',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-外勤记录';

-- ----------------------------
-- Records of d_app_attendance_outside
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_repair
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_repair`;
CREATE TABLE `d_app_attendance_repair` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）',
  `attendance_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '考勤记录id',
  `repair_time` datetime DEFAULT NULL COMMENT '补卡时间',
  `reason` varchar(256) NOT NULL DEFAULT '' COMMENT '原因',
  `repair_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '补卡类型  1 迟到补卡  2 下班补卡  3 当天缺卡',
  `repair_photo` varchar(256) NOT NULL DEFAULT '' COMMENT '图片',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 未审核  1 通过  2 未通过',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤补卡';

-- ----------------------------
-- Records of d_app_attendance_repair
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_repair_audit
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_repair_audit`;
CREATE TABLE `d_app_attendance_repair_audit` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `audit_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '审核人员ID',
  `copy_for_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '抄送人员ID',
  `count` int(11) NOT NULL DEFAULT '0' COMMENT '补卡次数',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-审核抄送';

-- ----------------------------
-- Records of d_app_attendance_repair_audit
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_attendance_time
-- ----------------------------
DROP TABLE IF EXISTS `d_app_attendance_time`;
CREATE TABLE `d_app_attendance_time` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `first_time` time NOT NULL DEFAULT '00:00:00' COMMENT '上班时间',
  `last_time` time NOT NULL DEFAULT '00:00:00' COMMENT '下班时间',
  `deadline` time NOT NULL,
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤时间设置';

-- ----------------------------
-- Records of d_app_attendance_time
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `d_app_auth_group`;
CREATE TABLE `d_app_auth_group` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:员工组  2：访客组',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-门禁授权组';

-- ----------------------------
-- Records of d_app_auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_background
-- ----------------------------
DROP TABLE IF EXISTS `d_app_background`;
CREATE TABLE `d_app_background` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `screen_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '预览ID（外键）',
  `uri` varchar(1024) NOT NULL DEFAULT '' COMMENT 'uri地址',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-预览背景';

-- ----------------------------
-- Records of d_app_background
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `d_app_blacklist`;
CREATE TABLE `d_app_blacklist` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `th_feature` longblob NOT NULL COMMENT '前端比对特征值',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `photo` varchar(64) NOT NULL DEFAULT '' COMMENT '照片',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-黑名单';

-- ----------------------------
-- Records of d_app_blacklist
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_blacklist_group
-- ----------------------------
DROP TABLE IF EXISTS `d_app_blacklist_group`;
CREATE TABLE `d_app_blacklist_group` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-黑名单组';

-- ----------------------------
-- Records of d_app_blacklist_group
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_blacklist_group_device
-- ----------------------------
DROP TABLE IF EXISTS `d_app_blacklist_group_device`;
CREATE TABLE `d_app_blacklist_group_device` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '黑名单组ID（外键）',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `update_time` bigint(20) NOT NULL DEFAULT '1546272001000' COMMENT '更新时间',
  `is_del` bigint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-黑名单组-设备';

-- ----------------------------
-- Records of d_app_blacklist_group_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_demand
-- ----------------------------
DROP TABLE IF EXISTS `d_app_demand`;
CREATE TABLE `d_app_demand` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '标题',
  `no` varchar(64) DEFAULT '' COMMENT '需求单号',
  `level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 低 2 中 3 高',
  `content` varchar(1024) NOT NULL DEFAULT '' COMMENT '描述',
  `product` varchar(512) DEFAULT '' COMMENT '相关产品',
  `photo` varchar(512) NOT NULL DEFAULT '' COMMENT '图片',
  `anonymous` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否匿名 1 是 0否',
  `status` tinyint(4) NOT NULL DEFAULT '6' COMMENT '状态 1 草稿 2 暂不处理 3 处理中 4 已撤销 5 已处理 6 未处理 7已打回',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-需求单表';

-- ----------------------------
-- Records of d_app_demand
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_demand_draft
-- ----------------------------
DROP TABLE IF EXISTS `d_app_demand_draft`;
CREATE TABLE `d_app_demand_draft` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `employee_id` bigint(20) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '标题',
  `level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 低 2 中 3 高',
  `content` varchar(1024) NOT NULL DEFAULT '' COMMENT '描述',
  `product` varchar(512) DEFAULT '' COMMENT '相关产品',
  `photo` varchar(512) NOT NULL DEFAULT '' COMMENT '图片',
  `anonymous` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否匿名 1 是 0否',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-需求单表';

-- ----------------------------
-- Records of d_app_demand_draft
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_demand_result
-- ----------------------------
DROP TABLE IF EXISTS `d_app_demand_result`;
CREATE TABLE `d_app_demand_result` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `demand_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '需求单ID',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '受理者',
  `result` varchar(1024) NOT NULL DEFAULT '' COMMENT '结果描述',
  `photo` varchar(512) NOT NULL DEFAULT '' COMMENT '图片',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态 1 草稿 2 暂不处理 3 处理中 4 已撤销 5 已处理 6 未处理 7已打回',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-需求单处理结果';

-- ----------------------------
-- Records of d_app_demand_result
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_doorguard_picture
-- ----------------------------
DROP TABLE IF EXISTS `d_app_doorguard_picture`;
CREATE TABLE `d_app_doorguard_picture` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'id',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `picture` varchar(64) NOT NULL DEFAULT '' COMMENT '图片md5',
  `video` varchar(512) NOT NULL DEFAULT '' COMMENT '视频路径',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '屏保类型 0 系统默认  1用户自定义 2-推荐屏保',
  `media_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '媒体类型 0-图片 1-视频',
  `author` varchar(64) NOT NULL DEFAULT '' COMMENT '作者',
  `classification` bigint(20) NOT NULL DEFAULT '0' COMMENT '屏保分类id',
  `remarks` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-APP-门禁屏保图片';

-- ----------------------------
-- Records of d_app_doorguard_picture
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_doorguard_screen
-- ----------------------------
DROP TABLE IF EXISTS `d_app_doorguard_screen`;
CREATE TABLE `d_app_doorguard_screen` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'id',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '屏保名称',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '屏保类型 0 系统默认  1用户自定义 ',
  `video` bigint(20) NOT NULL DEFAULT '0' COMMENT '视频id',
  `picture` varchar(1024) NOT NULL DEFAULT '' COMMENT '图片md5数组集合',
  `screen_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '屏保类型  （0-静态 1-动态）',
  `start_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '屏保开启时间',
  `end_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '屏保关闭时间',
  `attribute` tinyint(3) NOT NULL DEFAULT '0' COMMENT '属性（0-默认屏保 1-时段屏保 ）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-APP-门禁屏保';

-- ----------------------------
-- Records of d_app_doorguard_screen
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_group_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `d_app_group_blacklist`;
CREATE TABLE `d_app_group_blacklist` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '黑名单组ID（外键）',
  `blacklist_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '黑名单人员ID（外键）',
  `update_time` bigint(20) NOT NULL DEFAULT '1546272001000' COMMENT '更新时间',
  `is_del` bigint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-黑名单组-黑名单人员';

-- ----------------------------
-- Records of d_app_group_blacklist
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_group_device
-- ----------------------------
DROP TABLE IF EXISTS `d_app_group_device`;
CREATE TABLE `d_app_group_device` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '授权组ID（外键）',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `update_time` bigint(20) NOT NULL DEFAULT '1546272001000' COMMENT '更新时间',
  `is_del` bigint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-开关组-锁';

-- ----------------------------
-- Records of d_app_group_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_group_employee
-- ----------------------------
DROP TABLE IF EXISTS `d_app_group_employee`;
CREATE TABLE `d_app_group_employee` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '授权组ID（外键）',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）',
  `update_time` bigint(20) NOT NULL DEFAULT '1546272001000' COMMENT '更新时间',
  `is_del` bigint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-开关组-人员';

-- ----------------------------
-- Records of d_app_group_employee
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_group_theme
-- ----------------------------
DROP TABLE IF EXISTS `d_app_group_theme`;
CREATE TABLE `d_app_group_theme` (
  `theme_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '主题id',
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '授权组id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-授权组组-主题';

-- ----------------------------
-- Records of d_app_group_theme
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_group_visitor
-- ----------------------------
DROP TABLE IF EXISTS `d_app_group_visitor`;
CREATE TABLE `d_app_group_visitor` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '授权组ID（外键）',
  `visitor_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '访客ID（外键）',
  `update_time` bigint(20) NOT NULL DEFAULT '1546272001000' COMMENT '更新时间',
  `is_del` bigint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-开关组-访客';

-- ----------------------------
-- Records of d_app_group_visitor
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_member_device
-- ----------------------------
DROP TABLE IF EXISTS `d_app_member_device`;
CREATE TABLE `d_app_member_device` (
  `member_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '人员id',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备id',
  `update_time` bigint(20) NOT NULL DEFAULT '1546272001000' COMMENT '更新时间',
  `is_del` bigint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='人员设备表（设备上报人员）';

-- ----------------------------
-- Records of d_app_member_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_product
-- ----------------------------
DROP TABLE IF EXISTS `d_app_product`;
CREATE TABLE `d_app_product` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `category_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '类别ID',
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '名称',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-需求单表';

-- ----------------------------
-- Records of d_app_product
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_product_category
-- ----------------------------
DROP TABLE IF EXISTS `d_app_product_category`;
CREATE TABLE `d_app_product_category` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '名称',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-产品类别';

-- ----------------------------
-- Records of d_app_product_category
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_scheme
-- ----------------------------
DROP TABLE IF EXISTS `d_app_scheme`;
CREATE TABLE `d_app_scheme` (
  `id` bigint(20) NOT NULL COMMENT '模板id',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '模板名称',
  `text_content` varchar(8) NOT NULL DEFAULT '' COMMENT '文字内容',
  `text_position` tinyint(4) NOT NULL DEFAULT '0' COMMENT '显示位置（0：下面（卡片中）；1：上面（锁图片下面））',
  `card_color` varchar(64) NOT NULL DEFAULT '' COMMENT '卡片颜色',
  `is_push_tips` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否推送提示（0：不推送；1：推送）',
  `voice_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '语音id',
  `is_push_voice` tinyint(4) NOT NULL COMMENT '是否推送语音（0：不推送；1：推送）',
  `warm_heart_tips` varchar(512) NOT NULL DEFAULT '' COMMENT '暖心提示',
  `is_push_warm_heart` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否推送暖心提示（0：不推送；1：推送）',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '方案类型(0-系统方案，1-自定义方案)',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `id_del` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备中心-门禁方案管理';

-- ----------------------------
-- Records of d_app_scheme
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_screen
-- ----------------------------
DROP TABLE IF EXISTS `d_app_screen`;
CREATE TABLE `d_app_screen` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `animation` varchar(64) NOT NULL DEFAULT '0' COMMENT '动画',
  `duration` int(11) NOT NULL DEFAULT '0' COMMENT '持续时长',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  `type` tinyint(4) NOT NULL COMMENT 'screen类型(0: 模板 1:自定义)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-预览';

-- ----------------------------
-- Records of d_app_screen
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_screen_widget
-- ----------------------------
DROP TABLE IF EXISTS `d_app_screen_widget`;
CREATE TABLE `d_app_screen_widget` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `screen_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '预览ID（外键）',
  `widget_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '组件ID（外键）',
  `x` float NOT NULL DEFAULT '0' COMMENT 'x',
  `y` float NOT NULL DEFAULT '0' COMMENT 'y',
  `width` float NOT NULL DEFAULT '0' COMMENT 'width',
  `height` float NOT NULL DEFAULT '0' COMMENT 'height',
  `z_index` int(11) NOT NULL DEFAULT '0' COMMENT 'z_index',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-预览-组件';

-- ----------------------------
-- Records of d_app_screen_widget
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_seat_temp
-- ----------------------------
DROP TABLE IF EXISTS `d_app_seat_temp`;
CREATE TABLE `d_app_seat_temp` (
  `id` bigint(20) NOT NULL COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '模板名称',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '总座位数',
  `row` int(11) NOT NULL DEFAULT '0' COMMENT '座位行数',
  `col` int(11) NOT NULL DEFAULT '0' COMMENT '座位列数',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '标题',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-座位模板管理';

-- ----------------------------
-- Records of d_app_seat_temp
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_sms_code
-- ----------------------------
DROP TABLE IF EXISTS `d_app_sms_code`;
CREATE TABLE `d_app_sms_code` (
  `phone` varchar(64) NOT NULL DEFAULT '' COMMENT '手机号',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '验证码',
  `update_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '验证码发送时间',
  PRIMARY KEY (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-短信验证码';

-- ----------------------------
-- Records of d_app_sms_code
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_theme
-- ----------------------------
DROP TABLE IF EXISTS `d_app_theme`;
CREATE TABLE `d_app_theme` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT '主题id',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '发起人成员id',
  `company_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '公司id',
  `theme` varchar(64) NOT NULL DEFAULT '' COMMENT '主题',
  `cause_id` int(11) NOT NULL DEFAULT '0' COMMENT '来访事由',
  `address_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '接待地点id',
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '开始时间',
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '结束时间',
  `image` varchar(1024) NOT NULL DEFAULT '' COMMENT '图片',
  `qr_code` varchar(1024) NOT NULL DEFAULT '' COMMENT '二维码',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户id',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '跟新时间',
  `revoke_remark` varchar(1024) NOT NULL DEFAULT '' COMMENT '撤回理由',
  `is_revoke` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否撤销（0-否 1-是）',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-邀请主题';

-- ----------------------------
-- Records of d_app_theme
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_tourist
-- ----------------------------
DROP TABLE IF EXISTS `d_app_tourist`;
CREATE TABLE `d_app_tourist` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT '访客id',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '游客名字',
  `phone` varchar(64) NOT NULL DEFAULT '' COMMENT '手机',
  `photo` varchar(1024) NOT NULL DEFAULT '' COMMENT '图片',
  `open_id` varchar(64) NOT NULL DEFAULT '' COMMENT '通行管理的openId',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-游客管理';

-- ----------------------------
-- Records of d_app_tourist
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_visitor
-- ----------------------------
DROP TABLE IF EXISTS `d_app_visitor`;
CREATE TABLE `d_app_visitor` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `visit_number` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '到访单号',
  `feature_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '特征ID（外键）',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '访客类型（0：普通访客 1：VIP访客）',
  `verification_mode` int(2) DEFAULT '0' COMMENT '0:无证，1:有证，2：人工',
  `dept_id` bigint(20) DEFAULT '0' COMMENT '接待部门ID（外键）',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '接待人ID（外键）',
  `number_of_visitors` int(4) DEFAULT NULL COMMENT '到访人数',
  `estimated_duration` int(4) DEFAULT NULL COMMENT '预计时长',
  `purpose` varchar(512) NOT NULL DEFAULT '' COMMENT '来访目的',
  `visitor_unit` varchar(100) DEFAULT '' COMMENT '访客单位',
  `bring_in_items` varchar(100) DEFAULT '' COMMENT '代入物品',
  `car_number` varchar(100) DEFAULT '' COMMENT '车牌号',
  `take_out_articles` varchar(100) DEFAULT '' COMMENT '带出物品',
  `status` int(2) DEFAULT '0',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `over_time` datetime NOT NULL COMMENT '结束时间',
  `leave_time` datetime DEFAULT NULL COMMENT '离开时间',
  `sn` varchar(64) DEFAULT '' COMMENT '登记设备号',
  `sn2` varchar(64) DEFAULT '' COMMENT '离访设备号',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `purpose_id` varchar(64) DEFAULT '' COMMENT '到访事由id',
  `visitor_status` tinyint(4) DEFAULT '0' COMMENT '访问状态(0-待处理1-待访问2-已到达3-已离开4-已撤销)',
  `qr_code` varchar(1024) NOT NULL DEFAULT '' COMMENT '二维码',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  `IC_card` varchar(64) DEFAULT '',
  PRIMARY KEY (`visit_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-访客管理';

-- ----------------------------
-- Records of d_app_visitor
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_visitor_apply
-- ----------------------------
DROP TABLE IF EXISTS `d_app_visitor_apply`;
CREATE TABLE `d_app_visitor_apply` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '姓名',
  `th_feature` longblob COMMENT '特征值',
  `phone` varchar(64) NOT NULL DEFAULT '' COMMENT '手机',
  `purpose` varchar(256) NOT NULL DEFAULT '' COMMENT '目的',
  `dept_name` varchar(64) NOT NULL DEFAULT '' COMMENT '拜访部门',
  `employee_name` varchar(64) NOT NULL DEFAULT '' COMMENT '拜访人员',
  `photo` varchar(64) NOT NULL DEFAULT '' COMMENT '照片',
  `start_time` datetime DEFAULT NULL,
  `over_time` datetime DEFAULT NULL,
  `open_id` varchar(64) NOT NULL DEFAULT '' COMMENT '申请人的openId',
  `invitation_open_id` varchar(64) NOT NULL DEFAULT '' COMMENT '邀请者openId',
  `status` int(4) NOT NULL DEFAULT '0' COMMENT '访问申请状态(0-待处理1-待访问2-已到达3-已离开4-已撤销)',
  `unfinished` int(4) NOT NULL DEFAULT '1' COMMENT '1 已完成  0 未完成',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '成员id',
  `qr_code` varchar(1024) NOT NULL DEFAULT '' COMMENT '二维码',
  `time_type` tinyint(4) DEFAULT '0' COMMENT '预约时间类型默认本周',
  `source` tinyint(4) NOT NULL DEFAULT '0' COMMENT '邀请来源（0-短信1-二维码）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `revoke_remark` varchar(1024) NOT NULL DEFAULT '' COMMENT '拒绝理由',
  `remark` varchar(1024) DEFAULT '' COMMENT '备注',
  `visitor_id` bigint(20) DEFAULT '0' COMMENT '访客id',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-访客申请';

-- ----------------------------
-- Records of d_app_visitor_apply
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_visitor_apply_theme
-- ----------------------------
DROP TABLE IF EXISTS `d_app_visitor_apply_theme`;
CREATE TABLE `d_app_visitor_apply_theme` (
  `theme_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '邀请主题id',
  `visitor_apply_id` bigint(20) DEFAULT '0' COMMENT '拜访申请id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='访客申请-会议邀请';

-- ----------------------------
-- Records of d_app_visitor_apply_theme
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_visitor_device
-- ----------------------------
DROP TABLE IF EXISTS `d_app_visitor_device`;
CREATE TABLE `d_app_visitor_device` (
  `visitor_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '访客ID（外键）',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-访客-关联设备';

-- ----------------------------
-- Records of d_app_visitor_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_voice
-- ----------------------------
DROP TABLE IF EXISTS `d_app_voice`;
CREATE TABLE `d_app_voice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `content` varchar(512) NOT NULL DEFAULT '' COMMENT '语音内容',
  `url` varchar(1024) NOT NULL DEFAULT '' COMMENT '语音存储地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备中心-语音录入表';

-- ----------------------------
-- Records of d_app_voice
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_widget
-- ----------------------------
DROP TABLE IF EXISTS `d_app_widget`;
CREATE TABLE `d_app_widget` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '类型',
  `param1` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param2` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param3` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param4` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param5` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param6` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param7` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param8` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-组件';

-- ----------------------------
-- Records of d_app_widget
-- ----------------------------

-- ----------------------------
-- Table structure for d_app_wx_form_id
-- ----------------------------
DROP TABLE IF EXISTS `d_app_wx_form_id`;
CREATE TABLE `d_app_wx_form_id` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `app_id` varchar(64) NOT NULL DEFAULT '' COMMENT 'appid',
  `open_id` varchar(64) NOT NULL DEFAULT '',
  `form_id` varchar(64) NOT NULL DEFAULT '' COMMENT 'formId',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-需求单表';

-- ----------------------------
-- Records of d_app_wx_form_id
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_app
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_app`;
CREATE TABLE `d_sys_app` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'APP类型',
  `version` double(20,0) NOT NULL DEFAULT '0' COMMENT '版本',
  `version_name` varchar(255) NOT NULL COMMENT 'versionName',
  `package_name` varchar(255) NOT NULL DEFAULT '' COMMENT '包名',
  `icon` varchar(1024) NOT NULL COMMENT 'APP图片',
  `summary` varchar(1024) NOT NULL DEFAULT '' COMMENT '简介',
  `min_sdk_version` varchar(64) NOT NULL DEFAULT '' COMMENT 'min_sdk_version',
  `target_sdk_version` varchar(64) NOT NULL DEFAULT '' COMMENT 'target_sdk_version',
  `uses_permissions` varchar(2048) NOT NULL DEFAULT '' COMMENT '依赖权限',
  `url` varchar(1024) NOT NULL DEFAULT '' COMMENT '下载路径',
  `skip` int(4) NOT NULL DEFAULT '0' COMMENT '版本是否可以跳过 0 不可以  1可以',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公共管理-APP';

-- ----------------------------
-- Records of d_sys_app
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_app_view
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_app_view`;
CREATE TABLE `d_sys_app_view` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'UUID主键',
  `device_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '设备类型',
  `app_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'App ID（外键）',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `version` varchar(64) NOT NULL DEFAULT '' COMMENT '版本',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '标题',
  `logo` varchar(1024) NOT NULL DEFAULT '' COMMENT 'logo',
  `param1` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param2` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param3` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param4` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `param5` varchar(1024) NOT NULL DEFAULT '' COMMENT '其他参数',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公共管理-APP-默认界面';

-- ----------------------------
-- Records of d_sys_app_view
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_area
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_area`;
CREATE TABLE `d_sys_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父节点',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `code` char(6) NOT NULL DEFAULT '' COMMENT '城市编码',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3223 DEFAULT CHARSET=utf8 COMMENT='公共管理-区域';

-- ----------------------------
-- Records of d_sys_area
-- ----------------------------
INSERT INTO `d_sys_area` VALUES ('1', '0', '北京市', '110000', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('2', '1', '东城区', '110101', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('3', '1', '西城区', '110102', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('4', '1', '朝阳区', '110105', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('5', '1', '丰台区', '110106', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('6', '1', '石景山区', '110107', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('7', '1', '海淀区', '110108', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('8', '1', '门头沟区', '110109', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('9', '1', '房山区', '110111', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('10', '1', '通州区', '110112', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('11', '1', '顺义区', '110113', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('12', '1', '昌平区', '110114', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('13', '1', '大兴区', '110115', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('14', '1', '怀柔区', '110116', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('15', '1', '平谷区', '110117', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('16', '1', '密云区', '110118', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('17', '1', '延庆区', '110119', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('18', '0', '天津市', '120000', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('19', '18', '和平区', '120101', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('20', '18', '河东区', '120102', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('21', '18', '河西区', '120103', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('22', '18', '南开区', '120104', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('23', '18', '河北区', '120105', '0', '2018-10-30 16:29:06', '0', '2018-10-30 16:29:06', '0');
INSERT INTO `d_sys_area` VALUES ('24', '18', '红桥区', '120106', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('25', '18', '东丽区', '120110', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('26', '18', '西青区', '120111', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('27', '18', '津南区', '120112', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('28', '18', '北辰区', '120113', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('29', '18', '武清区', '120114', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('30', '18', '宝坻区', '120115', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('31', '18', '滨海新区', '120116', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('32', '18', '宁河区', '120117', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('33', '18', '静海区', '120118', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('34', '18', '蓟州区', '120119', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('35', '0', '河北省', '130000', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('36', '35', '石家庄市', '130100', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('37', '36', '长安区', '130102', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('38', '36', '桥西区', '130104', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('39', '36', '新华区', '130105', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('40', '36', '井陉矿区', '130107', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('41', '36', '裕华区', '130108', '0', '2018-10-30 16:29:07', '0', '2018-10-30 16:29:07', '0');
INSERT INTO `d_sys_area` VALUES ('42', '36', '藁城区', '130109', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('43', '36', '鹿泉区', '130110', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('44', '36', '栾城区', '130111', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('45', '36', '井陉县', '130121', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('46', '36', '正定县', '130123', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('47', '36', '行唐县', '130125', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('48', '36', '灵寿县', '130126', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('49', '36', '高邑县', '130127', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('50', '36', '深泽县', '130128', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('51', '36', '赞皇县', '130129', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('52', '36', '无极县', '130130', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('53', '36', '平山县', '130131', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('54', '36', '元氏县', '130132', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('55', '36', '赵县', '130133', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('56', '36', '晋州市', '130183', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('57', '36', '新乐市', '130184', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('58', '35', '唐山市', '130200', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('59', '58', '路南区', '130202', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('60', '58', '路北区', '130203', '0', '2018-10-30 16:29:08', '0', '2018-10-30 16:29:08', '0');
INSERT INTO `d_sys_area` VALUES ('61', '58', '古冶区', '130204', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('62', '58', '开平区', '130205', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('63', '58', '丰南区', '130207', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('64', '58', '丰润区', '130208', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('65', '58', '曹妃甸区', '130209', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('66', '58', '滦县', '130223', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('67', '58', '滦南县', '130224', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('68', '58', '乐亭县', '130225', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('69', '58', '迁西县', '130227', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('70', '58', '玉田县', '130229', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('71', '58', '遵化市', '130281', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('72', '58', '迁安市', '130283', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('73', '35', '秦皇岛市', '130300', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('74', '73', '海港区', '130302', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('75', '73', '山海关区', '130303', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('76', '73', '北戴河区', '130304', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('77', '73', '抚宁区', '130306', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('78', '73', '青龙满族自治县', '130321', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('79', '73', '昌黎县', '130322', '0', '2018-10-30 16:29:09', '0', '2018-10-30 16:29:09', '0');
INSERT INTO `d_sys_area` VALUES ('80', '73', '卢龙县', '130324', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('81', '35', '邯郸市', '130400', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('82', '81', '邯山区', '130402', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('83', '81', '丛台区', '130403', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('84', '81', '复兴区', '130404', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('85', '81', '峰峰矿区', '130406', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('86', '81', '邯郸县', '130421', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('87', '81', '临漳县', '130423', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('88', '81', '成安县', '130424', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('89', '81', '大名县', '130425', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('90', '81', '涉县', '130426', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('91', '81', '磁县', '130427', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('92', '81', '肥乡县', '130428', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('93', '81', '永年县', '130429', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('94', '81', '邱县', '130430', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('95', '81', '鸡泽县', '130431', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('96', '81', '广平县', '130432', '0', '2018-10-30 16:29:10', '0', '2018-10-30 16:29:10', '0');
INSERT INTO `d_sys_area` VALUES ('97', '81', '馆陶县', '130433', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('98', '81', '魏县', '130434', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('99', '81', '曲周县', '130435', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('100', '81', '武安市', '130481', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('101', '35', '邢台市', '130500', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('102', '101', '桥东区', '130502', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('103', '101', '桥西区', '130503', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('104', '101', '邢台县', '130521', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('105', '101', '临城县', '130522', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('106', '101', '内丘县', '130523', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('107', '101', '柏乡县', '130524', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('108', '101', '隆尧县', '130525', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('109', '101', '任县', '130526', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('110', '101', '南和县', '130527', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('111', '101', '宁晋县', '130528', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('112', '101', '巨鹿县', '130529', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('113', '101', '新河县', '130530', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('114', '101', '广宗县', '130531', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('115', '101', '平乡县', '130532', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('116', '101', '威县', '130533', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('117', '101', '清河县', '130534', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('118', '101', '临西县', '130535', '0', '2018-10-30 16:29:11', '0', '2018-10-30 16:29:11', '0');
INSERT INTO `d_sys_area` VALUES ('119', '101', '南宫市', '130581', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('120', '101', '沙河市', '130582', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('121', '35', '保定市', '130600', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('122', '121', '竞秀区', '130602', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('123', '121', '莲池区', '130606', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('124', '121', '满城区', '130607', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('125', '121', '清苑区', '130608', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('126', '121', '徐水区', '130609', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('127', '121', '涞水县', '130623', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('128', '121', '阜平县', '130624', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('129', '121', '定兴县', '130626', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('130', '121', '唐县', '130627', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('131', '121', '高阳县', '130628', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('132', '121', '容城县', '130629', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('133', '121', '涞源县', '130630', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('134', '121', '望都县', '130631', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('135', '121', '安新县', '130632', '0', '2018-10-30 16:29:12', '0', '2018-10-30 16:29:12', '0');
INSERT INTO `d_sys_area` VALUES ('136', '121', '易县', '130633', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('137', '121', '曲阳县', '130634', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('138', '121', '蠡县', '130635', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('139', '121', '顺平县', '130636', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('140', '121', '博野县', '130637', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('141', '121', '雄县', '130638', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('142', '121', '涿州市', '130681', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('143', '121', '安国市', '130683', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('144', '121', '高碑店市', '130684', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('145', '35', '张家口市', '130700', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('146', '145', '桥东区', '130702', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('147', '145', '桥西区', '130703', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('148', '145', '宣化区', '130705', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('149', '145', '下花园区', '130706', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('150', '145', '万全区', '130708', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('151', '145', '崇礼区', '130709', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('152', '145', '张北县', '130722', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('153', '145', '康保县', '130723', '0', '2018-10-30 16:29:13', '0', '2018-10-30 16:29:13', '0');
INSERT INTO `d_sys_area` VALUES ('154', '145', '沽源县', '130724', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('155', '145', '尚义县', '130725', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('156', '145', '蔚县', '130726', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('157', '145', '阳原县', '130727', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('158', '145', '怀安县', '130728', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('159', '145', '怀来县', '130730', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('160', '145', '涿鹿县', '130731', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('161', '145', '赤城县', '130732', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('162', '35', '承德市', '130800', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('163', '162', '双桥区', '130802', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('164', '162', '双滦区', '130803', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('165', '162', '鹰手营子矿区', '130804', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('166', '162', '承德县', '130821', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('167', '162', '兴隆县', '130822', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('168', '162', '平泉县', '130823', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('169', '162', '滦平县', '130824', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('170', '162', '隆化县', '130825', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('171', '162', '丰宁满族自治县', '130826', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('172', '162', '宽城满族自治县', '130827', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('173', '162', '围场满族蒙古族自治县', '130828', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('174', '35', '沧州市', '130900', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('175', '174', '新华区', '130902', '0', '2018-10-30 16:29:14', '0', '2018-10-30 16:29:14', '0');
INSERT INTO `d_sys_area` VALUES ('176', '174', '运河区', '130903', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('177', '174', '沧县', '130921', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('178', '174', '青县', '130922', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('179', '174', '东光县', '130923', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('180', '174', '海兴县', '130924', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('181', '174', '盐山县', '130925', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('182', '174', '肃宁县', '130926', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('183', '174', '南皮县', '130927', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('184', '174', '吴桥县', '130928', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('185', '174', '献县', '130929', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('186', '174', '孟村回族自治县', '130930', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('187', '174', '泊头市', '130981', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('188', '174', '任丘市', '130982', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('189', '174', '黄骅市', '130983', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('190', '174', '河间市', '130984', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('191', '35', '廊坊市', '131000', '0', '2018-10-30 16:29:15', '0', '2018-10-30 16:29:15', '0');
INSERT INTO `d_sys_area` VALUES ('192', '191', '安次区', '131002', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('193', '191', '广阳区', '131003', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('194', '191', '固安县', '131022', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('195', '191', '永清县', '131023', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('196', '191', '香河县', '131024', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('197', '191', '大城县', '131025', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('198', '191', '文安县', '131026', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('199', '191', '大厂回族自治县', '131028', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('200', '191', '霸州市', '131081', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('201', '191', '三河市', '131082', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('202', '35', '衡水市', '131100', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('203', '202', '桃城区', '131102', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('204', '202', '冀州区', '131103', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('205', '202', '枣强县', '131121', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('206', '202', '武邑县', '131122', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('207', '202', '武强县', '131123', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('208', '202', '饶阳县', '131124', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('209', '202', '安平县', '131125', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('210', '202', '故城县', '131126', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('211', '202', '景县', '131127', '0', '2018-10-30 16:29:16', '0', '2018-10-30 16:29:16', '0');
INSERT INTO `d_sys_area` VALUES ('212', '202', '阜城县', '131128', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('213', '202', '深州市', '131182', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('214', '35', '省直辖县级行政区划', '139000', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('215', '35', '定州市', '139001', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('216', '35', '辛集市', '139002', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('217', '0', '山西省', '140000', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('218', '217', '太原市', '140100', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('219', '218', '小店区', '140105', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('220', '218', '迎泽区', '140106', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('221', '218', '杏花岭区', '140107', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('222', '218', '尖草坪区', '140108', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('223', '218', '万柏林区', '140109', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('224', '218', '晋源区', '140110', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('225', '218', '清徐县', '140121', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('226', '218', '阳曲县', '140122', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('227', '218', '娄烦县', '140123', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('228', '218', '古交市', '140181', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('229', '217', '大同市', '140200', '0', '2018-10-30 16:29:17', '0', '2018-10-30 16:29:17', '0');
INSERT INTO `d_sys_area` VALUES ('230', '229', '城区', '140202', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('231', '229', '矿区', '140203', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('232', '229', '南郊区', '140211', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('233', '229', '新荣区', '140212', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('234', '229', '阳高县', '140221', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('235', '229', '天镇县', '140222', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('236', '229', '广灵县', '140223', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('237', '229', '灵丘县', '140224', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('238', '229', '浑源县', '140225', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('239', '229', '左云县', '140226', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('240', '229', '大同县', '140227', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('241', '217', '阳泉市', '140300', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('242', '241', '城区', '140302', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('243', '241', '矿区', '140303', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('244', '241', '郊区', '140311', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('245', '241', '平定县', '140321', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('246', '241', '盂县', '140322', '0', '2018-10-30 16:29:18', '0', '2018-10-30 16:29:18', '0');
INSERT INTO `d_sys_area` VALUES ('247', '217', '长治市', '140400', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('248', '247', '城区', '140402', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('249', '247', '郊区', '140411', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('250', '247', '长治县', '140421', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('251', '247', '襄垣县', '140423', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('252', '247', '屯留县', '140424', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('253', '247', '平顺县', '140425', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('254', '247', '黎城县', '140426', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('255', '247', '壶关县', '140427', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('256', '247', '长子县', '140428', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('257', '247', '武乡县', '140429', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('258', '247', '沁县', '140430', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('259', '247', '沁源县', '140431', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('260', '247', '潞城市', '140481', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('261', '217', '晋城市', '140500', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('262', '261', '城区', '140502', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('263', '261', '沁水县', '140521', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('264', '261', '阳城县', '140522', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('265', '261', '陵川县', '140524', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('266', '261', '泽州县', '140525', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('267', '261', '高平市', '140581', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('268', '217', '朔州市', '140600', '0', '2018-10-30 16:29:19', '0', '2018-10-30 16:29:19', '0');
INSERT INTO `d_sys_area` VALUES ('269', '268', '朔城区', '140602', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('270', '268', '平鲁区', '140603', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('271', '268', '山阴县', '140621', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('272', '268', '应县', '140622', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('273', '268', '右玉县', '140623', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('274', '268', '怀仁县', '140624', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('275', '217', '晋中市', '140700', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('276', '275', '榆次区', '140702', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('277', '275', '榆社县', '140721', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('278', '275', '左权县', '140722', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('279', '275', '和顺县', '140723', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('280', '275', '昔阳县', '140724', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('281', '275', '寿阳县', '140725', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('282', '275', '太谷县', '140726', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('283', '275', '祁县', '140727', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('284', '275', '平遥县', '140728', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('285', '275', '灵石县', '140729', '0', '2018-10-30 16:29:20', '0', '2018-10-30 16:29:20', '0');
INSERT INTO `d_sys_area` VALUES ('286', '275', '介休市', '140781', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('287', '217', '运城市', '140800', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('288', '287', '盐湖区', '140802', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('289', '287', '临猗县', '140821', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('290', '287', '万荣县', '140822', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('291', '287', '闻喜县', '140823', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('292', '287', '稷山县', '140824', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('293', '287', '新绛县', '140825', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('294', '287', '绛县', '140826', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('295', '287', '垣曲县', '140827', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('296', '287', '夏县', '140828', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('297', '287', '平陆县', '140829', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('298', '287', '芮城县', '140830', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('299', '287', '永济市', '140881', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('300', '287', '河津市', '140882', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('301', '217', '忻州市', '140900', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('302', '301', '忻府区', '140902', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('303', '301', '定襄县', '140921', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('304', '301', '五台县', '140922', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('305', '301', '代县', '140923', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('306', '301', '繁峙县', '140924', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('307', '301', '宁武县', '140925', '0', '2018-10-30 16:29:21', '0', '2018-10-30 16:29:21', '0');
INSERT INTO `d_sys_area` VALUES ('308', '301', '静乐县', '140926', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('309', '301', '神池县', '140927', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('310', '301', '五寨县', '140928', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('311', '301', '岢岚县', '140929', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('312', '301', '河曲县', '140930', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('313', '301', '保德县', '140931', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('314', '301', '偏关县', '140932', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('315', '301', '原平市', '140981', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('316', '217', '临汾市', '141000', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('317', '316', '尧都区', '141002', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('318', '316', '曲沃县', '141021', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('319', '316', '翼城县', '141022', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('320', '316', '襄汾县', '141023', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('321', '316', '洪洞县', '141024', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('322', '316', '古县', '141025', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('323', '316', '安泽县', '141026', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('324', '316', '浮山县', '141027', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('325', '316', '吉县', '141028', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('326', '316', '乡宁县', '141029', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('327', '316', '大宁县', '141030', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('328', '316', '隰县', '141031', '0', '2018-10-30 16:29:22', '0', '2018-10-30 16:29:22', '0');
INSERT INTO `d_sys_area` VALUES ('329', '316', '永和县', '141032', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('330', '316', '蒲县', '141033', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('331', '316', '汾西县', '141034', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('332', '316', '侯马市', '141081', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('333', '316', '霍州市', '141082', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('334', '217', '吕梁市', '141100', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('335', '334', '离石区', '141102', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('336', '334', '文水县', '141121', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('337', '334', '交城县', '141122', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('338', '334', '兴县', '141123', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('339', '334', '临县', '141124', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('340', '334', '柳林县', '141125', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('341', '334', '石楼县', '141126', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('342', '334', '岚县', '141127', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('343', '334', '方山县', '141128', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('344', '334', '中阳县', '141129', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('345', '334', '交口县', '141130', '0', '2018-10-30 16:29:23', '0', '2018-10-30 16:29:23', '0');
INSERT INTO `d_sys_area` VALUES ('346', '334', '孝义市', '141181', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('347', '334', '汾阳市', '141182', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('348', '0', '内蒙古自治区', '150000', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('349', '348', '呼和浩特市', '150100', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('350', '349', '新城区', '150102', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('351', '349', '回民区', '150103', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('352', '349', '玉泉区', '150104', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('353', '349', '赛罕区', '150105', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('354', '349', '土默特左旗', '150121', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('355', '349', '托克托县', '150122', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('356', '349', '和林格尔县', '150123', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('357', '349', '清水河县', '150124', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('358', '349', '武川县', '150125', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('359', '348', '包头市', '150200', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('360', '359', '东河区', '150202', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('361', '359', '昆都仑区', '150203', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('362', '359', '青山区', '150204', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('363', '359', '石拐区', '150205', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('364', '359', '白云鄂博矿区', '150206', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('365', '359', '九原区', '150207', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('366', '359', '土默特右旗', '150221', '0', '2018-10-30 16:29:24', '0', '2018-10-30 16:29:24', '0');
INSERT INTO `d_sys_area` VALUES ('367', '359', '固阳县', '150222', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('368', '359', '达尔罕茂明安联合旗', '150223', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('369', '348', '乌海市', '150300', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('370', '369', '海勃湾区', '150302', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('371', '369', '海南区', '150303', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('372', '369', '乌达区', '150304', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('373', '348', '赤峰市', '150400', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('374', '373', '红山区', '150402', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('375', '373', '元宝山区', '150403', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('376', '373', '松山区', '150404', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('377', '373', '阿鲁科尔沁旗', '150421', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('378', '373', '巴林左旗', '150422', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('379', '373', '巴林右旗', '150423', '0', '2018-10-30 16:29:25', '0', '2018-10-30 16:29:25', '0');
INSERT INTO `d_sys_area` VALUES ('380', '373', '林西县', '150424', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('381', '373', '克什克腾旗', '150425', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('382', '373', '翁牛特旗', '150426', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('383', '373', '喀喇沁旗', '150428', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('384', '373', '宁城县', '150429', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('385', '373', '敖汉旗', '150430', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('386', '348', '通辽市', '150500', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('387', '386', '科尔沁区', '150502', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('388', '386', '科尔沁左翼中旗', '150521', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('389', '386', '科尔沁左翼后旗', '150522', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('390', '386', '开鲁县', '150523', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('391', '386', '库伦旗', '150524', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('392', '386', '奈曼旗', '150525', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('393', '386', '扎鲁特旗', '150526', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('394', '386', '霍林郭勒市', '150581', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('395', '348', '鄂尔多斯市', '150600', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('396', '395', '东胜区', '150602', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('397', '395', '康巴什区', '150603', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('398', '395', '达拉特旗', '150621', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('399', '395', '准格尔旗', '150622', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('400', '395', '鄂托克前旗', '150623', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('401', '395', '鄂托克旗', '150624', '0', '2018-10-30 16:29:26', '0', '2018-10-30 16:29:26', '0');
INSERT INTO `d_sys_area` VALUES ('402', '395', '杭锦旗', '150625', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('403', '395', '乌审旗', '150626', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('404', '395', '伊金霍洛旗', '150627', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('405', '348', '呼伦贝尔市', '150700', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('406', '405', '海拉尔区', '150702', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('407', '405', '扎赉诺尔区', '150703', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('408', '405', '阿荣旗', '150721', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('409', '405', '莫力达瓦达斡尔族自治旗', '150722', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('410', '405', '鄂伦春自治旗', '150723', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('411', '405', '鄂温克族自治旗', '150724', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('412', '405', '陈巴尔虎旗', '150725', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('413', '405', '新巴尔虎左旗', '150726', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('414', '405', '新巴尔虎右旗', '150727', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('415', '405', '满洲里市', '150781', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('416', '405', '牙克石市', '150782', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('417', '405', '扎兰屯市', '150783', '0', '2018-10-30 16:29:27', '0', '2018-10-30 16:29:27', '0');
INSERT INTO `d_sys_area` VALUES ('418', '405', '额尔古纳市', '150784', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('419', '405', '根河市', '150785', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('420', '348', '巴彦淖尔市', '150800', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('421', '420', '临河区', '150802', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('422', '420', '五原县', '150821', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('423', '420', '磴口县', '150822', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('424', '420', '乌拉特前旗', '150823', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('425', '420', '乌拉特中旗', '150824', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('426', '420', '乌拉特后旗', '150825', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('427', '420', '杭锦后旗', '150826', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('428', '348', '乌兰察布市', '150900', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('429', '428', '集宁区', '150902', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('430', '428', '卓资县', '150921', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('431', '428', '化德县', '150922', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('432', '428', '商都县', '150923', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('433', '428', '兴和县', '150924', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('434', '428', '凉城县', '150925', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('435', '428', '察哈尔右翼前旗', '150926', '0', '2018-10-30 16:29:28', '0', '2018-10-30 16:29:28', '0');
INSERT INTO `d_sys_area` VALUES ('436', '428', '察哈尔右翼中旗', '150927', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('437', '428', '察哈尔右翼后旗', '150928', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('438', '428', '四子王旗', '150929', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('439', '428', '丰镇市', '150981', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('440', '348', '兴安盟', '152200', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('441', '348', '乌兰浩特市', '152201', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('442', '348', '阿尔山市', '152202', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('443', '348', '科尔沁右翼前旗', '152221', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('444', '348', '科尔沁右翼中旗', '152222', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('445', '348', '扎赉特旗', '152223', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('446', '348', '突泉县', '152224', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('447', '348', '锡林郭勒盟', '152500', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('448', '348', '二连浩特市', '152501', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('449', '348', '锡林浩特市', '152502', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('450', '348', '阿巴嘎旗', '152522', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('451', '348', '苏尼特左旗', '152523', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('452', '348', '苏尼特右旗', '152524', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('453', '348', '东乌珠穆沁旗', '152525', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('454', '348', '西乌珠穆沁旗', '152526', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('455', '348', '太仆寺旗', '152527', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('456', '348', '镶黄旗', '152528', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('457', '348', '正镶白旗', '152529', '0', '2018-10-30 16:29:29', '0', '2018-10-30 16:29:29', '0');
INSERT INTO `d_sys_area` VALUES ('458', '348', '正蓝旗', '152530', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('459', '348', '多伦县', '152531', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('460', '348', '阿拉善盟', '152900', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('461', '348', '阿拉善左旗', '152921', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('462', '348', '阿拉善右旗', '152922', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('463', '348', '额济纳旗', '152923', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('464', '0', '辽宁省', '210000', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('465', '464', '沈阳市', '210100', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('466', '465', '和平区', '210102', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('467', '465', '沈河区', '210103', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('468', '465', '大东区', '210104', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('469', '465', '皇姑区', '210105', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('470', '465', '铁西区', '210106', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('471', '465', '苏家屯区', '210111', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('472', '465', '浑南区', '210112', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('473', '465', '沈北新区', '210113', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('474', '465', '于洪区', '210114', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('475', '465', '辽中区', '210115', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('476', '465', '康平县', '210123', '0', '2018-10-30 16:29:30', '0', '2018-10-30 16:29:30', '0');
INSERT INTO `d_sys_area` VALUES ('477', '465', '法库县', '210124', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('478', '465', '新民市', '210181', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('479', '464', '大连市', '210200', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('480', '479', '中山区', '210202', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('481', '479', '西岗区', '210203', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('482', '479', '沙河口区', '210204', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('483', '479', '甘井子区', '210211', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('484', '479', '旅顺口区', '210212', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('485', '479', '金州区', '210213', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('486', '479', '普兰店区', '210214', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('487', '479', '长海县', '210224', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('488', '479', '瓦房店市', '210281', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('489', '479', '庄河市', '210283', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('490', '464', '鞍山市', '210300', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('491', '490', '铁东区', '210302', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('492', '490', '铁西区', '210303', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('493', '490', '立山区', '210304', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('494', '490', '千山区', '210311', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('495', '490', '台安县', '210321', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('496', '490', '岫岩满族自治县', '210323', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('497', '490', '海城市', '210381', '0', '2018-10-30 16:29:31', '0', '2018-10-30 16:29:31', '0');
INSERT INTO `d_sys_area` VALUES ('498', '464', '抚顺市', '210400', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('499', '498', '新抚区', '210402', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('500', '498', '东洲区', '210403', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('501', '498', '望花区', '210404', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('502', '498', '顺城区', '210411', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('503', '498', '抚顺县', '210421', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('504', '498', '新宾满族自治县', '210422', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('505', '498', '清原满族自治县', '210423', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('506', '464', '本溪市', '210500', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('507', '506', '平山区', '210502', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('508', '506', '溪湖区', '210503', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('509', '506', '明山区', '210504', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('510', '506', '南芬区', '210505', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('511', '506', '本溪满族自治县', '210521', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('512', '506', '桓仁满族自治县', '210522', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('513', '464', '丹东市', '210600', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('514', '513', '元宝区', '210602', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('515', '513', '振兴区', '210603', '0', '2018-10-30 16:29:32', '0', '2018-10-30 16:29:32', '0');
INSERT INTO `d_sys_area` VALUES ('516', '513', '振安区', '210604', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('517', '513', '宽甸满族自治县', '210624', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('518', '513', '东港市', '210681', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('519', '513', '凤城市', '210682', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('520', '464', '锦州市', '210700', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('521', '520', '古塔区', '210702', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('522', '520', '凌河区', '210703', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('523', '520', '太和区', '210711', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('524', '520', '黑山县', '210726', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('525', '520', '义县', '210727', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('526', '520', '凌海市', '210781', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('527', '520', '北镇市', '210782', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('528', '464', '营口市', '210800', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('529', '528', '站前区', '210802', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('530', '528', '西市区', '210803', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('531', '528', '鲅鱼圈区', '210804', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('532', '528', '老边区', '210811', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('533', '528', '盖州市', '210881', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('534', '528', '大石桥市', '210882', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('535', '464', '阜新市', '210900', '0', '2018-10-30 16:29:33', '0', '2018-10-30 16:29:33', '0');
INSERT INTO `d_sys_area` VALUES ('536', '535', '海州区', '210902', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('537', '535', '新邱区', '210903', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('538', '535', '太平区', '210904', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('539', '535', '清河门区', '210905', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('540', '535', '细河区', '210911', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('541', '535', '阜新蒙古族自治县', '210921', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('542', '535', '彰武县', '210922', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('543', '464', '辽阳市', '211000', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('544', '543', '白塔区', '211002', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('545', '543', '文圣区', '211003', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('546', '543', '宏伟区', '211004', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('547', '543', '弓长岭区', '211005', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('548', '543', '太子河区', '211011', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('549', '543', '辽阳县', '211021', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('550', '543', '灯塔市', '211081', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('551', '464', '盘锦市', '211100', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('552', '551', '双台子区', '211102', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('553', '551', '兴隆台区', '211103', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('554', '551', '大洼区', '211104', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('555', '551', '盘山县', '211122', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('556', '464', '铁岭市', '211200', '0', '2018-10-30 16:29:34', '0', '2018-10-30 16:29:34', '0');
INSERT INTO `d_sys_area` VALUES ('557', '556', '银州区', '211202', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('558', '556', '清河区', '211204', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('559', '556', '铁岭县', '211221', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('560', '556', '西丰县', '211223', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('561', '556', '昌图县', '211224', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('562', '556', '调兵山市', '211281', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('563', '556', '开原市', '211282', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('564', '464', '朝阳市', '211300', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('565', '564', '双塔区', '211302', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('566', '564', '龙城区', '211303', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('567', '564', '朝阳县', '211321', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('568', '564', '建平县', '211322', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('569', '564', '喀喇沁左翼蒙古族自治县', '211324', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('570', '564', '北票市', '211381', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('571', '564', '凌源市', '211382', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('572', '464', '葫芦岛市', '211400', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('573', '572', '连山区', '211402', '0', '2018-10-30 16:29:35', '0', '2018-10-30 16:29:35', '0');
INSERT INTO `d_sys_area` VALUES ('574', '572', '龙港区', '211403', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('575', '572', '南票区', '211404', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('576', '572', '绥中县', '211421', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('577', '572', '建昌县', '211422', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('578', '572', '兴城市', '211481', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('579', '0', '吉林省', '220000', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('580', '579', '长春市', '220100', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('581', '580', '南关区', '220102', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('582', '580', '宽城区', '220103', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('583', '580', '朝阳区', '220104', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('584', '580', '二道区', '220105', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('585', '580', '绿园区', '220106', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('586', '580', '双阳区', '220112', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('587', '580', '九台区', '220113', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('588', '580', '农安县', '220122', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('589', '580', '榆树市', '220182', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('590', '580', '德惠市', '220183', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('591', '579', '吉林市', '220200', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('592', '591', '昌邑区', '220202', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('593', '591', '龙潭区', '220203', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('594', '591', '船营区', '220204', '0', '2018-10-30 16:29:36', '0', '2018-10-30 16:29:36', '0');
INSERT INTO `d_sys_area` VALUES ('595', '591', '丰满区', '220211', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('596', '591', '永吉县', '220221', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('597', '591', '蛟河市', '220281', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('598', '591', '桦甸市', '220282', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('599', '591', '舒兰市', '220283', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('600', '591', '磐石市', '220284', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('601', '579', '四平市', '220300', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('602', '601', '铁西区', '220302', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('603', '601', '铁东区', '220303', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('604', '601', '梨树县', '220322', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('605', '601', '伊通满族自治县', '220323', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('606', '601', '公主岭市', '220381', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('607', '601', '双辽市', '220382', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('608', '579', '辽源市', '220400', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('609', '608', '龙山区', '220402', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('610', '608', '西安区', '220403', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('611', '608', '东丰县', '220421', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('612', '608', '东辽县', '220422', '0', '2018-10-30 16:29:37', '0', '2018-10-30 16:29:37', '0');
INSERT INTO `d_sys_area` VALUES ('613', '579', '通化市', '220500', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('614', '613', '东昌区', '220502', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('615', '613', '二道江区', '220503', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('616', '613', '通化县', '220521', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('617', '613', '辉南县', '220523', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('618', '613', '柳河县', '220524', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('619', '613', '梅河口市', '220581', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('620', '613', '集安市', '220582', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('621', '579', '白山市', '220600', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('622', '621', '浑江区', '220602', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('623', '621', '江源区', '220605', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('624', '621', '抚松县', '220621', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('625', '621', '靖宇县', '220622', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('626', '621', '长白朝鲜族自治县', '220623', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('627', '621', '临江市', '220681', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('628', '579', '松原市', '220700', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('629', '628', '宁江区', '220702', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('630', '628', '前郭尔罗斯蒙古族自治县', '220721', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('631', '628', '长岭县', '220722', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('632', '628', '乾安县', '220723', '0', '2018-10-30 16:29:38', '0', '2018-10-30 16:29:38', '0');
INSERT INTO `d_sys_area` VALUES ('633', '628', '扶余市', '220781', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('634', '579', '白城市', '220800', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('635', '634', '洮北区', '220802', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('636', '634', '镇赉县', '220821', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('637', '634', '通榆县', '220822', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('638', '634', '洮南市', '220881', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('639', '634', '大安市', '220882', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('640', '579', '延边朝鲜族自治州', '222400', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('641', '579', '延吉市', '222401', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('642', '579', '图们市', '222402', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('643', '579', '敦化市', '222403', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('644', '579', '珲春市', '222404', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('645', '579', '龙井市', '222405', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('646', '579', '和龙市', '222406', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('647', '579', '汪清县', '222424', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('648', '579', '安图县', '222426', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('649', '0', '黑龙江省', '230000', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('650', '649', '哈尔滨市', '230100', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('651', '650', '道里区', '230102', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('652', '650', '南岗区', '230103', '0', '2018-10-30 16:29:39', '0', '2018-10-30 16:29:39', '0');
INSERT INTO `d_sys_area` VALUES ('653', '650', '道外区', '230104', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('654', '650', '平房区', '230108', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('655', '650', '松北区', '230109', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('656', '650', '香坊区', '230110', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('657', '650', '呼兰区', '230111', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('658', '650', '阿城区', '230112', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('659', '650', '双城区', '230113', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('660', '650', '依兰县', '230123', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('661', '650', '方正县', '230124', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('662', '650', '宾县', '230125', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('663', '650', '巴彦县', '230126', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('664', '650', '木兰县', '230127', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('665', '650', '通河县', '230128', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('666', '650', '延寿县', '230129', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('667', '650', '尚志市', '230183', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('668', '650', '五常市', '230184', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('669', '649', '齐齐哈尔市', '230200', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('670', '669', '龙沙区', '230202', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('671', '669', '建华区', '230203', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('672', '669', '铁锋区', '230204', '0', '2018-10-30 16:29:40', '0', '2018-10-30 16:29:40', '0');
INSERT INTO `d_sys_area` VALUES ('673', '669', '昂昂溪区', '230205', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('674', '669', '富拉尔基区', '230206', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('675', '669', '碾子山区', '230207', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('676', '669', '梅里斯达斡尔族区', '230208', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('677', '669', '龙江县', '230221', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('678', '669', '依安县', '230223', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('679', '669', '泰来县', '230224', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('680', '669', '甘南县', '230225', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('681', '669', '富裕县', '230227', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('682', '669', '克山县', '230229', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('683', '669', '克东县', '230230', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('684', '669', '拜泉县', '230231', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('685', '669', '讷河市', '230281', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('686', '649', '鸡西市', '230300', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('687', '686', '鸡冠区', '230302', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('688', '686', '恒山区', '230303', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('689', '686', '滴道区', '230304', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('690', '686', '梨树区', '230305', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('691', '686', '城子河区', '230306', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('692', '686', '麻山区', '230307', '0', '2018-10-30 16:29:41', '0', '2018-10-30 16:29:41', '0');
INSERT INTO `d_sys_area` VALUES ('693', '686', '鸡东县', '230321', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('694', '686', '虎林市', '230381', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('695', '686', '密山市', '230382', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('696', '649', '鹤岗市', '230400', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('697', '696', '向阳区', '230402', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('698', '696', '工农区', '230403', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('699', '696', '南山区', '230404', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('700', '696', '兴安区', '230405', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('701', '696', '东山区', '230406', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('702', '696', '兴山区', '230407', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('703', '696', '萝北县', '230421', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('704', '696', '绥滨县', '230422', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('705', '649', '双鸭山市', '230500', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('706', '705', '尖山区', '230502', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('707', '705', '岭东区', '230503', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('708', '705', '四方台区', '230505', '0', '2018-10-30 16:29:42', '0', '2018-10-30 16:29:42', '0');
INSERT INTO `d_sys_area` VALUES ('709', '705', '宝山区', '230506', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('710', '705', '集贤县', '230521', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('711', '705', '友谊县', '230522', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('712', '705', '宝清县', '230523', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('713', '705', '饶河县', '230524', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('714', '649', '大庆市', '230600', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('715', '714', '萨尔图区', '230602', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('716', '714', '龙凤区', '230603', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('717', '714', '让胡路区', '230604', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('718', '714', '红岗区', '230605', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('719', '714', '大同区', '230606', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('720', '714', '肇州县', '230621', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('721', '714', '肇源县', '230622', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('722', '714', '林甸县', '230623', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('723', '714', '杜尔伯特蒙古族自治县', '230624', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('724', '649', '伊春市', '230700', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('725', '724', '伊春区', '230702', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('726', '724', '南岔区', '230703', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('727', '724', '友好区', '230704', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('728', '724', '西林区', '230705', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('729', '724', '翠峦区', '230706', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('730', '724', '新青区', '230707', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('731', '724', '美溪区', '230708', '0', '2018-10-30 16:29:43', '0', '2018-10-30 16:29:43', '0');
INSERT INTO `d_sys_area` VALUES ('732', '724', '金山屯区', '230709', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('733', '724', '五营区', '230710', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('734', '724', '乌马河区', '230711', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('735', '724', '汤旺河区', '230712', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('736', '724', '带岭区', '230713', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('737', '724', '乌伊岭区', '230714', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('738', '724', '红星区', '230715', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('739', '724', '上甘岭区', '230716', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('740', '724', '嘉荫县', '230722', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('741', '724', '铁力市', '230781', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('742', '649', '佳木斯市', '230800', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('743', '742', '向阳区', '230803', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('744', '742', '前进区', '230804', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('745', '742', '东风区', '230805', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('746', '742', '郊区', '230811', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('747', '742', '桦南县', '230822', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('748', '742', '桦川县', '230826', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('749', '742', '汤原县', '230828', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('750', '742', '同江市', '230881', '0', '2018-10-30 16:29:44', '0', '2018-10-30 16:29:44', '0');
INSERT INTO `d_sys_area` VALUES ('751', '742', '富锦市', '230882', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('752', '742', '抚远市', '230883', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('753', '649', '七台河市', '230900', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('754', '753', '新兴区', '230902', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('755', '753', '桃山区', '230903', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('756', '753', '茄子河区', '230904', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('757', '753', '勃利县', '230921', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('758', '649', '牡丹江市', '231000', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('759', '758', '东安区', '231002', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('760', '758', '阳明区', '231003', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('761', '758', '爱民区', '231004', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('762', '758', '西安区', '231005', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('763', '758', '林口县', '231025', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('764', '758', '绥芬河市', '231081', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('765', '758', '海林市', '231083', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('766', '758', '宁安市', '231084', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('767', '758', '穆棱市', '231085', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('768', '758', '东宁市', '231086', '0', '2018-10-30 16:29:45', '0', '2018-10-30 16:29:45', '0');
INSERT INTO `d_sys_area` VALUES ('769', '649', '黑河市', '231100', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('770', '769', '爱辉区', '231102', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('771', '769', '嫩江县', '231121', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('772', '769', '逊克县', '231123', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('773', '769', '孙吴县', '231124', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('774', '769', '北安市', '231181', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('775', '769', '五大连池市', '231182', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('776', '649', '绥化市', '231200', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('777', '776', '北林区', '231202', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('778', '776', '望奎县', '231221', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('779', '776', '兰西县', '231222', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('780', '776', '青冈县', '231223', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('781', '776', '庆安县', '231224', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('782', '776', '明水县', '231225', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('783', '776', '绥棱县', '231226', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('784', '776', '安达市', '231281', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('785', '776', '肇东市', '231282', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('786', '776', '海伦市', '231283', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('787', '649', '大兴安岭地区', '232700', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('788', '649', '呼玛县', '232721', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('789', '649', '塔河县', '232722', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('790', '649', '漠河县', '232723', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('791', '0', '上海市', '310000', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('792', '791', '黄浦区', '310101', '0', '2018-10-30 16:29:46', '0', '2018-10-30 16:29:46', '0');
INSERT INTO `d_sys_area` VALUES ('793', '791', '徐汇区', '310104', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('794', '791', '长宁区', '310105', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('795', '791', '静安区', '310106', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('796', '791', '普陀区', '310107', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('797', '791', '虹口区', '310109', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('798', '791', '杨浦区', '310110', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('799', '791', '闵行区', '310112', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('800', '791', '宝山区', '310113', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('801', '791', '嘉定区', '310114', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('802', '791', '浦东新区', '310115', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('803', '791', '金山区', '310116', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('804', '791', '松江区', '310117', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('805', '791', '青浦区', '310118', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('806', '791', '奉贤区', '310120', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('807', '791', '崇明区', '310151', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('808', '0', '江苏省', '320000', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('809', '808', '南京市', '320100', '0', '2018-10-30 16:29:47', '0', '2018-10-30 16:29:47', '0');
INSERT INTO `d_sys_area` VALUES ('810', '809', '玄武区', '320102', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('811', '809', '秦淮区', '320104', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('812', '809', '建邺区', '320105', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('813', '809', '鼓楼区', '320106', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('814', '809', '浦口区', '320111', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('815', '809', '栖霞区', '320113', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('816', '809', '雨花台区', '320114', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('817', '809', '江宁区', '320115', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('818', '809', '六合区', '320116', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('819', '809', '溧水区', '320117', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('820', '809', '高淳区', '320118', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('821', '808', '无锡市', '320200', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('822', '821', '锡山区', '320205', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('823', '821', '惠山区', '320206', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('824', '821', '滨湖区', '320211', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('825', '821', '梁溪区', '320213', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('826', '821', '新吴区', '320214', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('827', '821', '江阴市', '320281', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('828', '821', '宜兴市', '320282', '0', '2018-10-30 16:29:48', '0', '2018-10-30 16:29:48', '0');
INSERT INTO `d_sys_area` VALUES ('829', '808', '徐州市', '320300', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('830', '829', '鼓楼区', '320302', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('831', '829', '云龙区', '320303', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('832', '829', '贾汪区', '320305', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('833', '829', '泉山区', '320311', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('834', '829', '铜山区', '320312', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('835', '829', '丰县', '320321', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('836', '829', '沛县', '320322', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('837', '829', '睢宁县', '320324', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('838', '829', '新沂市', '320381', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('839', '829', '邳州市', '320382', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('840', '808', '常州市', '320400', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('841', '840', '天宁区', '320402', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('842', '840', '钟楼区', '320404', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('843', '840', '新北区', '320411', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('844', '840', '武进区', '320412', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('845', '840', '金坛区', '320413', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('846', '840', '溧阳市', '320481', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('847', '808', '苏州市', '320500', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('848', '847', '虎丘区', '320505', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('849', '847', '吴中区', '320506', '0', '2018-10-30 16:29:49', '0', '2018-10-30 16:29:49', '0');
INSERT INTO `d_sys_area` VALUES ('850', '847', '相城区', '320507', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('851', '847', '姑苏区', '320508', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('852', '847', '吴江区', '320509', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('853', '847', '常熟市', '320581', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('854', '847', '张家港市', '320582', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('855', '847', '昆山市', '320583', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('856', '847', '太仓市', '320585', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('857', '808', '南通市', '320600', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('858', '857', '崇川区', '320602', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('859', '857', '港闸区', '320611', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('860', '857', '通州区', '320612', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('861', '857', '海安县', '320621', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('862', '857', '如东县', '320623', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('863', '857', '启东市', '320681', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('864', '857', '如皋市', '320682', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('865', '857', '海门市', '320684', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('866', '808', '连云港市', '320700', '0', '2018-10-30 16:29:50', '0', '2018-10-30 16:29:50', '0');
INSERT INTO `d_sys_area` VALUES ('867', '866', '连云区', '320703', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('868', '866', '海州区', '320706', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('869', '866', '赣榆区', '320707', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('870', '866', '东海县', '320722', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('871', '866', '灌云县', '320723', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('872', '866', '灌南县', '320724', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('873', '808', '淮安市', '320800', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('874', '873', '淮安区', '320803', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('875', '873', '淮阴区', '320804', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('876', '873', '清江浦区', '320812', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('877', '873', '洪泽区', '320813', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('878', '873', '涟水县', '320826', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('879', '873', '盱眙县', '320830', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('880', '873', '金湖县', '320831', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('881', '808', '盐城市', '320900', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('882', '881', '亭湖区', '320902', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('883', '881', '盐都区', '320903', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('884', '881', '大丰区', '320904', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('885', '881', '响水县', '320921', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('886', '881', '滨海县', '320922', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('887', '881', '阜宁县', '320923', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('888', '881', '射阳县', '320924', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('889', '881', '建湖县', '320925', '0', '2018-10-30 16:29:51', '0', '2018-10-30 16:29:51', '0');
INSERT INTO `d_sys_area` VALUES ('890', '881', '东台市', '320981', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('891', '808', '扬州市', '321000', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('892', '891', '广陵区', '321002', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('893', '891', '邗江区', '321003', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('894', '891', '江都区', '321012', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('895', '891', '宝应县', '321023', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('896', '891', '仪征市', '321081', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('897', '891', '高邮市', '321084', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('898', '808', '镇江市', '321100', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('899', '898', '京口区', '321102', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('900', '898', '润州区', '321111', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('901', '898', '丹徒区', '321112', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('902', '898', '丹阳市', '321181', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('903', '898', '扬中市', '321182', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('904', '898', '句容市', '321183', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('905', '808', '泰州市', '321200', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('906', '905', '海陵区', '321202', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('907', '905', '高港区', '321203', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('908', '905', '姜堰区', '321204', '0', '2018-10-30 16:29:52', '0', '2018-10-30 16:29:52', '0');
INSERT INTO `d_sys_area` VALUES ('909', '905', '兴化市', '321281', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('910', '905', '靖江市', '321282', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('911', '905', '泰兴市', '321283', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('912', '808', '宿迁市', '321300', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('913', '912', '宿城区', '321302', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('914', '912', '宿豫区', '321311', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('915', '912', '沭阳县', '321322', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('916', '912', '泗阳县', '321323', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('917', '912', '泗洪县', '321324', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('918', '0', '浙江省', '330000', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('919', '918', '杭州市', '330100', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('920', '919', '上城区', '330102', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('921', '919', '下城区', '330103', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('922', '919', '江干区', '330104', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('923', '919', '拱墅区', '330105', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('924', '919', '西湖区', '330106', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('925', '919', '滨江区', '330108', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('926', '919', '萧山区', '330109', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('927', '919', '余杭区', '330110', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('928', '919', '富阳区', '330111', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('929', '919', '桐庐县', '330122', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('930', '919', '淳安县', '330127', '0', '2018-10-30 16:29:53', '0', '2018-10-30 16:29:53', '0');
INSERT INTO `d_sys_area` VALUES ('931', '919', '建德市', '330182', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('932', '919', '临安市', '330185', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('933', '918', '宁波市', '330200', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('934', '933', '海曙区', '330203', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('935', '933', '江东区', '330204', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('936', '933', '江北区', '330205', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('937', '933', '北仑区', '330206', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('938', '933', '镇海区', '330211', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('939', '933', '鄞州区', '330212', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('940', '933', '象山县', '330225', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('941', '933', '宁海县', '330226', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('942', '933', '余姚市', '330281', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('943', '933', '慈溪市', '330282', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('944', '933', '奉化市', '330283', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('945', '918', '温州市', '330300', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('946', '945', '鹿城区', '330302', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('947', '945', '龙湾区', '330303', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('948', '945', '瓯海区', '330304', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('949', '945', '洞头区', '330305', '0', '2018-10-30 16:29:54', '0', '2018-10-30 16:29:54', '0');
INSERT INTO `d_sys_area` VALUES ('950', '945', '永嘉县', '330324', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('951', '945', '平阳县', '330326', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('952', '945', '苍南县', '330327', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('953', '945', '文成县', '330328', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('954', '945', '泰顺县', '330329', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('955', '945', '瑞安市', '330381', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('956', '945', '乐清市', '330382', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('957', '918', '嘉兴市', '330400', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('958', '957', '南湖区', '330402', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('959', '957', '秀洲区', '330411', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('960', '957', '嘉善县', '330421', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('961', '957', '海盐县', '330424', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('962', '957', '海宁市', '330481', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('963', '957', '平湖市', '330482', '0', '2018-10-30 16:29:55', '0', '2018-10-30 16:29:55', '0');
INSERT INTO `d_sys_area` VALUES ('964', '957', '桐乡市', '330483', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('965', '918', '湖州市', '330500', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('966', '965', '吴兴区', '330502', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('967', '965', '南浔区', '330503', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('968', '965', '德清县', '330521', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('969', '965', '长兴县', '330522', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('970', '965', '安吉县', '330523', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('971', '918', '绍兴市', '330600', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('972', '971', '越城区', '330602', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('973', '971', '柯桥区', '330603', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('974', '971', '上虞区', '330604', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('975', '971', '新昌县', '330624', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('976', '971', '诸暨市', '330681', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('977', '971', '嵊州市', '330683', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('978', '918', '金华市', '330700', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('979', '978', '婺城区', '330702', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('980', '978', '金东区', '330703', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('981', '978', '武义县', '330723', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('982', '978', '浦江县', '330726', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('983', '978', '磐安县', '330727', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('984', '978', '兰溪市', '330781', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('985', '978', '义乌市', '330782', '0', '2018-10-30 16:29:56', '0', '2018-10-30 16:29:56', '0');
INSERT INTO `d_sys_area` VALUES ('986', '978', '东阳市', '330783', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('987', '978', '永康市', '330784', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('988', '918', '衢州市', '330800', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('989', '988', '柯城区', '330802', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('990', '988', '衢江区', '330803', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('991', '988', '常山县', '330822', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('992', '988', '开化县', '330824', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('993', '988', '龙游县', '330825', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('994', '988', '江山市', '330881', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('995', '918', '舟山市', '330900', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('996', '995', '定海区', '330902', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('997', '995', '普陀区', '330903', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('998', '995', '岱山县', '330921', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('999', '995', '嵊泗县', '330922', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('1000', '918', '台州市', '331000', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('1001', '1000', '椒江区', '331002', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('1002', '1000', '黄岩区', '331003', '0', '2018-10-30 16:29:57', '0', '2018-10-30 16:29:57', '0');
INSERT INTO `d_sys_area` VALUES ('1003', '1000', '路桥区', '331004', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1004', '1000', '玉环县', '331021', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1005', '1000', '三门县', '331022', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1006', '1000', '天台县', '331023', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1007', '1000', '仙居县', '331024', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1008', '1000', '温岭市', '331081', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1009', '1000', '临海市', '331082', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1010', '918', '丽水市', '331100', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1011', '1010', '莲都区', '331102', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1012', '1010', '青田县', '331121', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1013', '1010', '缙云县', '331122', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1014', '1010', '遂昌县', '331123', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1015', '1010', '松阳县', '331124', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1016', '1010', '云和县', '331125', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1017', '1010', '庆元县', '331126', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1018', '1010', '景宁畲族自治县', '331127', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1019', '1010', '龙泉市', '331181', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1020', '0', '安徽省', '340000', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1021', '1020', '合肥市', '340100', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1022', '1021', '瑶海区', '340102', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1023', '1021', '庐阳区', '340103', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1024', '1021', '蜀山区', '340104', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1025', '1021', '包河区', '340111', '0', '2018-10-30 16:29:58', '0', '2018-10-30 16:29:58', '0');
INSERT INTO `d_sys_area` VALUES ('1026', '1021', '长丰县', '340121', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1027', '1021', '肥东县', '340122', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1028', '1021', '肥西县', '340123', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1029', '1021', '庐江县', '340124', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1030', '1021', '巢湖市', '340181', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1031', '1020', '芜湖市', '340200', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1032', '1031', '镜湖区', '340202', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1033', '1031', '弋江区', '340203', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1034', '1031', '鸠江区', '340207', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1035', '1031', '三山区', '340208', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1036', '1031', '芜湖县', '340221', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1037', '1031', '繁昌县', '340222', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1038', '1031', '南陵县', '340223', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1039', '1031', '无为县', '340225', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1040', '1020', '蚌埠市', '340300', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1041', '1040', '龙子湖区', '340302', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1042', '1040', '蚌山区', '340303', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1043', '1040', '禹会区', '340304', '0', '2018-10-30 16:29:59', '0', '2018-10-30 16:29:59', '0');
INSERT INTO `d_sys_area` VALUES ('1044', '1040', '淮上区', '340311', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1045', '1040', '怀远县', '340321', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1046', '1040', '五河县', '340322', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1047', '1040', '固镇县', '340323', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1048', '1020', '淮南市', '340400', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1049', '1048', '大通区', '340402', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1050', '1048', '田家庵区', '340403', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1051', '1048', '谢家集区', '340404', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1052', '1048', '八公山区', '340405', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1053', '1048', '潘集区', '340406', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1054', '1048', '凤台县', '340421', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1055', '1048', '寿县', '340422', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1056', '1020', '马鞍山市', '340500', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1057', '1056', '花山区', '340503', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1058', '1056', '雨山区', '340504', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1059', '1056', '博望区', '340506', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1060', '1056', '当涂县', '340521', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1061', '1056', '含山县', '340522', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1062', '1056', '和县', '340523', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1063', '1020', '淮北市', '340600', '0', '2018-10-30 16:30:00', '0', '2018-10-30 16:30:00', '0');
INSERT INTO `d_sys_area` VALUES ('1064', '1063', '杜集区', '340602', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1065', '1063', '相山区', '340603', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1066', '1063', '烈山区', '340604', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1067', '1063', '濉溪县', '340621', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1068', '1020', '铜陵市', '340700', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1069', '1068', '铜官区', '340705', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1070', '1068', '义安区', '340706', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1071', '1068', '郊区', '340711', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1072', '1068', '枞阳县', '340722', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1073', '1020', '安庆市', '340800', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1074', '1073', '迎江区', '340802', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1075', '1073', '大观区', '340803', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1076', '1073', '宜秀区', '340811', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1077', '1073', '怀宁县', '340822', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1078', '1073', '潜山县', '340824', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1079', '1073', '太湖县', '340825', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1080', '1073', '宿松县', '340826', '0', '2018-10-30 16:30:01', '0', '2018-10-30 16:30:01', '0');
INSERT INTO `d_sys_area` VALUES ('1081', '1073', '望江县', '340827', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1082', '1073', '岳西县', '340828', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1083', '1073', '桐城市', '340881', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1084', '1020', '黄山市', '341000', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1085', '1084', '屯溪区', '341002', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1086', '1084', '黄山区', '341003', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1087', '1084', '徽州区', '341004', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1088', '1084', '歙县', '341021', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1089', '1084', '休宁县', '341022', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1090', '1084', '黟县', '341023', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1091', '1084', '祁门县', '341024', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1092', '1020', '滁州市', '341100', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1093', '1092', '琅琊区', '341102', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1094', '1092', '南谯区', '341103', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1095', '1092', '来安县', '341122', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1096', '1092', '全椒县', '341124', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1097', '1092', '定远县', '341125', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1098', '1092', '凤阳县', '341126', '0', '2018-10-30 16:30:02', '0', '2018-10-30 16:30:02', '0');
INSERT INTO `d_sys_area` VALUES ('1099', '1092', '天长市', '341181', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1100', '1092', '明光市', '341182', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1101', '1020', '阜阳市', '341200', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1102', '1101', '颍州区', '341202', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1103', '1101', '颍东区', '341203', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1104', '1101', '颍泉区', '341204', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1105', '1101', '临泉县', '341221', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1106', '1101', '太和县', '341222', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1107', '1101', '阜南县', '341225', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1108', '1101', '颍上县', '341226', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1109', '1101', '界首市', '341282', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1110', '1020', '宿州市', '341300', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1111', '1110', '埇桥区', '341302', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1112', '1110', '砀山县', '341321', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1113', '1110', '萧县', '341322', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1114', '1110', '灵璧县', '341323', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1115', '1110', '泗县', '341324', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1116', '1020', '六安市', '341500', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1117', '1116', '金安区', '341502', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1118', '1116', '裕安区', '341503', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1119', '1116', '叶集区', '341504', '0', '2018-10-30 16:30:03', '0', '2018-10-30 16:30:03', '0');
INSERT INTO `d_sys_area` VALUES ('1120', '1116', '霍邱县', '341522', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1121', '1116', '舒城县', '341523', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1122', '1116', '金寨县', '341524', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1123', '1116', '霍山县', '341525', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1124', '1020', '亳州市', '341600', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1125', '1124', '谯城区', '341602', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1126', '1124', '涡阳县', '341621', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1127', '1124', '蒙城县', '341622', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1128', '1124', '利辛县', '341623', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1129', '1020', '池州市', '341700', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1130', '1129', '贵池区', '341702', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1131', '1129', '东至县', '341721', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1132', '1129', '石台县', '341722', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1133', '1129', '青阳县', '341723', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1134', '1020', '宣城市', '341800', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1135', '1134', '宣州区', '341802', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1136', '1134', '郎溪县', '341821', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1137', '1134', '广德县', '341822', '0', '2018-10-30 16:30:04', '0', '2018-10-30 16:30:04', '0');
INSERT INTO `d_sys_area` VALUES ('1138', '1134', '泾县', '341823', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1139', '1134', '绩溪县', '341824', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1140', '1134', '旌德县', '341825', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1141', '1134', '宁国市', '341881', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1142', '0', '福建省', '350000', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1143', '1142', '福州市', '350100', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1144', '1143', '鼓楼区', '350102', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1145', '1143', '台江区', '350103', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1146', '1143', '仓山区', '350104', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1147', '1143', '马尾区', '350105', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1148', '1143', '晋安区', '350111', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1149', '1143', '闽侯县', '350121', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1150', '1143', '连江县', '350122', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1151', '1143', '罗源县', '350123', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1152', '1143', '闽清县', '350124', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1153', '1143', '永泰县', '350125', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1154', '1143', '平潭县', '350128', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1155', '1143', '福清市', '350181', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1156', '1143', '长乐市', '350182', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1157', '1142', '厦门市', '350200', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1158', '1157', '思明区', '350203', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1159', '1157', '海沧区', '350205', '0', '2018-10-30 16:30:05', '0', '2018-10-30 16:30:05', '0');
INSERT INTO `d_sys_area` VALUES ('1160', '1157', '湖里区', '350206', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1161', '1157', '集美区', '350211', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1162', '1157', '同安区', '350212', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1163', '1157', '翔安区', '350213', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1164', '1142', '莆田市', '350300', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1165', '1164', '城厢区', '350302', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1166', '1164', '涵江区', '350303', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1167', '1164', '荔城区', '350304', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1168', '1164', '秀屿区', '350305', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1169', '1164', '仙游县', '350322', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1170', '1142', '三明市', '350400', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1171', '1170', '梅列区', '350402', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1172', '1170', '三元区', '350403', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1173', '1170', '明溪县', '350421', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1174', '1170', '清流县', '350423', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1175', '1170', '宁化县', '350424', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1176', '1170', '大田县', '350425', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1177', '1170', '尤溪县', '350426', '0', '2018-10-30 16:30:06', '0', '2018-10-30 16:30:06', '0');
INSERT INTO `d_sys_area` VALUES ('1178', '1170', '沙县', '350427', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1179', '1170', '将乐县', '350428', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1180', '1170', '泰宁县', '350429', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1181', '1170', '建宁县', '350430', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1182', '1170', '永安市', '350481', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1183', '1142', '泉州市', '350500', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1184', '1183', '鲤城区', '350502', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1185', '1183', '丰泽区', '350503', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1186', '1183', '洛江区', '350504', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1187', '1183', '泉港区', '350505', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1188', '1183', '惠安县', '350521', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1189', '1183', '安溪县', '350524', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1190', '1183', '永春县', '350525', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1191', '1183', '德化县', '350526', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1192', '1183', '金门县', '350527', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1193', '1183', '石狮市', '350581', '0', '2018-10-30 16:30:07', '0', '2018-10-30 16:30:07', '0');
INSERT INTO `d_sys_area` VALUES ('1194', '1183', '晋江市', '350582', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1195', '1183', '南安市', '350583', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1196', '1142', '漳州市', '350600', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1197', '1196', '芗城区', '350602', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1198', '1196', '龙文区', '350603', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1199', '1196', '云霄县', '350622', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1200', '1196', '漳浦县', '350623', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1201', '1196', '诏安县', '350624', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1202', '1196', '长泰县', '350625', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1203', '1196', '东山县', '350626', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1204', '1196', '南靖县', '350627', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1205', '1196', '平和县', '350628', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1206', '1196', '华安县', '350629', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1207', '1196', '龙海市', '350681', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1208', '1142', '南平市', '350700', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1209', '1208', '延平区', '350702', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1210', '1208', '建阳区', '350703', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1211', '1208', '顺昌县', '350721', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1212', '1208', '浦城县', '350722', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1213', '1208', '光泽县', '350723', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1214', '1208', '松溪县', '350724', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1215', '1208', '政和县', '350725', '0', '2018-10-30 16:30:08', '0', '2018-10-30 16:30:08', '0');
INSERT INTO `d_sys_area` VALUES ('1216', '1208', '邵武市', '350781', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1217', '1208', '武夷山市', '350782', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1218', '1208', '建瓯市', '350783', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1219', '1142', '龙岩市', '350800', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1220', '1219', '新罗区', '350802', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1221', '1219', '永定区', '350803', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1222', '1219', '长汀县', '350821', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1223', '1219', '上杭县', '350823', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1224', '1219', '武平县', '350824', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1225', '1219', '连城县', '350825', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1226', '1219', '漳平市', '350881', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1227', '1142', '宁德市', '350900', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1228', '1227', '蕉城区', '350902', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1229', '1227', '霞浦县', '350921', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1230', '1227', '古田县', '350922', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1231', '1227', '屏南县', '350923', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1232', '1227', '寿宁县', '350924', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1233', '1227', '周宁县', '350925', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1234', '1227', '柘荣县', '350926', '0', '2018-10-30 16:30:09', '0', '2018-10-30 16:30:09', '0');
INSERT INTO `d_sys_area` VALUES ('1235', '1227', '福安市', '350981', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1236', '1227', '福鼎市', '350982', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1237', '0', '江西省', '360000', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1238', '1237', '南昌市', '360100', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1239', '1238', '东湖区', '360102', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1240', '1238', '西湖区', '360103', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1241', '1238', '青云谱区', '360104', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1242', '1238', '湾里区', '360105', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1243', '1238', '青山湖区', '360111', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1244', '1238', '新建区', '360112', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1245', '1238', '南昌县', '360121', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1246', '1238', '安义县', '360123', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1247', '1238', '进贤县', '360124', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1248', '1237', '景德镇市', '360200', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1249', '1248', '昌江区', '360202', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1250', '1248', '珠山区', '360203', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1251', '1248', '浮梁县', '360222', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1252', '1248', '乐平市', '360281', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1253', '1237', '萍乡市', '360300', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1254', '1253', '安源区', '360302', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1255', '1253', '湘东区', '360313', '0', '2018-10-30 16:30:10', '0', '2018-10-30 16:30:10', '0');
INSERT INTO `d_sys_area` VALUES ('1256', '1253', '莲花县', '360321', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1257', '1253', '上栗县', '360322', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1258', '1253', '芦溪县', '360323', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1259', '1237', '九江市', '360400', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1260', '1259', '濂溪区', '360402', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1261', '1259', '浔阳区', '360403', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1262', '1259', '九江县', '360421', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1263', '1259', '武宁县', '360423', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1264', '1259', '修水县', '360424', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1265', '1259', '永修县', '360425', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1266', '1259', '德安县', '360426', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1267', '1259', '都昌县', '360428', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1268', '1259', '湖口县', '360429', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1269', '1259', '彭泽县', '360430', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1270', '1259', '瑞昌市', '360481', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1271', '1259', '共青城市', '360482', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1272', '1259', '庐山市', '360483', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1273', '1237', '新余市', '360500', '0', '2018-10-30 16:30:11', '0', '2018-10-30 16:30:11', '0');
INSERT INTO `d_sys_area` VALUES ('1274', '1273', '渝水区', '360502', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1275', '1273', '分宜县', '360521', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1276', '1237', '鹰潭市', '360600', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1277', '1276', '月湖区', '360602', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1278', '1276', '余江县', '360622', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1279', '1276', '贵溪市', '360681', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1280', '1237', '赣州市', '360700', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1281', '1280', '章贡区', '360702', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1282', '1280', '南康区', '360703', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1283', '1280', '赣县', '360721', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1284', '1280', '信丰县', '360722', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1285', '1280', '大余县', '360723', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1286', '1280', '上犹县', '360724', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1287', '1280', '崇义县', '360725', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1288', '1280', '安远县', '360726', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1289', '1280', '龙南县', '360727', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1290', '1280', '定南县', '360728', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1291', '1280', '全南县', '360729', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1292', '1280', '宁都县', '360730', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1293', '1280', '于都县', '360731', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1294', '1280', '兴国县', '360732', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1295', '1280', '会昌县', '360733', '0', '2018-10-30 16:30:12', '0', '2018-10-30 16:30:12', '0');
INSERT INTO `d_sys_area` VALUES ('1296', '1280', '寻乌县', '360734', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1297', '1280', '石城县', '360735', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1298', '1280', '瑞金市', '360781', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1299', '1237', '吉安市', '360800', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1300', '1299', '吉州区', '360802', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1301', '1299', '青原区', '360803', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1302', '1299', '吉安县', '360821', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1303', '1299', '吉水县', '360822', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1304', '1299', '峡江县', '360823', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1305', '1299', '新干县', '360824', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1306', '1299', '永丰县', '360825', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1307', '1299', '泰和县', '360826', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1308', '1299', '遂川县', '360827', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1309', '1299', '万安县', '360828', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1310', '1299', '安福县', '360829', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1311', '1299', '永新县', '360830', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1312', '1299', '井冈山市', '360881', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1313', '1237', '宜春市', '360900', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1314', '1313', '袁州区', '360902', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1315', '1313', '奉新县', '360921', '0', '2018-10-30 16:30:13', '0', '2018-10-30 16:30:13', '0');
INSERT INTO `d_sys_area` VALUES ('1316', '1313', '万载县', '360922', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1317', '1313', '上高县', '360923', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1318', '1313', '宜丰县', '360924', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1319', '1313', '靖安县', '360925', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1320', '1313', '铜鼓县', '360926', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1321', '1313', '丰城市', '360981', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1322', '1313', '樟树市', '360982', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1323', '1313', '高安市', '360983', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1324', '1237', '抚州市', '361000', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1325', '1324', '临川区', '361002', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1326', '1324', '南城县', '361021', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1327', '1324', '黎川县', '361022', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1328', '1324', '南丰县', '361023', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1329', '1324', '崇仁县', '361024', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1330', '1324', '乐安县', '361025', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1331', '1324', '宜黄县', '361026', '0', '2018-10-30 16:30:14', '0', '2018-10-30 16:30:14', '0');
INSERT INTO `d_sys_area` VALUES ('1332', '1324', '金溪县', '361027', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1333', '1324', '资溪县', '361028', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1334', '1324', '东乡县', '361029', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1335', '1324', '广昌县', '361030', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1336', '1237', '上饶市', '361100', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1337', '1336', '信州区', '361102', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1338', '1336', '广丰区', '361103', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1339', '1336', '上饶县', '361121', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1340', '1336', '玉山县', '361123', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1341', '1336', '铅山县', '361124', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1342', '1336', '横峰县', '361125', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1343', '1336', '弋阳县', '361126', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1344', '1336', '余干县', '361127', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1345', '1336', '鄱阳县', '361128', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1346', '1336', '万年县', '361129', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1347', '1336', '婺源县', '361130', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1348', '1336', '德兴市', '361181', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1349', '0', '山东省', '370000', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1350', '1349', '济南市', '370100', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1351', '1350', '历下区', '370102', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1352', '1350', '市中区', '370103', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1353', '1350', '槐荫区', '370104', '0', '2018-10-30 16:30:15', '0', '2018-10-30 16:30:15', '0');
INSERT INTO `d_sys_area` VALUES ('1354', '1350', '天桥区', '370105', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1355', '1350', '历城区', '370112', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1356', '1350', '长清区', '370113', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1357', '1350', '平阴县', '370124', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1358', '1350', '济阳县', '370125', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1359', '1350', '商河县', '370126', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1360', '1350', '章丘市', '370181', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1361', '1349', '青岛市', '370200', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1362', '1361', '市南区', '370202', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1363', '1361', '市北区', '370203', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1364', '1361', '黄岛区', '370211', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1365', '1361', '崂山区', '370212', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1366', '1361', '李沧区', '370213', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1367', '1361', '城阳区', '370214', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1368', '1361', '胶州市', '370281', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1369', '1361', '即墨市', '370282', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1370', '1361', '平度市', '370283', '0', '2018-10-30 16:30:16', '0', '2018-10-30 16:30:16', '0');
INSERT INTO `d_sys_area` VALUES ('1371', '1361', '莱西市', '370285', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1372', '1349', '淄博市', '370300', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1373', '1372', '淄川区', '370302', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1374', '1372', '张店区', '370303', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1375', '1372', '博山区', '370304', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1376', '1372', '临淄区', '370305', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1377', '1372', '周村区', '370306', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1378', '1372', '桓台县', '370321', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1379', '1372', '高青县', '370322', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1380', '1372', '沂源县', '370323', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1381', '1349', '枣庄市', '370400', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1382', '1381', '市中区', '370402', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1383', '1381', '薛城区', '370403', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1384', '1381', '峄城区', '370404', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1385', '1381', '台儿庄区', '370405', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1386', '1381', '山亭区', '370406', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1387', '1381', '滕州市', '370481', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1388', '1349', '东营市', '370500', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1389', '1388', '东营区', '370502', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1390', '1388', '河口区', '370503', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1391', '1388', '垦利区', '370505', '0', '2018-10-30 16:30:17', '0', '2018-10-30 16:30:17', '0');
INSERT INTO `d_sys_area` VALUES ('1392', '1388', '利津县', '370522', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1393', '1388', '广饶县', '370523', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1394', '1349', '烟台市', '370600', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1395', '1394', '芝罘区', '370602', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1396', '1394', '福山区', '370611', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1397', '1394', '牟平区', '370612', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1398', '1394', '莱山区', '370613', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1399', '1394', '长岛县', '370634', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1400', '1394', '龙口市', '370681', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1401', '1394', '莱阳市', '370682', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1402', '1394', '莱州市', '370683', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1403', '1394', '蓬莱市', '370684', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1404', '1394', '招远市', '370685', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1405', '1394', '栖霞市', '370686', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1406', '1394', '海阳市', '370687', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1407', '1349', '潍坊市', '370700', '0', '2018-10-30 16:30:18', '0', '2018-10-30 16:30:18', '0');
INSERT INTO `d_sys_area` VALUES ('1408', '1407', '潍城区', '370702', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1409', '1407', '寒亭区', '370703', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1410', '1407', '坊子区', '370704', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1411', '1407', '奎文区', '370705', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1412', '1407', '临朐县', '370724', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1413', '1407', '昌乐县', '370725', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1414', '1407', '青州市', '370781', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1415', '1407', '诸城市', '370782', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1416', '1407', '寿光市', '370783', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1417', '1407', '安丘市', '370784', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1418', '1407', '高密市', '370785', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1419', '1407', '昌邑市', '370786', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1420', '1349', '济宁市', '370800', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1421', '1420', '任城区', '370811', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1422', '1420', '兖州区', '370812', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1423', '1420', '微山县', '370826', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1424', '1420', '鱼台县', '370827', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1425', '1420', '金乡县', '370828', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1426', '1420', '嘉祥县', '370829', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1427', '1420', '汶上县', '370830', '0', '2018-10-30 16:30:19', '0', '2018-10-30 16:30:19', '0');
INSERT INTO `d_sys_area` VALUES ('1428', '1420', '泗水县', '370831', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1429', '1420', '梁山县', '370832', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1430', '1420', '曲阜市', '370881', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1431', '1420', '邹城市', '370883', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1432', '1349', '泰安市', '370900', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1433', '1432', '泰山区', '370902', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1434', '1432', '岱岳区', '370911', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1435', '1432', '宁阳县', '370921', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1436', '1432', '东平县', '370923', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1437', '1432', '新泰市', '370982', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1438', '1432', '肥城市', '370983', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1439', '1349', '威海市', '371000', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1440', '1439', '环翠区', '371002', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1441', '1439', '文登区', '371003', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1442', '1439', '荣成市', '371082', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1443', '1439', '乳山市', '371083', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1444', '1349', '日照市', '371100', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1445', '1444', '东港区', '371102', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1446', '1444', '岚山区', '371103', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1447', '1444', '五莲县', '371121', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1448', '1444', '莒县', '371122', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1449', '1349', '莱芜市', '371200', '0', '2018-10-30 16:30:20', '0', '2018-10-30 16:30:20', '0');
INSERT INTO `d_sys_area` VALUES ('1450', '1449', '莱城区', '371202', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1451', '1449', '钢城区', '371203', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1452', '1349', '临沂市', '371300', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1453', '1452', '兰山区', '371302', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1454', '1452', '罗庄区', '371311', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1455', '1452', '河东区', '371312', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1456', '1452', '沂南县', '371321', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1457', '1452', '郯城县', '371322', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1458', '1452', '沂水县', '371323', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1459', '1452', '兰陵县', '371324', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1460', '1452', '费县', '371325', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1461', '1452', '平邑县', '371326', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1462', '1452', '莒南县', '371327', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1463', '1452', '蒙阴县', '371328', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1464', '1452', '临沭县', '371329', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1465', '1349', '德州市', '371400', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1466', '1465', '德城区', '371402', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1467', '1465', '陵城区', '371403', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1468', '1465', '宁津县', '371422', '0', '2018-10-30 16:30:21', '0', '2018-10-30 16:30:21', '0');
INSERT INTO `d_sys_area` VALUES ('1469', '1465', '庆云县', '371423', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1470', '1465', '临邑县', '371424', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1471', '1465', '齐河县', '371425', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1472', '1465', '平原县', '371426', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1473', '1465', '夏津县', '371427', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1474', '1465', '武城县', '371428', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1475', '1465', '乐陵市', '371481', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1476', '1465', '禹城市', '371482', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1477', '1349', '聊城市', '371500', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1478', '1477', '东昌府区', '371502', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1479', '1477', '阳谷县', '371521', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1480', '1477', '莘县', '371522', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1481', '1477', '茌平县', '371523', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1482', '1477', '东阿县', '371524', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1483', '1477', '冠县', '371525', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1484', '1477', '高唐县', '371526', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1485', '1477', '临清市', '371581', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1486', '1349', '滨州市', '371600', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1487', '1486', '滨城区', '371602', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1488', '1486', '沾化区', '371603', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1489', '1486', '惠民县', '371621', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1490', '1486', '阳信县', '371622', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1491', '1486', '无棣县', '371623', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1492', '1486', '博兴县', '371625', '0', '2018-10-30 16:30:22', '0', '2018-10-30 16:30:22', '0');
INSERT INTO `d_sys_area` VALUES ('1493', '1486', '邹平县', '371626', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1494', '1349', '菏泽市', '371700', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1495', '1494', '牡丹区', '371702', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1496', '1494', '定陶区', '371703', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1497', '1494', '曹县', '371721', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1498', '1494', '单县', '371722', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1499', '1494', '成武县', '371723', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1500', '1494', '巨野县', '371724', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1501', '1494', '郓城县', '371725', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1502', '1494', '鄄城县', '371726', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1503', '1494', '东明县', '371728', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1504', '0', '河南省', '410000', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1505', '1504', '郑州市', '410100', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1506', '1505', '中原区', '410102', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1507', '1505', '二七区', '410103', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1508', '1505', '管城回族区', '410104', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1509', '1505', '金水区', '410105', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1510', '1505', '上街区', '410106', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1511', '1505', '惠济区', '410108', '0', '2018-10-30 16:30:23', '0', '2018-10-30 16:30:23', '0');
INSERT INTO `d_sys_area` VALUES ('1512', '1505', '中牟县', '410122', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1513', '1505', '巩义市', '410181', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1514', '1505', '荥阳市', '410182', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1515', '1505', '新密市', '410183', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1516', '1505', '新郑市', '410184', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1517', '1505', '登封市', '410185', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1518', '1504', '开封市', '410200', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1519', '1518', '龙亭区', '410202', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1520', '1518', '顺河回族区', '410203', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1521', '1518', '鼓楼区', '410204', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1522', '1518', '禹王台区', '410205', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1523', '1518', '金明区', '410211', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1524', '1518', '祥符区', '410212', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1525', '1518', '杞县', '410221', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1526', '1518', '通许县', '410222', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1527', '1518', '尉氏县', '410223', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1528', '1518', '兰考县', '410225', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1529', '1504', '洛阳市', '410300', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1530', '1529', '老城区', '410302', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1531', '1529', '西工区', '410303', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1532', '1529', '瀍河回族区', '410304', '0', '2018-10-30 16:30:24', '0', '2018-10-30 16:30:24', '0');
INSERT INTO `d_sys_area` VALUES ('1533', '1529', '涧西区', '410305', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1534', '1529', '吉利区', '410306', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1535', '1529', '洛龙区', '410311', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1536', '1529', '孟津县', '410322', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1537', '1529', '新安县', '410323', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1538', '1529', '栾川县', '410324', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1539', '1529', '嵩县', '410325', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1540', '1529', '汝阳县', '410326', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1541', '1529', '宜阳县', '410327', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1542', '1529', '洛宁县', '410328', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1543', '1529', '伊川县', '410329', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1544', '1529', '偃师市', '410381', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1545', '1504', '平顶山市', '410400', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1546', '1545', '新华区', '410402', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1547', '1545', '卫东区', '410403', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1548', '1545', '石龙区', '410404', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1549', '1545', '湛河区', '410411', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1550', '1545', '宝丰县', '410421', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1551', '1545', '叶县', '410422', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1552', '1545', '鲁山县', '410423', '0', '2018-10-30 16:30:25', '0', '2018-10-30 16:30:25', '0');
INSERT INTO `d_sys_area` VALUES ('1553', '1545', '郏县', '410425', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1554', '1545', '舞钢市', '410481', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1555', '1545', '汝州市', '410482', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1556', '1504', '安阳市', '410500', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1557', '1556', '文峰区', '410502', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1558', '1556', '北关区', '410503', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1559', '1556', '殷都区', '410505', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1560', '1556', '龙安区', '410506', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1561', '1556', '安阳县', '410522', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1562', '1556', '汤阴县', '410523', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1563', '1556', '滑县', '410526', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1564', '1556', '内黄县', '410527', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1565', '1556', '林州市', '410581', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1566', '1504', '鹤壁市', '410600', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1567', '1566', '鹤山区', '410602', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1568', '1566', '山城区', '410603', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1569', '1566', '淇滨区', '410611', '0', '2018-10-30 16:30:26', '0', '2018-10-30 16:30:26', '0');
INSERT INTO `d_sys_area` VALUES ('1570', '1566', '浚县', '410621', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1571', '1566', '淇县', '410622', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1572', '1504', '新乡市', '410700', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1573', '1572', '红旗区', '410702', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1574', '1572', '卫滨区', '410703', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1575', '1572', '凤泉区', '410704', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1576', '1572', '牧野区', '410711', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1577', '1572', '新乡县', '410721', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1578', '1572', '获嘉县', '410724', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1579', '1572', '原阳县', '410725', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1580', '1572', '延津县', '410726', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1581', '1572', '封丘县', '410727', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1582', '1572', '长垣县', '410728', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1583', '1572', '卫辉市', '410781', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1584', '1572', '辉县市', '410782', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1585', '1504', '焦作市', '410800', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1586', '1585', '解放区', '410802', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1587', '1585', '中站区', '410803', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1588', '1585', '马村区', '410804', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1589', '1585', '山阳区', '410811', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1590', '1585', '修武县', '410821', '0', '2018-10-30 16:30:27', '0', '2018-10-30 16:30:27', '0');
INSERT INTO `d_sys_area` VALUES ('1591', '1585', '博爱县', '410822', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1592', '1585', '武陟县', '410823', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1593', '1585', '温县', '410825', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1594', '1585', '沁阳市', '410882', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1595', '1585', '孟州市', '410883', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1596', '1504', '濮阳市', '410900', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1597', '1596', '华龙区', '410902', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1598', '1596', '清丰县', '410922', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1599', '1596', '南乐县', '410923', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1600', '1596', '范县', '410926', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1601', '1596', '台前县', '410927', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1602', '1596', '濮阳县', '410928', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1603', '1504', '许昌市', '411000', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1604', '1603', '魏都区', '411002', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1605', '1603', '许昌县', '411023', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1606', '1603', '鄢陵县', '411024', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1607', '1603', '襄城县', '411025', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1608', '1603', '禹州市', '411081', '0', '2018-10-30 16:30:28', '0', '2018-10-30 16:30:28', '0');
INSERT INTO `d_sys_area` VALUES ('1609', '1603', '长葛市', '411082', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1610', '1504', '漯河市', '411100', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1611', '1610', '源汇区', '411102', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1612', '1610', '郾城区', '411103', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1613', '1610', '召陵区', '411104', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1614', '1610', '舞阳县', '411121', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1615', '1610', '临颍县', '411122', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1616', '1504', '三门峡市', '411200', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1617', '1616', '湖滨区', '411202', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1618', '1616', '陕州区', '411203', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1619', '1616', '渑池县', '411221', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1620', '1616', '卢氏县', '411224', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1621', '1616', '义马市', '411281', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1622', '1616', '灵宝市', '411282', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1623', '1504', '南阳市', '411300', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1624', '1623', '宛城区', '411302', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1625', '1623', '卧龙区', '411303', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1626', '1623', '南召县', '411321', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1627', '1623', '方城县', '411322', '0', '2018-10-30 16:30:29', '0', '2018-10-30 16:30:29', '0');
INSERT INTO `d_sys_area` VALUES ('1628', '1623', '西峡县', '411323', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1629', '1623', '镇平县', '411324', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1630', '1623', '内乡县', '411325', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1631', '1623', '淅川县', '411326', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1632', '1623', '社旗县', '411327', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1633', '1623', '唐河县', '411328', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1634', '1623', '新野县', '411329', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1635', '1623', '桐柏县', '411330', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1636', '1623', '邓州市', '411381', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1637', '1504', '商丘市', '411400', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1638', '1637', '梁园区', '411402', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1639', '1637', '睢阳区', '411403', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1640', '1637', '民权县', '411421', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1641', '1637', '睢县', '411422', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1642', '1637', '宁陵县', '411423', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1643', '1637', '柘城县', '411424', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1644', '1637', '虞城县', '411425', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1645', '1637', '夏邑县', '411426', '0', '2018-10-30 16:30:30', '0', '2018-10-30 16:30:30', '0');
INSERT INTO `d_sys_area` VALUES ('1646', '1637', '永城市', '411481', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1647', '1504', '信阳市', '411500', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1648', '1647', '浉河区', '411502', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1649', '1647', '平桥区', '411503', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1650', '1647', '罗山县', '411521', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1651', '1647', '光山县', '411522', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1652', '1647', '新县', '411523', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1653', '1647', '商城县', '411524', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1654', '1647', '固始县', '411525', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1655', '1647', '潢川县', '411526', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1656', '1647', '淮滨县', '411527', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1657', '1647', '息县', '411528', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1658', '1504', '周口市', '411600', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1659', '1658', '川汇区', '411602', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1660', '1658', '扶沟县', '411621', '0', '2018-10-30 16:30:31', '0', '2018-10-30 16:30:31', '0');
INSERT INTO `d_sys_area` VALUES ('1661', '1658', '西华县', '411622', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1662', '1658', '商水县', '411623', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1663', '1658', '沈丘县', '411624', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1664', '1658', '郸城县', '411625', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1665', '1658', '淮阳县', '411626', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1666', '1658', '太康县', '411627', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1667', '1658', '鹿邑县', '411628', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1668', '1658', '项城市', '411681', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1669', '1504', '驻马店市', '411700', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1670', '1669', '驿城区', '411702', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1671', '1669', '西平县', '411721', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1672', '1669', '上蔡县', '411722', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1673', '1669', '平舆县', '411723', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1674', '1669', '正阳县', '411724', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1675', '1669', '确山县', '411725', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1676', '1669', '泌阳县', '411726', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1677', '1669', '汝南县', '411727', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1678', '1669', '遂平县', '411728', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1679', '1669', '新蔡县', '411729', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1680', '1504', '省直辖县级行政区划', '419000', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1681', '1504', '济源市', '419001', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1682', '0', '湖北省', '420000', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1683', '1682', '武汉市', '420100', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1684', '1683', '江岸区', '420102', '0', '2018-10-30 16:30:32', '0', '2018-10-30 16:30:32', '0');
INSERT INTO `d_sys_area` VALUES ('1685', '1683', '江汉区', '420103', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1686', '1683', '硚口区', '420104', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1687', '1683', '汉阳区', '420105', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1688', '1683', '武昌区', '420106', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1689', '1683', '青山区', '420107', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1690', '1683', '洪山区', '420111', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1691', '1683', '东西湖区', '420112', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1692', '1683', '汉南区', '420113', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1693', '1683', '蔡甸区', '420114', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1694', '1683', '江夏区', '420115', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1695', '1683', '黄陂区', '420116', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1696', '1683', '新洲区', '420117', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1697', '1682', '黄石市', '420200', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1698', '1697', '黄石港区', '420202', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1699', '1697', '西塞山区', '420203', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1700', '1697', '下陆区', '420204', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1701', '1697', '铁山区', '420205', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1702', '1697', '阳新县', '420222', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1703', '1697', '大冶市', '420281', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1704', '1682', '十堰市', '420300', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1705', '1704', '茅箭区', '420302', '0', '2018-10-30 16:30:33', '0', '2018-10-30 16:30:33', '0');
INSERT INTO `d_sys_area` VALUES ('1706', '1704', '张湾区', '420303', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1707', '1704', '郧阳区', '420304', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1708', '1704', '郧西县', '420322', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1709', '1704', '竹山县', '420323', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1710', '1704', '竹溪县', '420324', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1711', '1704', '房县', '420325', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1712', '1704', '丹江口市', '420381', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1713', '1682', '宜昌市', '420500', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1714', '1713', '西陵区', '420502', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1715', '1713', '伍家岗区', '420503', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1716', '1713', '点军区', '420504', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1717', '1713', '猇亭区', '420505', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1718', '1713', '夷陵区', '420506', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1719', '1713', '远安县', '420525', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1720', '1713', '兴山县', '420526', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1721', '1713', '秭归县', '420527', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1722', '1713', '长阳土家族自治县', '420528', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1723', '1713', '五峰土家族自治县', '420529', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1724', '1713', '宜都市', '420581', '0', '2018-10-30 16:30:34', '0', '2018-10-30 16:30:34', '0');
INSERT INTO `d_sys_area` VALUES ('1725', '1713', '当阳市', '420582', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1726', '1713', '枝江市', '420583', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1727', '1682', '襄阳市', '420600', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1728', '1727', '襄城区', '420602', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1729', '1727', '樊城区', '420606', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1730', '1727', '襄州区', '420607', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1731', '1727', '南漳县', '420624', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1732', '1727', '谷城县', '420625', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1733', '1727', '保康县', '420626', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1734', '1727', '老河口市', '420682', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1735', '1727', '枣阳市', '420683', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1736', '1727', '宜城市', '420684', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1737', '1682', '鄂州市', '420700', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1738', '1737', '梁子湖区', '420702', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1739', '1737', '华容区', '420703', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1740', '1737', '鄂城区', '420704', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1741', '1682', '荆门市', '420800', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1742', '1741', '东宝区', '420802', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1743', '1741', '掇刀区', '420804', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1744', '1741', '京山县', '420821', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1745', '1741', '沙洋县', '420822', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1746', '1741', '钟祥市', '420881', '0', '2018-10-30 16:30:35', '0', '2018-10-30 16:30:35', '0');
INSERT INTO `d_sys_area` VALUES ('1747', '1682', '孝感市', '420900', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1748', '1747', '孝南区', '420902', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1749', '1747', '孝昌县', '420921', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1750', '1747', '大悟县', '420922', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1751', '1747', '云梦县', '420923', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1752', '1747', '应城市', '420981', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1753', '1747', '安陆市', '420982', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1754', '1747', '汉川市', '420984', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1755', '1682', '荆州市', '421000', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1756', '1755', '沙市区', '421002', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1757', '1755', '荆州区', '421003', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1758', '1755', '公安县', '421022', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1759', '1755', '监利县', '421023', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1760', '1755', '江陵县', '421024', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1761', '1755', '石首市', '421081', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1762', '1755', '洪湖市', '421083', '0', '2018-10-30 16:30:36', '0', '2018-10-30 16:30:36', '0');
INSERT INTO `d_sys_area` VALUES ('1763', '1755', '松滋市', '421087', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1764', '1682', '黄冈市', '421100', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1765', '1764', '黄州区', '421102', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1766', '1764', '团风县', '421121', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1767', '1764', '红安县', '421122', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1768', '1764', '罗田县', '421123', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1769', '1764', '英山县', '421124', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1770', '1764', '浠水县', '421125', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1771', '1764', '蕲春县', '421126', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1772', '1764', '黄梅县', '421127', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1773', '1764', '麻城市', '421181', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1774', '1764', '武穴市', '421182', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1775', '1682', '咸宁市', '421200', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1776', '1775', '咸安区', '421202', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1777', '1775', '嘉鱼县', '421221', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1778', '1775', '通城县', '421222', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1779', '1775', '崇阳县', '421223', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1780', '1775', '通山县', '421224', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1781', '1775', '赤壁市', '421281', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1782', '1682', '随州市', '421300', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1783', '1782', '曾都区', '421303', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1784', '1782', '随县', '421321', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1785', '1782', '广水市', '421381', '0', '2018-10-30 16:30:37', '0', '2018-10-30 16:30:37', '0');
INSERT INTO `d_sys_area` VALUES ('1786', '1682', '恩施土家族苗族自治州', '422800', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1787', '1682', '恩施市', '422801', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1788', '1682', '利川市', '422802', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1789', '1682', '建始县', '422822', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1790', '1682', '巴东县', '422823', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1791', '1682', '宣恩县', '422825', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1792', '1682', '咸丰县', '422826', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1793', '1682', '来凤县', '422827', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1794', '1682', '鹤峰县', '422828', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1795', '1682', '省直辖县级行政区划', '429000', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1796', '1682', '仙桃市', '429004', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1797', '1682', '潜江市', '429005', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1798', '1682', '天门市', '429006', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1799', '1682', '神农架林区', '429021', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1800', '0', '湖南省', '430000', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1801', '1800', '长沙市', '430100', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1802', '1801', '芙蓉区', '430102', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1803', '1801', '天心区', '430103', '0', '2018-10-30 16:30:38', '0', '2018-10-30 16:30:38', '0');
INSERT INTO `d_sys_area` VALUES ('1804', '1801', '岳麓区', '430104', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1805', '1801', '开福区', '430105', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1806', '1801', '雨花区', '430111', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1807', '1801', '望城区', '430112', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1808', '1801', '长沙县', '430121', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1809', '1801', '宁乡县', '430124', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1810', '1801', '浏阳市', '430181', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1811', '1800', '株洲市', '430200', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1812', '1811', '荷塘区', '430202', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1813', '1811', '芦淞区', '430203', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1814', '1811', '石峰区', '430204', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1815', '1811', '天元区', '430211', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1816', '1811', '株洲县', '430221', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1817', '1811', '攸县', '430223', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1818', '1811', '茶陵县', '430224', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1819', '1811', '炎陵县', '430225', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1820', '1811', '醴陵市', '430281', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1821', '1800', '湘潭市', '430300', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1822', '1821', '雨湖区', '430302', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1823', '1821', '岳塘区', '430304', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1824', '1821', '湘潭县', '430321', '0', '2018-10-30 16:30:39', '0', '2018-10-30 16:30:39', '0');
INSERT INTO `d_sys_area` VALUES ('1825', '1821', '湘乡市', '430381', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1826', '1821', '韶山市', '430382', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1827', '1800', '衡阳市', '430400', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1828', '1827', '珠晖区', '430405', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1829', '1827', '雁峰区', '430406', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1830', '1827', '石鼓区', '430407', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1831', '1827', '蒸湘区', '430408', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1832', '1827', '南岳区', '430412', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1833', '1827', '衡阳县', '430421', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1834', '1827', '衡南县', '430422', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1835', '1827', '衡山县', '430423', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1836', '1827', '衡东县', '430424', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1837', '1827', '祁东县', '430426', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1838', '1827', '耒阳市', '430481', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1839', '1827', '常宁市', '430482', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1840', '1800', '邵阳市', '430500', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1841', '1840', '双清区', '430502', '0', '2018-10-30 16:30:40', '0', '2018-10-30 16:30:40', '0');
INSERT INTO `d_sys_area` VALUES ('1842', '1840', '大祥区', '430503', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1843', '1840', '北塔区', '430511', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1844', '1840', '邵东县', '430521', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1845', '1840', '新邵县', '430522', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1846', '1840', '邵阳县', '430523', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1847', '1840', '隆回县', '430524', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1848', '1840', '洞口县', '430525', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1849', '1840', '绥宁县', '430527', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1850', '1840', '新宁县', '430528', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1851', '1840', '城步苗族自治县', '430529', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1852', '1840', '武冈市', '430581', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1853', '1800', '岳阳市', '430600', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1854', '1853', '岳阳楼区', '430602', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1855', '1853', '云溪区', '430603', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1856', '1853', '君山区', '430611', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1857', '1853', '岳阳县', '430621', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1858', '1853', '华容县', '430623', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1859', '1853', '湘阴县', '430624', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1860', '1853', '平江县', '430626', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1861', '1853', '汨罗市', '430681', '0', '2018-10-30 16:30:41', '0', '2018-10-30 16:30:41', '0');
INSERT INTO `d_sys_area` VALUES ('1862', '1853', '临湘市', '430682', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1863', '1800', '常德市', '430700', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1864', '1863', '武陵区', '430702', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1865', '1863', '鼎城区', '430703', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1866', '1863', '安乡县', '430721', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1867', '1863', '汉寿县', '430722', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1868', '1863', '澧县', '430723', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1869', '1863', '临澧县', '430724', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1870', '1863', '桃源县', '430725', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1871', '1863', '石门县', '430726', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1872', '1863', '津市市', '430781', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1873', '1800', '张家界市', '430800', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1874', '1873', '永定区', '430802', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1875', '1873', '武陵源区', '430811', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1876', '1873', '慈利县', '430821', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1877', '1873', '桑植县', '430822', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1878', '1800', '益阳市', '430900', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1879', '1878', '资阳区', '430902', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1880', '1878', '赫山区', '430903', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1881', '1878', '南县', '430921', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1882', '1878', '桃江县', '430922', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1883', '1878', '安化县', '430923', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1884', '1878', '沅江市', '430981', '0', '2018-10-30 16:30:42', '0', '2018-10-30 16:30:42', '0');
INSERT INTO `d_sys_area` VALUES ('1885', '1800', '郴州市', '431000', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1886', '1885', '北湖区', '431002', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1887', '1885', '苏仙区', '431003', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1888', '1885', '桂阳县', '431021', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1889', '1885', '宜章县', '431022', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1890', '1885', '永兴县', '431023', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1891', '1885', '嘉禾县', '431024', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1892', '1885', '临武县', '431025', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1893', '1885', '汝城县', '431026', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1894', '1885', '桂东县', '431027', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1895', '1885', '安仁县', '431028', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1896', '1885', '资兴市', '431081', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1897', '1800', '永州市', '431100', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1898', '1897', '零陵区', '431102', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1899', '1897', '冷水滩区', '431103', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1900', '1897', '祁阳县', '431121', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1901', '1897', '东安县', '431122', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1902', '1897', '双牌县', '431123', '0', '2018-10-30 16:30:43', '0', '2018-10-30 16:30:43', '0');
INSERT INTO `d_sys_area` VALUES ('1903', '1897', '道县', '431124', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1904', '1897', '江永县', '431125', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1905', '1897', '宁远县', '431126', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1906', '1897', '蓝山县', '431127', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1907', '1897', '新田县', '431128', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1908', '1897', '江华瑶族自治县', '431129', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1909', '1800', '怀化市', '431200', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1910', '1909', '鹤城区', '431202', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1911', '1909', '中方县', '431221', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1912', '1909', '沅陵县', '431222', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1913', '1909', '辰溪县', '431223', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1914', '1909', '溆浦县', '431224', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1915', '1909', '会同县', '431225', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1916', '1909', '麻阳苗族自治县', '431226', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1917', '1909', '新晃侗族自治县', '431227', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1918', '1909', '芷江侗族自治县', '431228', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1919', '1909', '靖州苗族侗族自治县', '431229', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1920', '1909', '通道侗族自治县', '431230', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1921', '1909', '洪江市', '431281', '0', '2018-10-30 16:30:44', '0', '2018-10-30 16:30:44', '0');
INSERT INTO `d_sys_area` VALUES ('1922', '1800', '娄底市', '431300', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1923', '1922', '娄星区', '431302', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1924', '1922', '双峰县', '431321', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1925', '1922', '新化县', '431322', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1926', '1922', '冷水江市', '431381', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1927', '1922', '涟源市', '431382', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1928', '1800', '湘西土家族苗族自治州', '433100', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1929', '1800', '吉首市', '433101', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1930', '1800', '泸溪县', '433122', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1931', '1800', '凤凰县', '433123', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1932', '1800', '花垣县', '433124', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1933', '1800', '保靖县', '433125', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1934', '1800', '古丈县', '433126', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1935', '1800', '永顺县', '433127', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1936', '1800', '龙山县', '433130', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1937', '0', '广东省', '440000', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1938', '1937', '广州市', '440100', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1939', '1938', '荔湾区', '440103', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1940', '1938', '越秀区', '440104', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1941', '1938', '海珠区', '440105', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1942', '1938', '天河区', '440106', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1943', '1938', '白云区', '440111', '0', '2018-10-30 16:30:45', '0', '2018-10-30 16:30:45', '0');
INSERT INTO `d_sys_area` VALUES ('1944', '1938', '黄埔区', '440112', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1945', '1938', '番禺区', '440113', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1946', '1938', '花都区', '440114', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1947', '1938', '南沙区', '440115', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1948', '1938', '从化区', '440117', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1949', '1938', '增城区', '440118', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1950', '1937', '韶关市', '440200', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1951', '1950', '武江区', '440203', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1952', '1950', '浈江区', '440204', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1953', '1950', '曲江区', '440205', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1954', '1950', '始兴县', '440222', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1955', '1950', '仁化县', '440224', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1956', '1950', '翁源县', '440229', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1957', '1950', '乳源瑶族自治县', '440232', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1958', '1950', '新丰县', '440233', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1959', '1950', '乐昌市', '440281', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1960', '1950', '南雄市', '440282', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1961', '1937', '深圳市', '440300', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1962', '1961', '罗湖区', '440303', '0', '2018-10-30 16:30:46', '0', '2018-10-30 16:30:46', '0');
INSERT INTO `d_sys_area` VALUES ('1963', '1961', '福田区', '440304', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1964', '1961', '南山区', '440305', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1965', '1961', '宝安区', '440306', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1966', '1961', '龙岗区', '440307', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1967', '1961', '盐田区', '440308', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1968', '1937', '珠海市', '440400', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1969', '1968', '香洲区', '440402', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1970', '1968', '斗门区', '440403', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1971', '1968', '金湾区', '440404', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1972', '1937', '汕头市', '440500', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1973', '1972', '龙湖区', '440507', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1974', '1972', '金平区', '440511', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1975', '1972', '濠江区', '440512', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1976', '1972', '潮阳区', '440513', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1977', '1972', '潮南区', '440514', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1978', '1972', '澄海区', '440515', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1979', '1972', '南澳县', '440523', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1980', '1937', '佛山市', '440600', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1981', '1980', '禅城区', '440604', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1982', '1980', '南海区', '440605', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1983', '1980', '顺德区', '440606', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1984', '1980', '三水区', '440607', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1985', '1980', '高明区', '440608', '0', '2018-10-30 16:30:47', '0', '2018-10-30 16:30:47', '0');
INSERT INTO `d_sys_area` VALUES ('1986', '1937', '江门市', '440700', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1987', '1986', '蓬江区', '440703', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1988', '1986', '江海区', '440704', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1989', '1986', '新会区', '440705', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1990', '1986', '台山市', '440781', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1991', '1986', '开平市', '440783', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1992', '1986', '鹤山市', '440784', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1993', '1986', '恩平市', '440785', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1994', '1937', '湛江市', '440800', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1995', '1994', '赤坎区', '440802', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1996', '1994', '霞山区', '440803', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1997', '1994', '坡头区', '440804', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1998', '1994', '麻章区', '440811', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('1999', '1994', '遂溪县', '440823', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('2000', '1994', '徐闻县', '440825', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('2001', '1994', '廉江市', '440881', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('2002', '1994', '雷州市', '440882', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('2003', '1994', '吴川市', '440883', '0', '2018-10-30 16:30:48', '0', '2018-10-30 16:30:48', '0');
INSERT INTO `d_sys_area` VALUES ('2004', '1937', '茂名市', '440900', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2005', '2004', '茂南区', '440902', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2006', '2004', '电白区', '440904', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2007', '2004', '高州市', '440981', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2008', '2004', '化州市', '440982', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2009', '2004', '信宜市', '440983', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2010', '1937', '肇庆市', '441200', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2011', '2010', '端州区', '441202', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2012', '2010', '鼎湖区', '441203', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2013', '2010', '高要区', '441204', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2014', '2010', '广宁县', '441223', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2015', '2010', '怀集县', '441224', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2016', '2010', '封开县', '441225', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2017', '2010', '德庆县', '441226', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2018', '2010', '四会市', '441284', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2019', '1937', '惠州市', '441300', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2020', '2019', '惠城区', '441302', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2021', '2019', '惠阳区', '441303', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2022', '2019', '博罗县', '441322', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2023', '2019', '惠东县', '441323', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2024', '2019', '龙门县', '441324', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2025', '1937', '梅州市', '441400', '0', '2018-10-30 16:30:49', '0', '2018-10-30 16:30:49', '0');
INSERT INTO `d_sys_area` VALUES ('2026', '2025', '梅江区', '441402', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2027', '2025', '梅县区', '441403', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2028', '2025', '大埔县', '441422', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2029', '2025', '丰顺县', '441423', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2030', '2025', '五华县', '441424', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2031', '2025', '平远县', '441426', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2032', '2025', '蕉岭县', '441427', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2033', '2025', '兴宁市', '441481', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2034', '1937', '汕尾市', '441500', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2035', '2034', '城区', '441502', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2036', '2034', '海丰县', '441521', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2037', '2034', '陆河县', '441523', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2038', '2034', '陆丰市', '441581', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2039', '1937', '河源市', '441600', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2040', '2039', '源城区', '441602', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2041', '2039', '紫金县', '441621', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2042', '2039', '龙川县', '441622', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2043', '2039', '连平县', '441623', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2044', '2039', '和平县', '441624', '0', '2018-10-30 16:30:50', '0', '2018-10-30 16:30:50', '0');
INSERT INTO `d_sys_area` VALUES ('2045', '2039', '东源县', '441625', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2046', '1937', '阳江市', '441700', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2047', '2046', '江城区', '441702', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2048', '2046', '阳东区', '441704', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2049', '2046', '阳西县', '441721', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2050', '2046', '阳春市', '441781', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2051', '1937', '清远市', '441800', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2052', '2051', '清城区', '441802', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2053', '2051', '清新区', '441803', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2054', '2051', '佛冈县', '441821', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2055', '2051', '阳山县', '441823', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2056', '2051', '连山壮族瑶族自治县', '441825', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2057', '2051', '连南瑶族自治县', '441826', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2058', '2051', '英德市', '441881', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2059', '2051', '连州市', '441882', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2060', '1937', '东莞市', '441900', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2061', '1937', '中山市', '442000', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2062', '1937', '潮州市', '445100', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2063', '2062', '湘桥区', '445102', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2064', '2062', '潮安区', '445103', '0', '2018-10-30 16:30:51', '0', '2018-10-30 16:30:51', '0');
INSERT INTO `d_sys_area` VALUES ('2065', '2062', '饶平县', '445122', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2066', '1937', '揭阳市', '445200', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2067', '2066', '榕城区', '445202', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2068', '2066', '揭东区', '445203', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2069', '2066', '揭西县', '445222', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2070', '2066', '惠来县', '445224', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2071', '2066', '普宁市', '445281', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2072', '1937', '云浮市', '445300', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2073', '2072', '云城区', '445302', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2074', '2072', '云安区', '445303', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2075', '2072', '新兴县', '445321', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2076', '2072', '郁南县', '445322', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2077', '2072', '罗定市', '445381', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2078', '0', '广西壮族自治区', '450000', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2079', '2078', '南宁市', '450100', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2080', '2079', '兴宁区', '450102', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2081', '2079', '青秀区', '450103', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2082', '2079', '江南区', '450105', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2083', '2079', '西乡塘区', '450107', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2084', '2079', '良庆区', '450108', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2085', '2079', '邕宁区', '450109', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2086', '2079', '武鸣区', '450110', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2087', '2079', '隆安县', '450123', '0', '2018-10-30 16:30:52', '0', '2018-10-30 16:30:52', '0');
INSERT INTO `d_sys_area` VALUES ('2088', '2079', '马山县', '450124', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2089', '2079', '上林县', '450125', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2090', '2079', '宾阳县', '450126', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2091', '2079', '横县', '450127', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2092', '2078', '柳州市', '450200', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2093', '2092', '城中区', '450202', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2094', '2092', '鱼峰区', '450203', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2095', '2092', '柳南区', '450204', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2096', '2092', '柳北区', '450205', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2097', '2092', '柳江区', '450206', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2098', '2092', '柳城县', '450222', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2099', '2092', '鹿寨县', '450223', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2100', '2092', '融安县', '450224', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2101', '2092', '融水苗族自治县', '450225', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2102', '2092', '三江侗族自治县', '450226', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2103', '2078', '桂林市', '450300', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2104', '2103', '秀峰区', '450302', '0', '2018-10-30 16:30:53', '0', '2018-10-30 16:30:53', '0');
INSERT INTO `d_sys_area` VALUES ('2105', '2103', '叠彩区', '450303', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2106', '2103', '象山区', '450304', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2107', '2103', '七星区', '450305', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2108', '2103', '雁山区', '450311', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2109', '2103', '临桂区', '450312', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2110', '2103', '阳朔县', '450321', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2111', '2103', '灵川县', '450323', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2112', '2103', '全州县', '450324', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2113', '2103', '兴安县', '450325', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2114', '2103', '永福县', '450326', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2115', '2103', '灌阳县', '450327', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2116', '2103', '龙胜各族自治县', '450328', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2117', '2103', '资源县', '450329', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2118', '2103', '平乐县', '450330', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2119', '2103', '荔浦县', '450331', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2120', '2103', '恭城瑶族自治县', '450332', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2121', '2078', '梧州市', '450400', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2122', '2121', '万秀区', '450403', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2123', '2121', '长洲区', '450405', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2124', '2121', '龙圩区', '450406', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2125', '2121', '苍梧县', '450421', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2126', '2121', '藤县', '450422', '0', '2018-10-30 16:30:54', '0', '2018-10-30 16:30:54', '0');
INSERT INTO `d_sys_area` VALUES ('2127', '2121', '蒙山县', '450423', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2128', '2121', '岑溪市', '450481', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2129', '2078', '北海市', '450500', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2130', '2129', '海城区', '450502', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2131', '2129', '银海区', '450503', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2132', '2129', '铁山港区', '450512', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2133', '2129', '合浦县', '450521', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2134', '2078', '防城港市', '450600', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2135', '2134', '港口区', '450602', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2136', '2134', '防城区', '450603', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2137', '2134', '上思县', '450621', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2138', '2134', '东兴市', '450681', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2139', '2078', '钦州市', '450700', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2140', '2139', '钦南区', '450702', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2141', '2139', '钦北区', '450703', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2142', '2139', '灵山县', '450721', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2143', '2139', '浦北县', '450722', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2144', '2078', '贵港市', '450800', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2145', '2144', '港北区', '450802', '0', '2018-10-30 16:30:55', '0', '2018-10-30 16:30:55', '0');
INSERT INTO `d_sys_area` VALUES ('2146', '2144', '港南区', '450803', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2147', '2144', '覃塘区', '450804', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2148', '2144', '平南县', '450821', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2149', '2144', '桂平市', '450881', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2150', '2078', '玉林市', '450900', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2151', '2150', '玉州区', '450902', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2152', '2150', '福绵区', '450903', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2153', '2150', '容县', '450921', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2154', '2150', '陆川县', '450922', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2155', '2150', '博白县', '450923', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2156', '2150', '兴业县', '450924', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2157', '2150', '北流市', '450981', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2158', '2078', '百色市', '451000', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2159', '2158', '右江区', '451002', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2160', '2158', '田阳县', '451021', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2161', '2158', '田东县', '451022', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2162', '2158', '平果县', '451023', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2163', '2158', '德保县', '451024', '0', '2018-10-30 16:30:56', '0', '2018-10-30 16:30:56', '0');
INSERT INTO `d_sys_area` VALUES ('2164', '2158', '那坡县', '451026', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2165', '2158', '凌云县', '451027', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2166', '2158', '乐业县', '451028', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2167', '2158', '田林县', '451029', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2168', '2158', '西林县', '451030', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2169', '2158', '隆林各族自治县', '451031', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2170', '2158', '靖西市', '451081', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2171', '2078', '贺州市', '451100', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2172', '2171', '八步区', '451102', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2173', '2171', '平桂区', '451103', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2174', '2171', '昭平县', '451121', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2175', '2171', '钟山县', '451122', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2176', '2171', '富川瑶族自治县', '451123', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2177', '2078', '河池市', '451200', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2178', '2177', '金城江区', '451202', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2179', '2177', '南丹县', '451221', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2180', '2177', '天峨县', '451222', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2181', '2177', '凤山县', '451223', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2182', '2177', '东兰县', '451224', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2183', '2177', '罗城仫佬族自治县', '451225', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2184', '2177', '环江毛南族自治县', '451226', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2185', '2177', '巴马瑶族自治县', '451227', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2186', '2177', '都安瑶族自治县', '451228', '0', '2018-10-30 16:30:57', '0', '2018-10-30 16:30:57', '0');
INSERT INTO `d_sys_area` VALUES ('2187', '2177', '大化瑶族自治县', '451229', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2188', '2177', '宜州市', '451281', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2189', '2078', '来宾市', '451300', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2190', '2189', '兴宾区', '451302', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2191', '2189', '忻城县', '451321', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2192', '2189', '象州县', '451322', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2193', '2189', '武宣县', '451323', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2194', '2189', '金秀瑶族自治县', '451324', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2195', '2189', '合山市', '451381', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2196', '2078', '崇左市', '451400', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2197', '2196', '江州区', '451402', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2198', '2196', '扶绥县', '451421', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2199', '2196', '宁明县', '451422', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2200', '2196', '龙州县', '451423', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2201', '2196', '大新县', '451424', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2202', '2196', '天等县', '451425', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2203', '2196', '凭祥市', '451481', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2204', '0', '海南省', '460000', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2205', '2204', '海口市', '460100', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2206', '2205', '秀英区', '460105', '0', '2018-10-30 16:30:58', '0', '2018-10-30 16:30:58', '0');
INSERT INTO `d_sys_area` VALUES ('2207', '2205', '龙华区', '460106', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2208', '2205', '琼山区', '460107', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2209', '2205', '美兰区', '460108', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2210', '2204', '三亚市', '460200', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2211', '2210', '海棠区', '460202', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2212', '2210', '吉阳区', '460203', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2213', '2210', '天涯区', '460204', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2214', '2210', '崖州区', '460205', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2215', '2204', '三沙市', '460300', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2216', '2204', '儋州市', '460400', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2217', '2204', '省直辖县级行政区划', '469000', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2218', '2204', '五指山市', '469001', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2219', '2204', '琼海市', '469002', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2220', '2204', '文昌市', '469005', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2221', '2204', '万宁市', '469006', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2222', '2204', '东方市', '469007', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2223', '2204', '定安县', '469021', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2224', '2204', '屯昌县', '469022', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2225', '2204', '澄迈县', '469023', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2226', '2204', '临高县', '469024', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2227', '2204', '白沙黎族自治县', '469025', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2228', '2204', '昌江黎族自治县', '469026', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2229', '2204', '乐东黎族自治县', '469027', '0', '2018-10-30 16:30:59', '0', '2018-10-30 16:30:59', '0');
INSERT INTO `d_sys_area` VALUES ('2230', '2204', '陵水黎族自治县', '469028', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2231', '2204', '保亭黎族苗族自治县', '469029', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2232', '2204', '琼中黎族苗族自治县', '469030', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2233', '0', '重庆市', '500000', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2234', '2233', '万州区', '500101', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2235', '2233', '涪陵区', '500102', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2236', '2233', '渝中区', '500103', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2237', '2233', '大渡口区', '500104', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2238', '2233', '江北区', '500105', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2239', '2233', '沙坪坝区', '500106', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2240', '2233', '九龙坡区', '500107', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2241', '2233', '南岸区', '500108', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2242', '2233', '北碚区', '500109', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2243', '2233', '綦江区', '500110', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2244', '2233', '大足区', '500111', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2245', '2233', '渝北区', '500112', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2246', '2233', '巴南区', '500113', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2247', '2233', '黔江区', '500114', '0', '2018-10-30 16:31:00', '0', '2018-10-30 16:31:00', '0');
INSERT INTO `d_sys_area` VALUES ('2248', '2233', '长寿区', '500115', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2249', '2233', '江津区', '500116', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2250', '2233', '合川区', '500117', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2251', '2233', '永川区', '500118', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2252', '2233', '南川区', '500119', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2253', '2233', '璧山区', '500120', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2254', '2233', '铜梁区', '500151', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2255', '2233', '潼南区', '500152', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2256', '2233', '荣昌区', '500153', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2257', '2233', '开州区', '500154', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2258', '2233', '县', '500200', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2259', '2233', '梁平县', '500228', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2260', '2233', '城口县', '500229', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2261', '2233', '丰都县', '500230', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2262', '2233', '垫江县', '500231', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2263', '2233', '武隆县', '500232', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2264', '2233', '忠县', '500233', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2265', '2233', '云阳县', '500235', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2266', '2233', '奉节县', '500236', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2267', '2233', '巫山县', '500237', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2268', '2233', '巫溪县', '500238', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2269', '2233', '石柱土家族自治县', '500240', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2270', '2233', '秀山土家族苗族自治县', '500241', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2271', '2233', '酉阳土家族苗族自治县', '500242', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2272', '2233', '彭水苗族土家族自治县', '500243', '0', '2018-10-30 16:31:01', '0', '2018-10-30 16:31:01', '0');
INSERT INTO `d_sys_area` VALUES ('2273', '0', '四川省', '510000', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2274', '2273', '成都市', '510100', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2275', '2274', '锦江区', '510104', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2276', '2274', '青羊区', '510105', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2277', '2274', '金牛区', '510106', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2278', '2274', '武侯区', '510107', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2279', '2274', '成华区', '510108', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2280', '2274', '龙泉驿区', '510112', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2281', '2274', '青白江区', '510113', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2282', '2274', '新都区', '510114', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2283', '2274', '温江区', '510115', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2284', '2274', '双流区', '510116', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2285', '2274', '金堂县', '510121', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2286', '2274', '郫县', '510124', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2287', '2274', '大邑县', '510129', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2288', '2274', '蒲江县', '510131', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2289', '2274', '新津县', '510132', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2290', '2274', '都江堰市', '510181', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2291', '2274', '彭州市', '510182', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2292', '2274', '邛崃市', '510183', '0', '2018-10-30 16:31:02', '0', '2018-10-30 16:31:02', '0');
INSERT INTO `d_sys_area` VALUES ('2293', '2274', '崇州市', '510184', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2294', '2274', '简阳市', '510185', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2295', '2273', '自贡市', '510300', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2296', '2295', '自流井区', '510302', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2297', '2295', '贡井区', '510303', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2298', '2295', '大安区', '510304', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2299', '2295', '沿滩区', '510311', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2300', '2295', '荣县', '510321', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2301', '2295', '富顺县', '510322', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2302', '2273', '攀枝花市', '510400', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2303', '2302', '东区', '510402', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2304', '2302', '西区', '510403', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2305', '2302', '仁和区', '510411', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2306', '2302', '米易县', '510421', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2307', '2302', '盐边县', '510422', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2308', '2273', '泸州市', '510500', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2309', '2308', '江阳区', '510502', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2310', '2308', '纳溪区', '510503', '0', '2018-10-30 16:31:03', '0', '2018-10-30 16:31:03', '0');
INSERT INTO `d_sys_area` VALUES ('2311', '2308', '龙马潭区', '510504', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2312', '2308', '泸县', '510521', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2313', '2308', '合江县', '510522', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2314', '2308', '叙永县', '510524', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2315', '2308', '古蔺县', '510525', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2316', '2273', '德阳市', '510600', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2317', '2316', '旌阳区', '510603', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2318', '2316', '中江县', '510623', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2319', '2316', '罗江县', '510626', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2320', '2316', '广汉市', '510681', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2321', '2316', '什邡市', '510682', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2322', '2316', '绵竹市', '510683', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2323', '2273', '绵阳市', '510700', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2324', '2323', '涪城区', '510703', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2325', '2323', '游仙区', '510704', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2326', '2323', '安州区', '510705', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2327', '2323', '三台县', '510722', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2328', '2323', '盐亭县', '510723', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2329', '2323', '梓潼县', '510725', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2330', '2323', '北川羌族自治县', '510726', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2331', '2323', '平武县', '510727', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2332', '2323', '江油市', '510781', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2333', '2273', '广元市', '510800', '0', '2018-10-30 16:31:04', '0', '2018-10-30 16:31:04', '0');
INSERT INTO `d_sys_area` VALUES ('2334', '2333', '利州区', '510802', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2335', '2333', '昭化区', '510811', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2336', '2333', '朝天区', '510812', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2337', '2333', '旺苍县', '510821', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2338', '2333', '青川县', '510822', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2339', '2333', '剑阁县', '510823', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2340', '2333', '苍溪县', '510824', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2341', '2273', '遂宁市', '510900', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2342', '2341', '船山区', '510903', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2343', '2341', '安居区', '510904', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2344', '2341', '蓬溪县', '510921', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2345', '2341', '射洪县', '510922', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2346', '2341', '大英县', '510923', '0', '2018-10-30 16:31:05', '0', '2018-10-30 16:31:05', '0');
INSERT INTO `d_sys_area` VALUES ('2347', '2273', '内江市', '511000', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2348', '2347', '市中区', '511002', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2349', '2347', '东兴区', '511011', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2350', '2347', '威远县', '511024', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2351', '2347', '资中县', '511025', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2352', '2347', '隆昌县', '511028', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2353', '2273', '乐山市', '511100', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2354', '2353', '市中区', '511102', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2355', '2353', '沙湾区', '511111', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2356', '2353', '五通桥区', '511112', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2357', '2353', '金口河区', '511113', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2358', '2353', '犍为县', '511123', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2359', '2353', '井研县', '511124', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2360', '2353', '夹江县', '511126', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2361', '2353', '沐川县', '511129', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2362', '2353', '峨边彝族自治县', '511132', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2363', '2353', '马边彝族自治县', '511133', '0', '2018-10-30 16:31:06', '0', '2018-10-30 16:31:06', '0');
INSERT INTO `d_sys_area` VALUES ('2364', '2353', '峨眉山市', '511181', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2365', '2273', '南充市', '511300', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2366', '2365', '顺庆区', '511302', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2367', '2365', '高坪区', '511303', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2368', '2365', '嘉陵区', '511304', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2369', '2365', '南部县', '511321', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2370', '2365', '营山县', '511322', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2371', '2365', '蓬安县', '511323', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2372', '2365', '仪陇县', '511324', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2373', '2365', '西充县', '511325', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2374', '2365', '阆中市', '511381', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2375', '2273', '眉山市', '511400', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2376', '2375', '东坡区', '511402', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2377', '2375', '彭山区', '511403', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2378', '2375', '仁寿县', '511421', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2379', '2375', '洪雅县', '511423', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2380', '2375', '丹棱县', '511424', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2381', '2375', '青神县', '511425', '0', '2018-10-30 16:31:07', '0', '2018-10-30 16:31:07', '0');
INSERT INTO `d_sys_area` VALUES ('2382', '2273', '宜宾市', '511500', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2383', '2382', '翠屏区', '511502', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2384', '2382', '南溪区', '511503', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2385', '2382', '宜宾县', '511521', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2386', '2382', '江安县', '511523', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2387', '2382', '长宁县', '511524', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2388', '2382', '高县', '511525', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2389', '2382', '珙县', '511526', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2390', '2382', '筠连县', '511527', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2391', '2382', '兴文县', '511528', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2392', '2382', '屏山县', '511529', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2393', '2273', '广安市', '511600', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2394', '2393', '广安区', '511602', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2395', '2393', '前锋区', '511603', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2396', '2393', '岳池县', '511621', '0', '2018-10-30 16:31:08', '0', '2018-10-30 16:31:08', '0');
INSERT INTO `d_sys_area` VALUES ('2397', '2393', '武胜县', '511622', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2398', '2393', '邻水县', '511623', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2399', '2393', '华蓥市', '511681', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2400', '2273', '达州市', '511700', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2401', '2400', '通川区', '511702', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2402', '2400', '达川区', '511703', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2403', '2400', '宣汉县', '511722', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2404', '2400', '开江县', '511723', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2405', '2400', '大竹县', '511724', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2406', '2400', '渠县', '511725', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2407', '2400', '万源市', '511781', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2408', '2273', '雅安市', '511800', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2409', '2408', '雨城区', '511802', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2410', '2408', '名山区', '511803', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2411', '2408', '荥经县', '511822', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2412', '2408', '汉源县', '511823', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2413', '2408', '石棉县', '511824', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2414', '2408', '天全县', '511825', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2415', '2408', '芦山县', '511826', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2416', '2408', '宝兴县', '511827', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2417', '2273', '巴中市', '511900', '0', '2018-10-30 16:31:09', '0', '2018-10-30 16:31:09', '0');
INSERT INTO `d_sys_area` VALUES ('2418', '2417', '巴州区', '511902', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2419', '2417', '恩阳区', '511903', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2420', '2417', '通江县', '511921', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2421', '2417', '南江县', '511922', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2422', '2417', '平昌县', '511923', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2423', '2273', '资阳市', '512000', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2424', '2423', '雁江区', '512002', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2425', '2423', '安岳县', '512021', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2426', '2423', '乐至县', '512022', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2427', '2273', '阿坝藏族羌族自治州', '513200', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2428', '2273', '马尔康市', '513201', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2429', '2273', '汶川县', '513221', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2430', '2273', '理县', '513222', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2431', '2273', '茂县', '513223', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2432', '2273', '松潘县', '513224', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2433', '2273', '九寨沟县', '513225', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2434', '2273', '金川县', '513226', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2435', '2273', '小金县', '513227', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2436', '2273', '黑水县', '513228', '0', '2018-10-30 16:31:10', '0', '2018-10-30 16:31:10', '0');
INSERT INTO `d_sys_area` VALUES ('2437', '2273', '壤塘县', '513230', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2438', '2273', '阿坝县', '513231', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2439', '2273', '若尔盖县', '513232', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2440', '2273', '红原县', '513233', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2441', '2273', '甘孜藏族自治州', '513300', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2442', '2273', '康定市', '513301', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2443', '2273', '泸定县', '513322', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2444', '2273', '丹巴县', '513323', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2445', '2273', '九龙县', '513324', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2446', '2273', '雅江县', '513325', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2447', '2273', '道孚县', '513326', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2448', '2273', '炉霍县', '513327', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2449', '2273', '甘孜县', '513328', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2450', '2273', '新龙县', '513329', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2451', '2273', '德格县', '513330', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2452', '2273', '白玉县', '513331', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2453', '2273', '石渠县', '513332', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2454', '2273', '色达县', '513333', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2455', '2273', '理塘县', '513334', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2456', '2273', '巴塘县', '513335', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2457', '2273', '乡城县', '513336', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2458', '2273', '稻城县', '513337', '0', '2018-10-30 16:31:11', '0', '2018-10-30 16:31:11', '0');
INSERT INTO `d_sys_area` VALUES ('2459', '2273', '得荣县', '513338', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2460', '2273', '凉山彝族自治州', '513400', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2461', '2273', '西昌市', '513401', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2462', '2273', '木里藏族自治县', '513422', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2463', '2273', '盐源县', '513423', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2464', '2273', '德昌县', '513424', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2465', '2273', '会理县', '513425', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2466', '2273', '会东县', '513426', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2467', '2273', '宁南县', '513427', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2468', '2273', '普格县', '513428', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2469', '2273', '布拖县', '513429', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2470', '2273', '金阳县', '513430', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2471', '2273', '昭觉县', '513431', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2472', '2273', '喜德县', '513432', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2473', '2273', '冕宁县', '513433', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2474', '2273', '越西县', '513434', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2475', '2273', '甘洛县', '513435', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2476', '2273', '美姑县', '513436', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2477', '2273', '雷波县', '513437', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2478', '0', '贵州省', '520000', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2479', '2478', '贵阳市', '520100', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2480', '2479', '南明区', '520102', '0', '2018-10-30 16:31:12', '0', '2018-10-30 16:31:12', '0');
INSERT INTO `d_sys_area` VALUES ('2481', '2479', '云岩区', '520103', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2482', '2479', '花溪区', '520111', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2483', '2479', '乌当区', '520112', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2484', '2479', '白云区', '520113', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2485', '2479', '观山湖区', '520115', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2486', '2479', '开阳县', '520121', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2487', '2479', '息烽县', '520122', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2488', '2479', '修文县', '520123', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2489', '2479', '清镇市', '520181', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2490', '2478', '六盘水市', '520200', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2491', '2478', '钟山区', '520201', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2492', '2478', '六枝特区', '520203', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2493', '2478', '水城县', '520221', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2494', '2478', '盘县', '520222', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2495', '2478', '遵义市', '520300', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2496', '2495', '红花岗区', '520302', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2497', '2495', '汇川区', '520303', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2498', '2495', '播州区', '520304', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2499', '2495', '桐梓县', '520322', '0', '2018-10-30 16:31:13', '0', '2018-10-30 16:31:13', '0');
INSERT INTO `d_sys_area` VALUES ('2500', '2495', '绥阳县', '520323', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2501', '2495', '正安县', '520324', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2502', '2495', '道真仡佬族苗族自治县', '520325', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2503', '2495', '务川仡佬族苗族自治县', '520326', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2504', '2495', '凤冈县', '520327', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2505', '2495', '湄潭县', '520328', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2506', '2495', '余庆县', '520329', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2507', '2495', '习水县', '520330', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2508', '2495', '赤水市', '520381', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2509', '2495', '仁怀市', '520382', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2510', '2478', '安顺市', '520400', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2511', '2510', '西秀区', '520402', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2512', '2510', '平坝区', '520403', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2513', '2510', '普定县', '520422', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2514', '2510', '镇宁布依族苗族自治县', '520423', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2515', '2510', '关岭布依族苗族自治县', '520424', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2516', '2510', '紫云苗族布依族自治县', '520425', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2517', '2478', '毕节市', '520500', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2518', '2517', '七星关区', '520502', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2519', '2517', '大方县', '520521', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2520', '2517', '黔西县', '520522', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2521', '2517', '金沙县', '520523', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2522', '2517', '织金县', '520524', '0', '2018-10-30 16:31:14', '0', '2018-10-30 16:31:14', '0');
INSERT INTO `d_sys_area` VALUES ('2523', '2517', '纳雍县', '520525', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2524', '2517', '威宁彝族回族苗族自治县', '520526', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2525', '2517', '赫章县', '520527', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2526', '2478', '铜仁市', '520600', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2527', '2526', '碧江区', '520602', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2528', '2526', '万山区', '520603', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2529', '2526', '江口县', '520621', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2530', '2526', '玉屏侗族自治县', '520622', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2531', '2526', '石阡县', '520623', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2532', '2526', '思南县', '520624', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2533', '2526', '印江土家族苗族自治县', '520625', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2534', '2526', '德江县', '520626', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2535', '2526', '沿河土家族自治县', '520627', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2536', '2526', '松桃苗族自治县', '520628', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2537', '2478', '黔西南布依族苗族自治州', '522300', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2538', '2478', '兴义市', '522301', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2539', '2478', '兴仁县', '522322', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2540', '2478', '普安县', '522323', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2541', '2478', '晴隆县', '522324', '0', '2018-10-30 16:31:15', '0', '2018-10-30 16:31:15', '0');
INSERT INTO `d_sys_area` VALUES ('2542', '2478', '贞丰县', '522325', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2543', '2478', '望谟县', '522326', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2544', '2478', '册亨县', '522327', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2545', '2478', '安龙县', '522328', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2546', '2478', '黔东南苗族侗族自治州', '522600', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2547', '2478', '凯里市', '522601', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2548', '2478', '黄平县', '522622', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2549', '2478', '施秉县', '522623', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2550', '2478', '三穗县', '522624', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2551', '2478', '镇远县', '522625', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2552', '2478', '岑巩县', '522626', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2553', '2478', '天柱县', '522627', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2554', '2478', '锦屏县', '522628', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2555', '2478', '剑河县', '522629', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2556', '2478', '台江县', '522630', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2557', '2478', '黎平县', '522631', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2558', '2478', '榕江县', '522632', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2559', '2478', '从江县', '522633', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2560', '2478', '雷山县', '522634', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2561', '2478', '麻江县', '522635', '0', '2018-10-30 16:31:16', '0', '2018-10-30 16:31:16', '0');
INSERT INTO `d_sys_area` VALUES ('2562', '2478', '丹寨县', '522636', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2563', '2478', '黔南布依族苗族自治州', '522700', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2564', '2478', '都匀市', '522701', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2565', '2478', '福泉市', '522702', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2566', '2478', '荔波县', '522722', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2567', '2478', '贵定县', '522723', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2568', '2478', '瓮安县', '522725', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2569', '2478', '独山县', '522726', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2570', '2478', '平塘县', '522727', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2571', '2478', '罗甸县', '522728', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2572', '2478', '长顺县', '522729', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2573', '2478', '龙里县', '522730', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2574', '2478', '惠水县', '522731', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2575', '2478', '三都水族自治县', '522732', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2576', '0', '云南省', '530000', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2577', '2576', '昆明市', '530100', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2578', '2577', '五华区', '530102', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2579', '2577', '盘龙区', '530103', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2580', '2577', '官渡区', '530111', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2581', '2577', '西山区', '530112', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2582', '2577', '东川区', '530113', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2583', '2577', '呈贡区', '530114', '0', '2018-10-30 16:31:17', '0', '2018-10-30 16:31:17', '0');
INSERT INTO `d_sys_area` VALUES ('2584', '2577', '晋宁县', '530122', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2585', '2577', '富民县', '530124', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2586', '2577', '宜良县', '530125', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2587', '2577', '石林彝族自治县', '530126', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2588', '2577', '嵩明县', '530127', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2589', '2577', '禄劝彝族苗族自治县', '530128', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2590', '2577', '寻甸回族彝族自治县', '530129', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2591', '2577', '安宁市', '530181', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2592', '2576', '曲靖市', '530300', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2593', '2592', '麒麟区', '530302', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2594', '2592', '沾益区', '530303', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2595', '2592', '马龙县', '530321', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2596', '2592', '陆良县', '530322', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2597', '2592', '师宗县', '530323', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2598', '2592', '罗平县', '530324', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2599', '2592', '富源县', '530325', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2600', '2592', '会泽县', '530326', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2601', '2592', '宣威市', '530381', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2602', '2576', '玉溪市', '530400', '0', '2018-10-30 16:31:18', '0', '2018-10-30 16:31:18', '0');
INSERT INTO `d_sys_area` VALUES ('2603', '2602', '红塔区', '530402', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2604', '2602', '江川区', '530403', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2605', '2602', '澄江县', '530422', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2606', '2602', '通海县', '530423', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2607', '2602', '华宁县', '530424', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2608', '2602', '易门县', '530425', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2609', '2602', '峨山彝族自治县', '530426', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2610', '2602', '新平彝族傣族自治县', '530427', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2611', '2602', '元江哈尼族彝族傣族自治县', '530428', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2612', '2576', '保山市', '530500', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2613', '2612', '隆阳区', '530502', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2614', '2612', '施甸县', '530521', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2615', '2612', '龙陵县', '530523', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2616', '2612', '昌宁县', '530524', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2617', '2612', '腾冲市', '530581', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2618', '2576', '昭通市', '530600', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2619', '2618', '昭阳区', '530602', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2620', '2618', '鲁甸县', '530621', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2621', '2618', '巧家县', '530622', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2622', '2618', '盐津县', '530623', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2623', '2618', '大关县', '530624', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2624', '2618', '永善县', '530625', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2625', '2618', '绥江县', '530626', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2626', '2618', '镇雄县', '530627', '0', '2018-10-30 16:31:19', '0', '2018-10-30 16:31:19', '0');
INSERT INTO `d_sys_area` VALUES ('2627', '2618', '彝良县', '530628', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2628', '2618', '威信县', '530629', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2629', '2618', '水富县', '530630', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2630', '2576', '丽江市', '530700', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2631', '2630', '古城区', '530702', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2632', '2630', '玉龙纳西族自治县', '530721', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2633', '2630', '永胜县', '530722', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2634', '2630', '华坪县', '530723', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2635', '2630', '宁蒗彝族自治县', '530724', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2636', '2576', '普洱市', '530800', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2637', '2636', '思茅区', '530802', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2638', '2636', '宁洱哈尼族彝族自治县', '530821', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2639', '2636', '墨江哈尼族自治县', '530822', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2640', '2636', '景东彝族自治县', '530823', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2641', '2636', '景谷傣族彝族自治县', '530824', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2642', '2636', '镇沅彝族哈尼族拉祜族自治县', '530825', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2643', '2636', '江城哈尼族彝族自治县', '530826', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2644', '2636', '孟连傣族拉祜族佤族自治县', '530827', '0', '2018-10-30 16:31:20', '0', '2018-10-30 16:31:20', '0');
INSERT INTO `d_sys_area` VALUES ('2645', '2636', '澜沧拉祜族自治县', '530828', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2646', '2636', '西盟佤族自治县', '530829', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2647', '2576', '临沧市', '530900', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2648', '2647', '临翔区', '530902', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2649', '2647', '凤庆县', '530921', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2650', '2647', '云县', '530922', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2651', '2647', '永德县', '530923', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2652', '2647', '镇康县', '530924', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2653', '2647', '双江拉祜族佤族布朗族傣族自治县', '530925', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2654', '2647', '耿马傣族佤族自治县', '530926', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2655', '2647', '沧源佤族自治县', '530927', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2656', '2576', '楚雄彝族自治州', '532300', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2657', '2576', '楚雄市', '532301', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2658', '2576', '双柏县', '532322', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2659', '2576', '牟定县', '532323', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2660', '2576', '南华县', '532324', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2661', '2576', '姚安县', '532325', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2662', '2576', '大姚县', '532326', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2663', '2576', '永仁县', '532327', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2664', '2576', '元谋县', '532328', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2665', '2576', '武定县', '532329', '0', '2018-10-30 16:31:21', '0', '2018-10-30 16:31:21', '0');
INSERT INTO `d_sys_area` VALUES ('2666', '2576', '禄丰县', '532331', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2667', '2576', '红河哈尼族彝族自治州', '532500', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2668', '2576', '个旧市', '532501', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2669', '2576', '开远市', '532502', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2670', '2576', '蒙自市', '532503', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2671', '2576', '弥勒市', '532504', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2672', '2576', '屏边苗族自治县', '532523', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2673', '2576', '建水县', '532524', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2674', '2576', '石屏县', '532525', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2675', '2576', '泸西县', '532527', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2676', '2576', '元阳县', '532528', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2677', '2576', '红河县', '532529', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2678', '2576', '金平苗族瑶族傣族自治县', '532530', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2679', '2576', '绿春县', '532531', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2680', '2576', '河口瑶族自治县', '532532', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2681', '2576', '文山壮族苗族自治州', '532600', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2682', '2576', '文山市', '532601', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2683', '2576', '砚山县', '532622', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2684', '2576', '西畴县', '532623', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2685', '2576', '麻栗坡县', '532624', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2686', '2576', '马关县', '532625', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2687', '2576', '丘北县', '532626', '0', '2018-10-30 16:31:22', '0', '2018-10-30 16:31:22', '0');
INSERT INTO `d_sys_area` VALUES ('2688', '2576', '广南县', '532627', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2689', '2576', '富宁县', '532628', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2690', '2576', '西双版纳傣族自治州', '532800', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2691', '2576', '景洪市', '532801', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2692', '2576', '勐海县', '532822', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2693', '2576', '勐腊县', '532823', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2694', '2576', '大理白族自治州', '532900', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2695', '2576', '大理市', '532901', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2696', '2576', '漾濞彝族自治县', '532922', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2697', '2576', '祥云县', '532923', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2698', '2576', '宾川县', '532924', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2699', '2576', '弥渡县', '532925', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2700', '2576', '南涧彝族自治县', '532926', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2701', '2576', '巍山彝族回族自治县', '532927', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2702', '2576', '永平县', '532928', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2703', '2576', '云龙县', '532929', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2704', '2576', '洱源县', '532930', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2705', '2576', '剑川县', '532931', '0', '2018-10-30 16:31:23', '0', '2018-10-30 16:31:23', '0');
INSERT INTO `d_sys_area` VALUES ('2706', '2576', '鹤庆县', '532932', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2707', '2576', '德宏傣族景颇族自治州', '533100', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2708', '2576', '瑞丽市', '533102', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2709', '2576', '芒市', '533103', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2710', '2576', '梁河县', '533122', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2711', '2576', '盈江县', '533123', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2712', '2576', '陇川县', '533124', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2713', '2576', '怒江傈僳族自治州', '533300', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2714', '2576', '泸水市', '533301', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2715', '2576', '福贡县', '533323', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2716', '2576', '贡山独龙族怒族自治县', '533324', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2717', '2576', '兰坪白族普米族自治县', '533325', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2718', '2576', '迪庆藏族自治州', '533400', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2719', '2576', '香格里拉市', '533401', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2720', '2576', '德钦县', '533422', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2721', '2576', '维西傈僳族自治县', '533423', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2722', '0', '西藏自治区', '540000', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2723', '2722', '拉萨市', '540100', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2724', '2723', '城关区', '540102', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2725', '2723', '堆龙德庆区', '540103', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2726', '2723', '林周县', '540121', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2727', '2723', '当雄县', '540122', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2728', '2723', '尼木县', '540123', '0', '2018-10-30 16:31:24', '0', '2018-10-30 16:31:24', '0');
INSERT INTO `d_sys_area` VALUES ('2729', '2723', '曲水县', '540124', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2730', '2723', '达孜县', '540126', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2731', '2723', '墨竹工卡县', '540127', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2732', '2722', '日喀则市', '540200', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2733', '2722', '桑珠孜区', '540202', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2734', '2722', '南木林县', '540221', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2735', '2722', '江孜县', '540222', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2736', '2722', '定日县', '540223', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2737', '2722', '萨迦县', '540224', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2738', '2722', '拉孜县', '540225', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2739', '2722', '昂仁县', '540226', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2740', '2722', '谢通门县', '540227', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2741', '2722', '白朗县', '540228', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2742', '2722', '仁布县', '540229', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2743', '2722', '康马县', '540230', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2744', '2722', '定结县', '540231', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2745', '2722', '仲巴县', '540232', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2746', '2722', '亚东县', '540233', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2747', '2722', '吉隆县', '540234', '0', '2018-10-30 16:31:25', '0', '2018-10-30 16:31:25', '0');
INSERT INTO `d_sys_area` VALUES ('2748', '2722', '聂拉木县', '540235', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2749', '2722', '萨嘎县', '540236', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2750', '2722', '岗巴县', '540237', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2751', '2722', '昌都市', '540300', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2752', '2722', '卡若区', '540302', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2753', '2722', '江达县', '540321', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2754', '2722', '贡觉县', '540322', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2755', '2722', '类乌齐县', '540323', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2756', '2722', '丁青县', '540324', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2757', '2722', '察雅县', '540325', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2758', '2722', '八宿县', '540326', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2759', '2722', '左贡县', '540327', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2760', '2722', '芒康县', '540328', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2761', '2722', '洛隆县', '540329', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2762', '2722', '边坝县', '540330', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2763', '2722', '林芝市', '540400', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2764', '2722', '巴宜区', '540402', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2765', '2722', '工布江达县', '540421', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2766', '2722', '米林县', '540422', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2767', '2722', '墨脱县', '540423', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2768', '2722', '波密县', '540424', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2769', '2722', '察隅县', '540425', '0', '2018-10-30 16:31:26', '0', '2018-10-30 16:31:26', '0');
INSERT INTO `d_sys_area` VALUES ('2770', '2722', '朗县', '540426', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2771', '2722', '山南市', '540500', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2772', '2771', '乃东区', '540502', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2773', '2771', '扎囊县', '540521', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2774', '2771', '贡嘎县', '540522', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2775', '2771', '桑日县', '540523', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2776', '2771', '琼结县', '540524', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2777', '2771', '曲松县', '540525', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2778', '2771', '措美县', '540526', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2779', '2771', '洛扎县', '540527', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2780', '2771', '加查县', '540528', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2781', '2771', '隆子县', '540529', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2782', '2771', '错那县', '540530', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2783', '2771', '浪卡子县', '540531', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2784', '2722', '那曲地区', '542400', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2785', '2722', '那曲县', '542421', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2786', '2722', '嘉黎县', '542422', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2787', '2722', '比如县', '542423', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2788', '2722', '聂荣县', '542424', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2789', '2722', '安多县', '542425', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2790', '2722', '申扎县', '542426', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2791', '2722', '索县', '542427', '0', '2018-10-30 16:31:27', '0', '2018-10-30 16:31:27', '0');
INSERT INTO `d_sys_area` VALUES ('2792', '2722', '班戈县', '542428', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2793', '2722', '巴青县', '542429', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2794', '2722', '尼玛县', '542430', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2795', '2722', '双湖县', '542431', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2796', '2722', '阿里地区', '542500', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2797', '2722', '普兰县', '542521', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2798', '2722', '札达县', '542522', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2799', '2722', '噶尔县', '542523', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2800', '2722', '日土县', '542524', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2801', '2722', '革吉县', '542525', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2802', '2722', '改则县', '542526', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2803', '2722', '措勤县', '542527', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2804', '0', '陕西省', '610000', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2805', '2804', '西安市', '610100', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2806', '2805', '新城区', '610102', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2807', '2805', '碑林区', '610103', '0', '2018-10-30 16:31:28', '0', '2018-10-30 16:31:28', '0');
INSERT INTO `d_sys_area` VALUES ('2808', '2805', '莲湖区', '610104', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2809', '2805', '灞桥区', '610111', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2810', '2805', '未央区', '610112', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2811', '2805', '雁塔区', '610113', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2812', '2805', '阎良区', '610114', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2813', '2805', '临潼区', '610115', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2814', '2805', '长安区', '610116', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2815', '2805', '高陵区', '610117', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2816', '2805', '蓝田县', '610122', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2817', '2805', '周至县', '610124', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2818', '2805', '户县', '610125', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2819', '2804', '铜川市', '610200', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2820', '2819', '王益区', '610202', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2821', '2819', '印台区', '610203', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2822', '2819', '耀州区', '610204', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2823', '2819', '宜君县', '610222', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2824', '2804', '宝鸡市', '610300', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2825', '2824', '渭滨区', '610302', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2826', '2824', '金台区', '610303', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2827', '2824', '陈仓区', '610304', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2828', '2824', '凤翔县', '610322', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2829', '2824', '岐山县', '610323', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2830', '2824', '扶风县', '610324', '0', '2018-10-30 16:31:29', '0', '2018-10-30 16:31:29', '0');
INSERT INTO `d_sys_area` VALUES ('2831', '2824', '眉县', '610326', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2832', '2824', '陇县', '610327', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2833', '2824', '千阳县', '610328', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2834', '2824', '麟游县', '610329', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2835', '2824', '凤县', '610330', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2836', '2824', '太白县', '610331', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2837', '2804', '咸阳市', '610400', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2838', '2837', '秦都区', '610402', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2839', '2837', '杨陵区', '610403', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2840', '2837', '渭城区', '610404', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2841', '2837', '三原县', '610422', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2842', '2837', '泾阳县', '610423', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2843', '2837', '乾县', '610424', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2844', '2837', '礼泉县', '610425', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2845', '2837', '永寿县', '610426', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2846', '2837', '彬县', '610427', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2847', '2837', '长武县', '610428', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2848', '2837', '旬邑县', '610429', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2849', '2837', '淳化县', '610430', '0', '2018-10-30 16:31:30', '0', '2018-10-30 16:31:30', '0');
INSERT INTO `d_sys_area` VALUES ('2850', '2837', '武功县', '610431', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2851', '2837', '兴平市', '610481', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2852', '2804', '渭南市', '610500', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2853', '2852', '临渭区', '610502', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2854', '2852', '华州区', '610503', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2855', '2852', '潼关县', '610522', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2856', '2852', '大荔县', '610523', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2857', '2852', '合阳县', '610524', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2858', '2852', '澄城县', '610525', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2859', '2852', '蒲城县', '610526', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2860', '2852', '白水县', '610527', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2861', '2852', '富平县', '610528', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2862', '2852', '韩城市', '610581', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2863', '2852', '华阴市', '610582', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2864', '2804', '延安市', '610600', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2865', '2864', '宝塔区', '610602', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2866', '2864', '安塞区', '610603', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2867', '2864', '延长县', '610621', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2868', '2864', '延川县', '610622', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2869', '2864', '子长县', '610623', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2870', '2864', '志丹县', '610625', '0', '2018-10-30 16:31:31', '0', '2018-10-30 16:31:31', '0');
INSERT INTO `d_sys_area` VALUES ('2871', '2864', '吴起县', '610626', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2872', '2864', '甘泉县', '610627', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2873', '2864', '富县', '610628', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2874', '2864', '洛川县', '610629', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2875', '2864', '宜川县', '610630', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2876', '2864', '黄龙县', '610631', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2877', '2864', '黄陵县', '610632', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2878', '2804', '汉中市', '610700', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2879', '2878', '汉台区', '610702', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2880', '2878', '南郑县', '610721', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2881', '2878', '城固县', '610722', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2882', '2878', '洋县', '610723', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2883', '2878', '西乡县', '610724', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2884', '2878', '勉县', '610725', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2885', '2878', '宁强县', '610726', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2886', '2878', '略阳县', '610727', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2887', '2878', '镇巴县', '610728', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2888', '2878', '留坝县', '610729', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2889', '2878', '佛坪县', '610730', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2890', '2804', '榆林市', '610800', '0', '2018-10-30 16:31:32', '0', '2018-10-30 16:31:32', '0');
INSERT INTO `d_sys_area` VALUES ('2891', '2890', '榆阳区', '610802', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2892', '2890', '横山区', '610803', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2893', '2890', '神木县', '610821', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2894', '2890', '府谷县', '610822', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2895', '2890', '靖边县', '610824', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2896', '2890', '定边县', '610825', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2897', '2890', '绥德县', '610826', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2898', '2890', '米脂县', '610827', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2899', '2890', '佳县', '610828', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2900', '2890', '吴堡县', '610829', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2901', '2890', '清涧县', '610830', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2902', '2890', '子洲县', '610831', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2903', '2804', '安康市', '610900', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2904', '2903', '汉滨区', '610902', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2905', '2903', '汉阴县', '610921', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2906', '2903', '石泉县', '610922', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2907', '2903', '宁陕县', '610923', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2908', '2903', '紫阳县', '610924', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2909', '2903', '岚皋县', '610925', '0', '2018-10-30 16:31:33', '0', '2018-10-30 16:31:33', '0');
INSERT INTO `d_sys_area` VALUES ('2910', '2903', '平利县', '610926', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2911', '2903', '镇坪县', '610927', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2912', '2903', '旬阳县', '610928', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2913', '2903', '白河县', '610929', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2914', '2804', '商洛市', '611000', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2915', '2914', '商州区', '611002', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2916', '2914', '洛南县', '611021', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2917', '2914', '丹凤县', '611022', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2918', '2914', '商南县', '611023', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2919', '2914', '山阳县', '611024', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2920', '2914', '镇安县', '611025', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2921', '2914', '柞水县', '611026', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2922', '0', '甘肃省', '620000', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2923', '2922', '兰州市', '620100', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2924', '2923', '城关区', '620102', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2925', '2923', '七里河区', '620103', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2926', '2923', '西固区', '620104', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2927', '2923', '安宁区', '620105', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2928', '2923', '红古区', '620111', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2929', '2923', '永登县', '620121', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2930', '2923', '皋兰县', '620122', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2931', '2923', '榆中县', '620123', '0', '2018-10-30 16:31:34', '0', '2018-10-30 16:31:34', '0');
INSERT INTO `d_sys_area` VALUES ('2932', '2922', '嘉峪关市', '620200', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2933', '2922', '金昌市', '620300', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2934', '2933', '金川区', '620302', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2935', '2933', '永昌县', '620321', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2936', '2922', '白银市', '620400', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2937', '2936', '白银区', '620402', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2938', '2936', '平川区', '620403', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2939', '2936', '靖远县', '620421', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2940', '2936', '会宁县', '620422', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2941', '2936', '景泰县', '620423', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2942', '2922', '天水市', '620500', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2943', '2942', '秦州区', '620502', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2944', '2942', '麦积区', '620503', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2945', '2942', '清水县', '620521', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2946', '2942', '秦安县', '620522', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2947', '2942', '甘谷县', '620523', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2948', '2942', '武山县', '620524', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2949', '2942', '张家川回族自治县', '620525', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2950', '2922', '武威市', '620600', '0', '2018-10-30 16:31:35', '0', '2018-10-30 16:31:35', '0');
INSERT INTO `d_sys_area` VALUES ('2951', '2950', '凉州区', '620602', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2952', '2950', '民勤县', '620621', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2953', '2950', '古浪县', '620622', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2954', '2950', '天祝藏族自治县', '620623', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2955', '2922', '张掖市', '620700', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2956', '2955', '甘州区', '620702', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2957', '2955', '肃南裕固族自治县', '620721', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2958', '2955', '民乐县', '620722', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2959', '2955', '临泽县', '620723', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2960', '2955', '高台县', '620724', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2961', '2955', '山丹县', '620725', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2962', '2922', '平凉市', '620800', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2963', '2962', '崆峒区', '620802', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2964', '2962', '泾川县', '620821', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2965', '2962', '灵台县', '620822', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2966', '2962', '崇信县', '620823', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2967', '2962', '华亭县', '620824', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2968', '2962', '庄浪县', '620825', '0', '2018-10-30 16:31:36', '0', '2018-10-30 16:31:36', '0');
INSERT INTO `d_sys_area` VALUES ('2969', '2962', '静宁县', '620826', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2970', '2922', '酒泉市', '620900', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2971', '2970', '肃州区', '620902', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2972', '2970', '金塔县', '620921', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2973', '2970', '瓜州县', '620922', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2974', '2970', '肃北蒙古族自治县', '620923', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2975', '2970', '阿克塞哈萨克族自治县', '620924', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2976', '2970', '玉门市', '620981', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2977', '2970', '敦煌市', '620982', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2978', '2922', '庆阳市', '621000', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2979', '2978', '西峰区', '621002', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2980', '2978', '庆城县', '621021', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2981', '2978', '环县', '621022', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2982', '2978', '华池县', '621023', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2983', '2978', '合水县', '621024', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2984', '2978', '正宁县', '621025', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2985', '2978', '宁县', '621026', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2986', '2978', '镇原县', '621027', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2987', '2922', '定西市', '621100', '0', '2018-10-30 16:31:37', '0', '2018-10-30 16:31:37', '0');
INSERT INTO `d_sys_area` VALUES ('2988', '2987', '安定区', '621102', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2989', '2987', '通渭县', '621121', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2990', '2987', '陇西县', '621122', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2991', '2987', '渭源县', '621123', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2992', '2987', '临洮县', '621124', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2993', '2987', '漳县', '621125', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2994', '2987', '岷县', '621126', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2995', '2922', '陇南市', '621200', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2996', '2995', '武都区', '621202', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2997', '2995', '成县', '621221', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2998', '2995', '文县', '621222', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('2999', '2995', '宕昌县', '621223', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3000', '2995', '康县', '621224', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3001', '2995', '西和县', '621225', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3002', '2995', '礼县', '621226', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3003', '2995', '徽县', '621227', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3004', '2995', '两当县', '621228', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3005', '2922', '临夏回族自治州', '622900', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3006', '2922', '临夏市', '622901', '0', '2018-10-30 16:31:38', '0', '2018-10-30 16:31:38', '0');
INSERT INTO `d_sys_area` VALUES ('3007', '2922', '临夏县', '622921', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3008', '2922', '康乐县', '622922', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3009', '2922', '永靖县', '622923', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3010', '2922', '广河县', '622924', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3011', '2922', '和政县', '622925', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3012', '2922', '东乡族自治县', '622926', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3013', '2922', '积石山保安族东乡族撒拉族自治县', '622927', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3014', '2922', '甘南藏族自治州', '623000', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3015', '2922', '合作市', '623001', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3016', '2922', '临潭县', '623021', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3017', '2922', '卓尼县', '623022', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3018', '2922', '舟曲县', '623023', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3019', '2922', '迭部县', '623024', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3020', '2922', '玛曲县', '623025', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3021', '2922', '碌曲县', '623026', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3022', '2922', '夏河县', '623027', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3023', '0', '青海省', '630000', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3024', '3023', '西宁市', '630100', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3025', '3024', '城东区', '630102', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3026', '3024', '城中区', '630103', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3027', '3024', '城西区', '630104', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3028', '3024', '城北区', '630105', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3029', '3024', '大通回族土族自治县', '630121', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3030', '3024', '湟中县', '630122', '0', '2018-10-30 16:31:39', '0', '2018-10-30 16:31:39', '0');
INSERT INTO `d_sys_area` VALUES ('3031', '3024', '湟源县', '630123', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3032', '3023', '海东市', '630200', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3033', '3023', '乐都区', '630202', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3034', '3023', '平安区', '630203', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3035', '3023', '民和回族土族自治县', '630222', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3036', '3023', '互助土族自治县', '630223', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3037', '3023', '化隆回族自治县', '630224', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3038', '3023', '循化撒拉族自治县', '630225', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3039', '3023', '海北藏族自治州', '632200', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3040', '3023', '门源回族自治县', '632221', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3041', '3023', '祁连县', '632222', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3042', '3023', '海晏县', '632223', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3043', '3023', '刚察县', '632224', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3044', '3023', '黄南藏族自治州', '632300', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3045', '3023', '同仁县', '632321', '0', '2018-10-30 16:31:40', '0', '2018-10-30 16:31:40', '0');
INSERT INTO `d_sys_area` VALUES ('3046', '3023', '尖扎县', '632322', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3047', '3023', '泽库县', '632323', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3048', '3023', '河南蒙古族自治县', '632324', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3049', '3023', '海南藏族自治州', '632500', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3050', '3023', '共和县', '632521', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3051', '3023', '同德县', '632522', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3052', '3023', '贵德县', '632523', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3053', '3023', '兴海县', '632524', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3054', '3023', '贵南县', '632525', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3055', '3023', '果洛藏族自治州', '632600', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3056', '3023', '玛沁县', '632621', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3057', '3023', '班玛县', '632622', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3058', '3023', '甘德县', '632623', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3059', '3023', '达日县', '632624', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3060', '3023', '久治县', '632625', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3061', '3023', '玛多县', '632626', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3062', '3023', '玉树藏族自治州', '632700', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3063', '3023', '玉树市', '632701', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3064', '3023', '杂多县', '632722', '0', '2018-10-30 16:31:41', '0', '2018-10-30 16:31:41', '0');
INSERT INTO `d_sys_area` VALUES ('3065', '3023', '称多县', '632723', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3066', '3023', '治多县', '632724', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3067', '3023', '囊谦县', '632725', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3068', '3023', '曲麻莱县', '632726', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3069', '3023', '海西蒙古族藏族自治州', '632800', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3070', '3023', '格尔木市', '632801', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3071', '3023', '德令哈市', '632802', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3072', '3023', '乌兰县', '632821', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3073', '3023', '都兰县', '632822', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3074', '3023', '天峻县', '632823', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3075', '0', '宁夏回族自治区', '640000', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3076', '3075', '银川市', '640100', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3077', '3076', '兴庆区', '640104', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3078', '3076', '西夏区', '640105', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3079', '3076', '金凤区', '640106', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3080', '3076', '永宁县', '640121', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3081', '3076', '贺兰县', '640122', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3082', '3076', '灵武市', '640181', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3083', '3075', '石嘴山市', '640200', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3084', '3083', '大武口区', '640202', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3085', '3083', '惠农区', '640205', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3086', '3083', '平罗县', '640221', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3087', '3075', '吴忠市', '640300', '0', '2018-10-30 16:31:42', '0', '2018-10-30 16:31:42', '0');
INSERT INTO `d_sys_area` VALUES ('3088', '3087', '利通区', '640302', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3089', '3087', '红寺堡区', '640303', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3090', '3087', '盐池县', '640323', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3091', '3087', '同心县', '640324', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3092', '3087', '青铜峡市', '640381', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3093', '3075', '固原市', '640400', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3094', '3093', '原州区', '640402', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3095', '3093', '西吉县', '640422', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3096', '3093', '隆德县', '640423', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3097', '3093', '泾源县', '640424', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3098', '3093', '彭阳县', '640425', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3099', '3075', '中卫市', '640500', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3100', '3099', '沙坡头区', '640502', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3101', '3099', '中宁县', '640521', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3102', '3099', '海原县', '640522', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3103', '0', '新疆维吾尔自治区', '650000', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3104', '3103', '乌鲁木齐市', '650100', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3105', '3104', '天山区', '650102', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3106', '3104', '沙依巴克区', '650103', '0', '2018-10-30 16:31:43', '0', '2018-10-30 16:31:43', '0');
INSERT INTO `d_sys_area` VALUES ('3107', '3104', '新市区', '650104', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3108', '3104', '水磨沟区', '650105', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3109', '3104', '头屯河区', '650106', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3110', '3104', '达坂城区', '650107', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3111', '3104', '米东区', '650109', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3112', '3104', '乌鲁木齐县', '650121', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3113', '3103', '克拉玛依市', '650200', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3114', '3113', '独山子区', '650202', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3115', '3113', '克拉玛依区', '650203', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3116', '3113', '白碱滩区', '650204', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3117', '3113', '乌尔禾区', '650205', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3118', '3103', '吐鲁番市', '650400', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3119', '3103', '高昌区', '650402', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3120', '3103', '鄯善县', '650421', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3121', '3103', '托克逊县', '650422', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3122', '3103', '哈密市', '650500', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3123', '3103', '伊州区', '650502', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3124', '3103', '巴里坤哈萨克自治县', '650521', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3125', '3103', '伊吾县', '650522', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3126', '3103', '昌吉回族自治州', '652300', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3127', '3103', '昌吉市', '652301', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3128', '3103', '阜康市', '652302', '0', '2018-10-30 16:31:44', '0', '2018-10-30 16:31:44', '0');
INSERT INTO `d_sys_area` VALUES ('3129', '3103', '呼图壁县', '652323', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3130', '3103', '玛纳斯县', '652324', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3131', '3103', '奇台县', '652325', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3132', '3103', '吉木萨尔县', '652327', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3133', '3103', '木垒哈萨克自治县', '652328', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3134', '3103', '博尔塔拉蒙古自治州', '652700', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3135', '3103', '博乐市', '652701', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3136', '3103', '阿拉山口市', '652702', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3137', '3103', '精河县', '652722', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3138', '3103', '温泉县', '652723', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3139', '3103', '巴音郭楞蒙古自治州', '652800', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3140', '3103', '库尔勒市', '652801', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3141', '3103', '轮台县', '652822', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3142', '3103', '尉犁县', '652823', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3143', '3103', '若羌县', '652824', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3144', '3103', '且末县', '652825', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3145', '3103', '焉耆回族自治县', '652826', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3146', '3103', '和静县', '652827', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3147', '3103', '和硕县', '652828', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3148', '3103', '博湖县', '652829', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3149', '3103', '阿克苏地区', '652900', '0', '2018-10-30 16:31:45', '0', '2018-10-30 16:31:45', '0');
INSERT INTO `d_sys_area` VALUES ('3150', '3103', '阿克苏市', '652901', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3151', '3103', '温宿县', '652922', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3152', '3103', '库车县', '652923', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3153', '3103', '沙雅县', '652924', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3154', '3103', '新和县', '652925', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3155', '3103', '拜城县', '652926', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3156', '3103', '乌什县', '652927', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3157', '3103', '阿瓦提县', '652928', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3158', '3103', '柯坪县', '652929', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3159', '3103', '克孜勒苏柯尔克孜自治州', '653000', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3160', '3103', '阿图什市', '653001', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3161', '3103', '阿克陶县', '653022', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3162', '3103', '阿合奇县', '653023', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3163', '3103', '乌恰县', '653024', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3164', '3103', '喀什地区', '653100', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3165', '3103', '喀什市', '653101', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3166', '3103', '疏附县', '653121', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3167', '3103', '疏勒县', '653122', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3168', '3103', '英吉沙县', '653123', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3169', '3103', '泽普县', '653124', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3170', '3103', '莎车县', '653125', '0', '2018-10-30 16:31:46', '0', '2018-10-30 16:31:46', '0');
INSERT INTO `d_sys_area` VALUES ('3171', '3103', '叶城县', '653126', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3172', '3103', '麦盖提县', '653127', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3173', '3103', '岳普湖县', '653128', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3174', '3103', '伽师县', '653129', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3175', '3103', '巴楚县', '653130', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3176', '3103', '塔什库尔干塔吉克自治县', '653131', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3177', '3103', '和田地区', '653200', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3178', '3103', '和田市', '653201', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3179', '3103', '和田县', '653221', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3180', '3103', '墨玉县', '653222', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3181', '3103', '皮山县', '653223', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3182', '3103', '洛浦县', '653224', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3183', '3103', '策勒县', '653225', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3184', '3103', '于田县', '653226', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3185', '3103', '民丰县', '653227', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3186', '3103', '伊犁哈萨克自治州', '654000', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3187', '3103', '伊宁市', '654002', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3188', '3103', '奎屯市', '654003', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3189', '3103', '霍尔果斯市', '654004', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3190', '3103', '伊宁县', '654021', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3191', '3103', '察布查尔锡伯自治县', '654022', '0', '2018-10-30 16:31:47', '0', '2018-10-30 16:31:47', '0');
INSERT INTO `d_sys_area` VALUES ('3192', '3103', '霍城县', '654023', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3193', '3103', '巩留县', '654024', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3194', '3103', '新源县', '654025', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3195', '3103', '昭苏县', '654026', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3196', '3103', '特克斯县', '654027', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3197', '3103', '尼勒克县', '654028', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3198', '3103', '塔城地区', '654200', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3199', '3103', '塔城市', '654201', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3200', '3103', '乌苏市', '654202', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3201', '3103', '额敏县', '654221', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3202', '3103', '沙湾县', '654223', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3203', '3103', '托里县', '654224', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3204', '3103', '裕民县', '654225', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3205', '3103', '和布克赛尔蒙古自治县', '654226', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3206', '3103', '阿勒泰地区', '654300', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3207', '3103', '阿勒泰市', '654301', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3208', '3103', '布尔津县', '654321', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3209', '3103', '富蕴县', '654322', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3210', '3103', '福海县', '654323', '0', '2018-10-30 16:31:48', '0', '2018-10-30 16:31:48', '0');
INSERT INTO `d_sys_area` VALUES ('3211', '3103', '哈巴河县', '654324', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3212', '3103', '青河县', '654325', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3213', '3103', '吉木乃县', '654326', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3214', '3103', '自治区直辖县级行政区划', '659000', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3215', '3103', '石河子市', '659001', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3216', '3103', '阿拉尔市', '659002', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3217', '3103', '图木舒克市', '659003', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3218', '3103', '五家渠市', '659004', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3219', '3103', '铁门关市', '659006', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3220', '0', '台湾省', '710000', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3221', '0', '香港特别行政区', '810000', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');
INSERT INTO `d_sys_area` VALUES ('3222', '0', '澳门特别行政区', '820000', '0', '2018-10-30 16:31:49', '0', '2018-10-30 16:31:49', '0');

-- ----------------------------
-- Table structure for d_sys_captcha
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_captcha`;
CREATE TABLE `d_sys_captcha` (
  `uuid` char(36) NOT NULL COMMENT 'uuid',
  `code` varchar(6) NOT NULL COMMENT '验证码',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统验证码';

-- ----------------------------
-- Records of d_sys_captcha
-- ----------------------------
INSERT INTO `d_sys_captcha` VALUES ('2d919b16-f6ca-47f7-8054-418a2aafaf4e', 'wedf3', '2020-09-01 14:30:59');
INSERT INTO `d_sys_captcha` VALUES ('3367955f-ada8-4486-8901-c4db3ab34659', 'ac5n8', '2020-08-24 17:49:49');
INSERT INTO `d_sys_captcha` VALUES ('66a1d099-3565-4375-872e-5dd5d51ee231', '3p4wp', '2020-08-25 09:12:34');
INSERT INTO `d_sys_captcha` VALUES ('66de3865-e7a1-4401-8940-1b92726c124f', 'n68c3', '2020-08-27 10:33:41');
INSERT INTO `d_sys_captcha` VALUES ('a91de9be-f86e-45a6-87ae-228ca0d36192', 'and4w', '2020-08-27 10:51:13');
INSERT INTO `d_sys_captcha` VALUES ('b94e58e9-27d7-420a-8c31-64006641664c', '5maee', '2020-09-01 14:08:28');
INSERT INTO `d_sys_captcha` VALUES ('fe2e0f86-7fd2-47a0-8296-751a22fd4db6', 'encbw', '2020-09-01 14:08:34');

-- ----------------------------
-- Table structure for d_sys_conf
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_conf`;
CREATE TABLE `d_sys_conf` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '编码',
  `value` varchar(64) NOT NULL DEFAULT '' COMMENT '值',
  `summary` varchar(128) NOT NULL DEFAULT '' COMMENT '简介',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公共管理-系统配置';

-- ----------------------------
-- Records of d_sys_conf
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_config
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_config`;
CREATE TABLE `d_sys_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `param_key` varchar(50) NOT NULL DEFAULT '' COMMENT 'key',
  `param_value` varchar(2000) NOT NULL DEFAULT '' COMMENT 'value',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0',
  `create_by` bigint(20) NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_by` bigint(20) NOT NULL DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_del` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统配置信息表';

-- ----------------------------
-- Records of d_sys_config
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_device
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_device`;
CREATE TABLE `d_sys_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `summary` varchar(128) NOT NULL DEFAULT '' COMMENT '简介',
  `icon` varchar(32) NOT NULL DEFAULT '' COMMENT '图标',
  `image` varchar(1024) NOT NULL DEFAULT '' COMMENT '示意图',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公共管理-设备类型';

-- ----------------------------
-- Records of d_sys_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_dict`;
CREATE TABLE `d_sys_dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父节点',
  `name` varchar(64) DEFAULT '' COMMENT '名称',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '编码',
  `value` varchar(64) NOT NULL DEFAULT '' COMMENT '值',
  `summary` varchar(1024) NOT NULL DEFAULT '' COMMENT '简介',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='公共管理-字典';

-- ----------------------------
-- Records of d_sys_dict
-- ----------------------------
INSERT INTO `d_sys_dict` VALUES ('1', '0', '性别', 'sex', '', '性别', '0', '2018-11-05 10:11:20', '0', '2018-11-05 10:11:20', '0');
INSERT INTO `d_sys_dict` VALUES ('2', '1', '女', '', '0', '女', '0', '2018-11-05 10:21:34', '0', '2018-11-05 10:21:34', '0');
INSERT INTO `d_sys_dict` VALUES ('3', '1', '男', '', '1', '', '0', '2018-11-05 10:22:29', '0', '2018-11-05 10:22:29', '0');
INSERT INTO `d_sys_dict` VALUES ('4', '0', '首页应用组', 'wapp_group', '', '', '0', '2018-11-05 10:37:08', '0', '2018-11-05 10:37:08', '0');
INSERT INTO `d_sys_dict` VALUES ('5', '4', '管理中心', '', '1', 'sys_manage', '0', '2018-11-05 10:37:25', '0', '2018-11-05 10:37:25', '0');
INSERT INTO `d_sys_dict` VALUES ('6', '4', '应用中心', '', '2', 'sys_application', '0', '2018-11-05 10:37:37', '0', '2018-11-05 10:37:37', '0');
INSERT INTO `d_sys_dict` VALUES ('7', '4', '设备中心', '', '3', 'sys_equipment', '0', '2018-11-05 10:37:49', '0', '2018-11-05 10:37:49', '0');
INSERT INTO `d_sys_dict` VALUES ('8', '0', '设备类型', 'device_group', '', '', '0', '2018-12-04 10:44:21', '0', '2018-12-04 10:44:21', '0');
INSERT INTO `d_sys_dict` VALUES ('9', '8', '人证机', '', '1', 'renzheng', '0', '2018-12-04 10:44:46', '0', '2018-12-04 10:44:46', '0');
INSERT INTO `d_sys_dict` VALUES ('10', '8', '门禁机', '', '2', 'menjin', '0', '2018-12-04 10:44:56', '0', '2018-12-04 10:44:56', '0');
INSERT INTO `d_sys_dict` VALUES ('11', '8', '考勤机', '', '3', 'kaoqin', '0', '2018-12-04 10:45:10', '0', '2018-12-04 10:45:10', '0');
INSERT INTO `d_sys_dict` VALUES ('12', '8', 'pad', '', '4', 'pad', '0', '2018-12-04 11:37:26', '0', '2018-12-04 11:37:26', '0');
INSERT INTO `d_sys_dict` VALUES ('13', '8', '大屏机', '', '5', 'daping', '0', '2018-12-04 11:37:42', '0', '2018-12-04 11:37:42', '0');
INSERT INTO `d_sys_dict` VALUES ('14', '8', '4g相机', '', '6', '4gcamera', '0', '2019-05-21 09:36:30', '0', '2019-05-21 09:36:30', '0');
INSERT INTO `d_sys_dict` VALUES ('15', '8', 'hik云相机', '', '80', 'hik-camera', '0', '2019-06-13 11:31:24', '0', '2019-06-13 11:31:24', '0');
INSERT INTO `d_sys_dict` VALUES ('16', '0', '不在岗原因', 'reason', '', '', '0', '2019-07-16 13:47:12', '0', '2019-07-16 13:47:12', '0');
INSERT INTO `d_sys_dict` VALUES ('17', '16', '事假', '', '1', '', '0', '2019-07-16 13:47:32', '0', '2019-07-16 13:47:32', '0');
INSERT INTO `d_sys_dict` VALUES ('18', '16', '病假', '', '2', '', '0', '2019-07-16 13:47:53', '0', '2019-07-16 13:47:53', '0');
INSERT INTO `d_sys_dict` VALUES ('19', '16', '出差', '', '3', '', '0', '2019-07-16 13:48:00', '0', '2019-07-16 13:48:00', '0');
INSERT INTO `d_sys_dict` VALUES ('20', '16', '带薪假', '', '4', '', '0', '2019-07-16 13:48:09', '0', '2019-07-16 13:48:09', '0');
INSERT INTO `d_sys_dict` VALUES ('21', '0', '到访事由', 'purpose', '', '访客事由', '0', '2019-10-12 10:42:27', '0', '2019-10-12 10:42:27', '0');
INSERT INTO `d_sys_dict` VALUES ('22', '21', '面试', '', '1', '', '0', '2019-10-12 10:44:45', '0', '2019-10-12 10:44:45', '0');
INSERT INTO `d_sys_dict` VALUES ('23', '21', '送水', '', '2', '', '0', '2019-10-12 10:45:57', '0', '2019-10-12 10:45:57', '0');
INSERT INTO `d_sys_dict` VALUES ('24', '21', '会议', '', '3', '', '0', '2019-10-12 10:46:18', '0', '2019-10-12 10:46:18', '0');
INSERT INTO `d_sys_dict` VALUES ('25', '21', '外卖', '', '4', '', '0', '2019-10-12 10:46:43', '0', '2019-10-12 10:46:43', '0');
INSERT INTO `d_sys_dict` VALUES ('26', '21', '快递物流', '', '5', '', '0', '2019-10-12 10:47:09', '0', '2019-10-12 10:47:09', '0');
INSERT INTO `d_sys_dict` VALUES ('27', '21', '维修', '', '6', '', '0', '2019-10-12 10:47:30', '0', '2019-10-12 10:47:30', '0');
INSERT INTO `d_sys_dict` VALUES ('28', '21', '清洁养护', '', '7', '', '0', '2019-10-12 10:47:50', '0', '2019-10-12 10:47:50', '0');
INSERT INTO `d_sys_dict` VALUES ('29', '21', '探望亲友', '', '8', '', '0', '2019-10-12 10:48:12', '0', '2019-10-12 10:48:12', '0');
INSERT INTO `d_sys_dict` VALUES ('30', '21', '办理业务', '', '9', '', '0', '2019-10-12 10:48:35', '0', '2019-10-12 10:48:35', '0');
INSERT INTO `d_sys_dict` VALUES ('31', '21', '其他', '', '99', '', '0', '2019-10-12 10:49:01', '0', '2019-10-12 10:49:01', '0');
INSERT INTO `d_sys_dict` VALUES ('32', '0', '设备厂商', 'manufacturer', '', '', '0', '2019-10-18 20:06:56', '0', '2019-10-18 20:06:56', '0');
INSERT INTO `d_sys_dict` VALUES ('33', '32', '澎思', '', '0', '', '0', '2019-10-18 20:07:14', '0', '2019-10-18 20:07:14', '0');
INSERT INTO `d_sys_dict` VALUES ('34', '0', ' 回调类型', 'callback', '', '', '0', '2019-10-19 11:45:54', '0', '2019-10-19 11:45:54', '0');
INSERT INTO `d_sys_dict` VALUES ('36', '34', ' 对比记录通知', '', 'compare_upload', '{ \"compareId\":\"154593954887381\", \"passTime\":\"时间戳\", \"sn\":\"设备序列号\", \"deviceType\":\"2\", \"deviceName\":\"设备名称\", \"capturePhoto\":\"抓拍url\", \"panoramaPhoto\":\"全景url\", \"name\":\"姓名\", \"sex\":\"0女 1男 2未知\", \"isPass\":\"1通过 2 不通过\", \"score\":\"53.354050000000001\", \"position\":\"南京\", \"status\":\"1 刷卡 2 刷脸 3 密码\", \"personType\":\"0 员工 1访客\", \"tenantId\":\"1123065425937043458\" }', '0', '2019-10-19 11:48:15', '0', '2019-10-19 11:48:15', '0');
INSERT INTO `d_sys_dict` VALUES ('37', '8', '访客机', '', '7', '', '0', '2019-10-22 14:33:03', '0', '2019-10-22 14:33:03', '0');
INSERT INTO `d_sys_dict` VALUES ('38', '0', '通行方式', 'modeofpassage', '', '', '0', '2019-11-27 09:47:01', '0', '2019-11-27 09:47:01', '0');
INSERT INTO `d_sys_dict` VALUES ('39', '38', '任意方式校验通过即可', '', '0', '', '0', '2019-11-27 09:51:31', '0', '2019-11-27 09:51:31', '0');
INSERT INTO `d_sys_dict` VALUES ('40', '38', '人脸和PIN码双重校验', '', '1', '', '0', '2019-11-27 09:51:56', '0', '2019-11-27 09:51:56', '0');
INSERT INTO `d_sys_dict` VALUES ('41', '38', '人脸和IC卡双重校验', '', '2', '', '0', '2019-11-27 09:52:19', '0', '2019-11-27 09:52:19', '0');
INSERT INTO `d_sys_dict` VALUES ('43', '0', '屏保分类', 'screenclassification', '', '', '0', '2019-12-17 10:20:20', '0', '2019-12-17 10:20:20', '0');
INSERT INTO `d_sys_dict` VALUES ('44', '43', '24节气', '', '1', '', '0', '2019-12-17 10:23:09', '0', '2019-12-17 10:23:09', '0');
INSERT INTO `d_sys_dict` VALUES ('45', '43', '节假日', '', '0', '', '0', '2019-12-19 09:33:19', '0', '2019-12-19 09:33:19', '0');

-- ----------------------------
-- Table structure for d_sys_holiday
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_holiday`;
CREATE TABLE `d_sys_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `year` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `month` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `day` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `summary` varchar(128) NOT NULL DEFAULT '' COMMENT '简介',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公共管理-法定节假日';

-- ----------------------------
-- Records of d_sys_holiday
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_log
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_log`;
CREATE TABLE `d_sys_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `time` bigint(20) NOT NULL COMMENT '执行时长(毫秒)',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统日志';

-- ----------------------------
-- Records of d_sys_log
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_menu`;
CREATE TABLE `d_sys_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父菜单ID，一级菜单为0',
  `wapp_id` bigint(20) DEFAULT NULL COMMENT '父级菜单ID',
  `name` varchar(50) DEFAULT NULL COMMENT '菜单名称',
  `url` varchar(200) DEFAULT NULL COMMENT '菜单URL',
  `perms` varchar(500) DEFAULT NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` int(11) DEFAULT NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(50) DEFAULT NULL COMMENT '菜单图标',
  `order_num` int(11) DEFAULT NULL COMMENT '排序',
  `visitable` int(1) DEFAULT NULL COMMENT '是否可见 0 显示 1隐藏',
  `is_independence` int(1) DEFAULT NULL COMMENT '是否是独立的页面 0: 是 1：否',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 COMMENT='菜单管理';

-- ----------------------------
-- Records of d_sys_menu
-- ----------------------------
INSERT INTO `d_sys_menu` VALUES ('1', '0', null, '管理中心', null, null, '0', 'sys_manage', '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('2', '1', '1064378603584548866', '系统账号', 'sys/user', null, '1', 'sys_account', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('3', '1', '1062948273161908226', '角色管理', 'sys/role', null, '1', 'role', '2', null, null);
INSERT INTO `d_sys_menu` VALUES ('4', '1', null, '菜单管理', 'sys/menu', null, '1', 'menu', '3', null, null);
INSERT INTO `d_sys_menu` VALUES ('5', '1', null, 'SQL监控', 'http://localhost:8032/terminal-admin/druid/sql.html', null, '1', 'sql', '4', null, null);
INSERT INTO `d_sys_menu` VALUES ('6', '1', null, '定时任务', 'job/schedule', null, '1', 'job', '5', null, null);
INSERT INTO `d_sys_menu` VALUES ('7', '6', null, '查看', null, 'sys:schedule:list,sys:schedule:info', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('8', '6', null, '新增', null, 'sys:schedule:save', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('9', '6', null, '修改', null, 'sys:schedule:update', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('10', '6', null, '删除', null, 'sys:schedule:delete', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('11', '6', null, '暂停', null, 'sys:schedule:pause', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('12', '6', null, '恢复', null, 'sys:schedule:resume', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('13', '6', null, '立即执行', null, 'sys:schedule:run', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('14', '6', null, '日志列表', null, 'sys:schedule:log', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('15', '2', null, '查看', null, 'sys:user:list,sys:user:info', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('16', '2', null, '新增', null, 'sys:user:save,sys:role:select', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('17', '2', null, '修改', null, 'sys:user:update,sys:role:select', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('18', '2', null, '删除', null, 'sys:user:delete', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('19', '3', null, '查看', null, 'sys:role:list,sys:role:info', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('20', '3', null, '新增', null, 'sys:role:save,sys:menu:list', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('21', '3', null, '修改', null, 'sys:role:update,sys:menu:list', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('22', '3', null, '删除', null, 'sys:role:delete', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('23', '4', null, '查看', null, 'sys:menu:list,sys:menu:info', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('24', '4', null, '新增', null, 'sys:menu:save,sys:menu:select', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('25', '4', null, '修改', null, 'sys:menu:update,sys:menu:select', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('26', '4', null, '删除', null, 'sys:menu:delete', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('27', '1', '1162263141718876161', '参数管理', 'sys/config', 'sys:config:list,sys:config:info,sys:config:save,sys:config:update,sys:config:delete', '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('29', '1', null, '系统日志', 'sys/log', 'sys:log:list', '1', 'log', '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('30', '1', null, '文件上传', 'oss/oss', 'sys:oss:all', '1', 'oss', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('31', '1', '1065799093087776770', '设备中心', 'tenant/device', null, '1', 'config', '6', '0', null);
INSERT INTO `d_sys_menu` VALUES ('32', '31', null, '查看', null, 'tenant:device:list,tenant:device:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('33', '31', null, '新增', null, 'tenant:device:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('34', '31', null, '修改', null, 'tenant:device:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('35', '31', null, '删除', null, 'tenant:device:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('42', '62', null, '查看', null, 'tenant:appview:list,tenant:appview:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('43', '62', null, '新增', null, 'tenant:appview:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('44', '62', null, '修改', null, 'tenant:appview:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('45', '62', null, '删除', null, 'tenant:appview:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('46', '0', null, '应用中心', null, null, '0', 'sys_application', '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('47', '0', null, '设备中心', null, null, '0', 'sys_equipment', '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('48', '46', null, '门禁授权', null, null, '1', 'sys_entrance', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('49', '46', null, '签到统计', null, null, '1', 'sys_signIn', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('50', '46', null, '抓拍详情', null, null, '1', 'sys_capture', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('51', '46', null, '考勤管理', null, null, '1', 'sys_Attendance', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('52', '46', null, '访客管理', null, null, '1', 'sys_visitor', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('53', '47', null, 'ow迎宾', null, null, '1', 'sys_owyb', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('54', '47', null, 'owpad', null, null, '1', 'sys_owpad', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('55', '47', null, '签到大屏', null, null, '0', 'sys_qddp', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('56', '47', null, '人证核验', null, null, '1', 'sys_rzhy', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('57', '47', null, '智慧门禁', '', null, '1', 'sys_xqmj', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('60', '1', null, '组织管理', '', null, '1', 'sys_moo', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('61', '1', null, '人员信息', null, null, '1', 'sys_pi', '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('62', '55', '1059642264534192130', 'APP界面', 'signin/appview', null, '1', 'config', '0', '0', null);
INSERT INTO `d_sys_menu` VALUES ('64', '55', '1059642264534192130', '模板管理', 'signin/seattemp', null, '1', 'config', '1', '0', null);
INSERT INTO `d_sys_menu` VALUES ('66', '64', null, '查看', null, 'app:seattemp:list,app:seattemp:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('67', '64', null, '新增', null, 'app:seattemp:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('68', '64', null, '修改', null, 'app:seattemp:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('69', '64', null, '删除', null, 'app:seattemp:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('70', '55', '1059642264534192130', '活动管理', 'signin/activity', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('71', '70', null, '查看', null, 'app:activity:list,app:activity:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('72', '70', null, '新增', null, 'app:activity:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('73', '70', null, '修改', null, 'app:activity:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('74', '70', null, '删除', null, 'app:activity:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('75', '55', '1059642264534192130', '添加活动人员', 'signin/activitysubject', 'app:activitysubject:list', '1', null, '0', '1', null);
INSERT INTO `d_sys_menu` VALUES ('82', '81', null, '查看', null, 'tenant:feature:list,tenant:feature:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('83', '81', null, '新增', null, 'tenant:feature:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('84', '81', null, '修改', null, 'tenant:feature:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('85', '81', null, '删除', null, 'tenant:feature:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('86', '75', null, '确定', null, 'app:activitysubject:save', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('87', '75', null, '删除', null, 'app:activitysubject:delete', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('88', '1', '1059636121808211969', '组织管理', 'tenant/dept', null, '1', 'config', '6', '0', null);
INSERT INTO `d_sys_menu` VALUES ('89', '88', null, '查看', null, 'tenant:dept:list,tenant:dept:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('90', '88', null, '新增', null, 'tenant:dept:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('91', '88', null, '修改', null, 'tenant:dept:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('92', '88', null, '删除', null, 'tenant:dept:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('93', '75', null, '参会人员分配', null, 'app:activitysubject:distribute', '2', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('95', '55', '1059642264534192130', '预览', 'signin/preview', null, '1', null, '0', '1', null);
INSERT INTO `d_sys_menu` VALUES ('96', '55', '1059642264534192130', '活动一览', 'signin/activityList', 'app:activity:list,app:activity:info', '1', null, '6', '0', null);
INSERT INTO `d_sys_menu` VALUES ('97', null, null, '查看', null, 'tenant:employee:list,tenant:employee:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('98', null, null, '新增', null, 'tenant:employee:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('99', null, null, '修改', null, 'tenant:employee:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('100', null, null, '删除', null, 'tenant:employee:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('101', '1', '1059637119087874049', '人员信息', 'sys/employee', null, '1', 'config', '6', '0', null);
INSERT INTO `d_sys_menu` VALUES ('102', '101', null, '查看', null, 'tenant:employee:list,tenant:employee:info,tenant:feature:list,tenant:feature:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('103', '101', null, '新增', null, 'tenant:employee:save,tenant:feature:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('104', '101', null, '修改', null, 'tenant:employee:update,tenant:feature:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('105', '101', null, '删除', null, 'tenant:employee:delete,tenant:feature:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('106', '55', '1059642264534192130', '基本设置', 'tenant/conf', 'tenant:conf:list,tenant:conf:info', '1', null, '6', '0', null);
INSERT INTO `d_sys_menu` VALUES ('107', '106', null, '新增', null, 'tenant:conf:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('108', '106', null, '修改', null, 'tenant:conf:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('109', '106', null, '删除', null, 'tenant:conf:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('110', '1', null, '签到统计', 'tenant/siginCount', null, '1', null, '0', null, null);
INSERT INTO `d_sys_menu` VALUES ('111', '110', '1068314328759705601', '签到统计', 'signin/activityRecord', null, '1', null, '1', '0', null);
INSERT INTO `d_sys_menu` VALUES ('112', '1', '1068315308955967489', '比中人员', 'tenant/employ-success', null, '1', null, '0', '1', null);
INSERT INTO `d_sys_menu` VALUES ('113', '1', '1068315308955967489', '未比中人员', 'tenant/stranger-compare', null, '1', null, '1', '1', null);
INSERT INTO `d_sys_menu` VALUES ('114', '1', '1066966567695118338', '抓拍记录', 'tenant/face', null, '1', null, '1', '1', null);
INSERT INTO `d_sys_menu` VALUES ('115', '1', '1068316382660042754', '比对信息', 'rzhy/compare-record', null, '1', null, '1', '1', null);
INSERT INTO `d_sys_menu` VALUES ('116', '114', null, '查看', null, 'face:compare:successList', '1', null, '1', '1', null);
INSERT INTO `d_sys_menu` VALUES ('117', '1', '1059637995911319553', '皮肤设计', 'guard/skin', null, '1', null, '1', '1', null);
INSERT INTO `d_sys_menu` VALUES ('118', '57', '1068316842959740930', '门禁授权组', 'app/authgroup', null, '1', 'config', '6', '1', null);
INSERT INTO `d_sys_menu` VALUES ('119', '118', null, '查看', null, 'app:authgroup:list,app:authgroup:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('120', '118', null, '新增', null, 'app:authgroup:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('121', '118', null, '修改', null, 'app:authgroup:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('122', '118', null, '删除', null, 'app:authgroup:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('123', '57', '1068316842959740930', '门禁设备', 'app/groupdevice', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('124', '123', null, '查看', null, 'app:groupdevice:list,app:groupdevice:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('125', '123', null, '新增', null, 'app:groupdevice:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('126', '123', null, '修改', null, 'app:groupdevice:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('127', '123', null, '删除', null, 'app:groupdevice:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('141', '1', null, '应用中心-开关组-人员', 'app/groupemployee', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('142', '141', null, '查看', null, 'app:groupemployee:list,app:groupemployee:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('143', '141', null, '新增', null, 'app:groupemployee:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('144', '141', null, '修改', null, 'app:groupemployee:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('145', '141', null, '删除', null, 'app:groupemployee:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('146', '52', '1068316663804239873', '访客管理', 'app/visitor', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('147', '146', null, '查看', null, 'app:visitor:list,app:visitor:info,app:visitordevice:list', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('148', '146', null, '新增', null, 'app:visitor:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('149', '146', null, '修改', null, 'app:visitor:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('150', '146', null, '删除', null, 'app:visitor:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('151', '52', '1068316663804239873', '访客统计', 'app/visitor-statistics', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('161', '52', null, '应用中心-访客-关联设备', 'app/visitordevice', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('162', '161', null, '查看', null, 'app:visitordevice:list,app:visitordevice:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('163', '161', null, '新增', null, 'app:visitordevice:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('164', '161', null, '修改', null, 'app:visitordevice:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('165', '161', null, '删除', null, 'app:visitordevice:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('166', '31', '1128944245701414913', '4G相机', 'device/camera', null, '1', null, '0', '1', null);
INSERT INTO `d_sys_menu` VALUES ('167', '57', '1068316842959740930', '上报人员', 'app/deviceemployee', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('170', '46', '1068884588548540930', '信息采集', 'app/appcollection', null, '1', 'config', '6', '1', null);
INSERT INTO `d_sys_menu` VALUES ('171', '170', null, '查看', null, 'tenant:appcollection:list,tenant:appcollection:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('172', '170', null, '新增', null, 'tenant:appcollection:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('173', '170', null, '修改', null, 'tenant:appcollection:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('174', '170', null, '删除', null, 'tenant:appcollection:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('175', '31', null, '租户-设备-配置', 'tenant/deviceconfigure', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('176', '175', null, '查看', null, 'tenant:deviceconfigure:list,tenant:deviceconfigure:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('177', '175', null, '新增', null, 'tenant:deviceconfigure:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('178', '175', null, '修改', null, 'tenant:deviceconfigure:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('179', '175', null, '删除', null, 'tenant:deviceconfigure:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('180', '51', '1068315776327262210', '节假日设定', 'app/attendanceholiday', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('181', '180', null, '查看', null, 'app:attendanceholiday:list,app:attendanceholiday:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('182', '180', null, '新增', null, 'app:attendanceholiday:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('183', '180', null, '修改', null, 'app:attendanceholiday:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('184', '180', null, '删除', null, 'app:attendanceholiday:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('185', '51', '1068315776327262210', '考勤班次', 'app/attendancetime', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('186', '185', null, '查看', null, 'app:attendancetime:list,app:attendancetime:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('187', '185', null, '新增', null, 'app:attendancetime:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('188', '185', null, '修改', null, 'app:attendancetime:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('189', '185', null, '删除', null, 'app:attendancetime:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('190', '51', '1068315776327262210', '考勤组', 'app/attendancegroup', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('191', '190', null, '查看', null, 'app:attendancegroup:list,app:attendancegroup:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('192', '190', null, '新增', null, 'app:attendancegroup:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('193', '190', null, '修改', null, 'app:attendancegroup:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('194', '190', null, '删除', null, 'app:attendancegroup:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('195', '51', '1068315776327262210', '考勤设备', 'app/attendancedevice', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('196', '195', null, '查看', null, 'app:attendancedevice:list,app:attendancedevice:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('197', '195', null, '新增', null, 'app:attendancedevice:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('198', '195', null, '修改', null, 'app:attendancedevice:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('199', '195', null, '删除', null, 'app:attendancedevice:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('200', '51', '1068315776327262210', '不在岗人员', 'app/attendancenotonsubject', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('201', '200', null, '查看', null, 'app:attendancenotonsubject:list,app:attendancenotonsubject:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('202', '200', null, '新增', null, 'app:attendancenotonsubject:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('203', '200', null, '修改', null, 'app:attendancenotonsubject:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('204', '200', null, '删除', null, 'app:attendancenotonsubject:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('205', '51', '1068315776327262210', '考勤统计', 'app/attendance', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('206', '205', null, '查看', null, 'app:attendance:list,app:attendance:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('207', '205', null, '新增', null, 'app:attendance:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('208', '205', null, '修改', null, 'app:attendance:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('209', '205', null, '删除', null, 'app:attendance:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('210', '51', null, '应用中心-考勤组-人员', 'app/attendancegroupsubject', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('211', '210', null, '查看', null, 'app:attendancegroupsubject:list,app:attendancegroupsubject:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('212', '210', null, '新增', null, 'app:attendancegroupsubject:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('213', '210', null, '修改', null, 'app:attendancegroupsubject:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('214', '210', null, '删除', null, 'app:attendancegroupsubject:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('215', '51', null, '应用中心-考勤组-班次', 'app/attendancegrouptime', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('216', '215', null, '查看', null, 'app:attendancegrouptime:list,app:attendancegrouptime:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('217', '215', null, '新增', null, 'app:attendancegrouptime:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('218', '215', null, '修改', null, 'app:attendancegrouptime:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('219', '215', null, '删除', null, 'app:attendancegrouptime:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('220', '31', null, '租户-设备-信息', 'tenant/deviceinfo', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('221', '220', null, '查看', null, 'tenant:deviceinfo:list,tenant:deviceinfo:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('222', '220', null, '新增', null, 'tenant:deviceinfo:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('223', '220', null, '修改', null, 'tenant:deviceinfo:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('224', '220', null, '删除', null, 'tenant:deviceinfo:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('225', '57', '1068316842959740930', '门禁屏保', 'app/groupdevice-appview', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('226', '46', null, '产品需求', null, null, '1', 'app_daping', '1', null, null);
INSERT INTO `d_sys_menu` VALUES ('227', '226', '1182917713719201794', '需求管理', 'app/demand', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('228', '227', null, '查看', null, 'app:demand:list,app:demand:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('229', '227', null, '新增', null, 'app:demand:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('230', '227', null, '修改', null, 'app:demand:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('231', '227', null, '删除', null, 'app:demand:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('232', '226', '1182917713719201794', '产品类别', 'app/productcategory', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('233', '232', null, '查看', null, 'app:productcategory:list,app:productcategory:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('234', '232', null, '新增', null, 'app:productcategory:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('235', '232', null, '修改', null, 'app:productcategory:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('236', '232', null, '删除', null, 'app:productcategory:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('237', '226', '1182917713719201794', '产品管理', 'app/product', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('238', '237', null, '查看', null, 'app:product:list,app:product:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('239', '237', null, '新增', null, 'app:product:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('240', '237', null, '修改', null, 'app:product:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('241', '237', null, '删除', null, 'app:product:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('242', '51', '1196714082460368897', '方案设置', 'programme/programme-setting', '', '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('243', '242', null, '查看', null, 'app:scheme:list,app:scheme:info,app:scheme:queryVoiceList,tenant:devicescheme:list,tenant:devicescheme:info,tenant:devicescheme:save,tenant:devicescheme:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('244', '242', null, '新增', null, 'app:scheme:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('245', '242', null, '修改', null, 'app:scheme:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('246', '242', null, '删除', null, 'app:scheme:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('247', '51', '1196714082460368897', '通行时间', 'programme/pass-time', 'tenant:accesstimetable:list,tenant:accesstimetable:info,tenant:accesstimetable:save,tenant:accesstimetable:update,tenant:accesstimetable:delete,tenant:accesstimetable:queryAllAccessModeList,tenant:devicetimetable:list,tenant:devicetimetable:delete', '1', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('248', '61', '1196714082460368898', '黑名单', 'app/blacklist', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('249', '248', null, '查看', null, 'app:blacklist:list,app:blacklist:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('250', '248', null, '新增', null, 'app:blacklist:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('251', '248', null, '修改', null, 'app:blacklist:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('252', '248', null, '删除', null, 'app:blacklist:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('253', '51', '1196714082460368897', '我的屏保方案', 'programme/doorguardscreen', null, '1', 'config', '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('254', '253', null, '查看', null, 'app:doorguarscreen:list,app:doorguarscreen:info,app:doorguarpicture:list,app:doorguarpicture:info,app:doorguarpicture:save,app:doorguarpicture:update,app:doorguarpicture:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('255', '253', null, '新增', null, 'app:doorguarscreen:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('256', '253', null, '修改', null, 'app:doorguarscreen:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('257', '253', null, '删除', null, 'app:doorguarscreen:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('258', '51', '1196714082460368897', '推荐屏保方案', 'programme/doorguardscreen-system', null, '1', 'config', '8', null, null);
INSERT INTO `d_sys_menu` VALUES ('259', '51', '1196714082460368897', '门禁设备组', 'tenant/devicegroup', null, '1', 'config', '9', null, null);
INSERT INTO `d_sys_menu` VALUES ('260', '259', null, '查看', null, 'tenant:devicegroup:list,tenant:devicegroup:info,tenant:devicegrouprel:list,tenant:devicegrouprel:info,tenant:devicegrouprel:save,tenant:devicegrouprel:update,tenant:devicegrouprel:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('261', '259', null, '新增', null, 'tenant:devicegroup:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('262', '259', null, '修改', null, 'tenant:devicegroup:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('263', '259', null, '删除', null, 'tenant:devicegroup:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('264', '61', '1196714082460368898', '黑名单组', 'app/blacklistgroup', null, '1', 'config', '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('265', '264', null, '查看', null, 'app:blacklistgroup:list,app:blacklistgroup:info,app:groupblacklist:list,app:groupblacklist:info', '2', null, '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('266', '264', null, '新增', null, 'app:blacklistgroup:save,app:groupblacklist:save', '2', null, '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('267', '264', null, '修改', null, 'app:blacklistgroup:update,app:groupblacklist:update', '2', null, '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('268', '264', null, '删除', null, 'app:blacklistgroup:delete,app:groupblacklist:delete', '2', null, '7', null, null);
INSERT INTO `d_sys_menu` VALUES ('269', '61', '1196714082460368898', '门禁设备', 'app/blackgroupdevice', null, '1', 'config', '8', null, null);
INSERT INTO `d_sys_menu` VALUES ('270', '269', null, '查看', null, 'app:groupdevice:list,app:groupdevice:info', '2', null, '8', null, null);
INSERT INTO `d_sys_menu` VALUES ('271', '269', null, '新增', null, 'app:groupdevice:save', '2', null, '8', null, null);
INSERT INTO `d_sys_menu` VALUES ('272', '269', null, '修改', null, 'app:groupdevice:update', '2', null, '8', null, null);
INSERT INTO `d_sys_menu` VALUES ('273', '269', null, '删除', null, 'app:groupdevice:delete', '2', null, '8', null, null);
INSERT INTO `d_sys_menu` VALUES ('274', '46', '1191917085139103746', '访客申请', 'app/visitorapply', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('275', '274', null, '查看', null, 'app:visitorapply:list,app:visitorapply:info', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('276', '274', null, '新增', null, 'app:visitorapply:save', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('277', '274', null, '修改', null, 'app:visitorapply:update', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('278', '274', null, '删除', null, 'app:visitorapply:delete', '2', null, '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('279', '46', '1196714082485121541', '实时监控', 'temperature/monitoring', null, '1', 'config', '6', null, null);
INSERT INTO `d_sys_menu` VALUES ('280', '46', '1196714082485121541', '测温历史', 'temperature/history', null, '1', 'config', '6', null, null);

-- ----------------------------
-- Table structure for d_sys_oss
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_oss`;
CREATE TABLE `d_sys_oss` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL COMMENT 'URL地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件上传';

-- ----------------------------
-- Records of d_sys_oss
-- ----------------------------

-- ----------------------------
-- Table structure for d_sys_user_token
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_user_token`;
CREATE TABLE `d_sys_user_token` (
  `user_id` bigint(20) NOT NULL,
  `token` varchar(100) NOT NULL COMMENT 'token',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `token` (`token`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统用户Token';

-- ----------------------------
-- Records of d_sys_user_token
-- ----------------------------
INSERT INTO `d_sys_user_token` VALUES ('1297836412240793601', 'c02048afa135336719eb9c4a85021af6', '2020-09-05 01:42:52', '2020-09-04 13:42:52');

-- ----------------------------
-- Table structure for d_sys_wapp
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_wapp`;
CREATE TABLE `d_sys_wapp` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '编码',
  `icon` varchar(32) NOT NULL DEFAULT '' COMMENT '图标',
  `uri` varchar(1024) NOT NULL DEFAULT '' COMMENT 'uri地址',
  `is_enable` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否启用（0：否 1：是）',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用类型',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  `is_independence` int(1) NOT NULL DEFAULT '0' COMMENT '是否是独立的页面 0: 是 1：否',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='公共管理-WEB-APP';

-- ----------------------------
-- Records of d_sys_wapp
-- ----------------------------
INSERT INTO `d_sys_wapp` VALUES ('1059636121808211969', '组织管理', 'dept', 'app_zuzhi', 'tenant/dept1', '1', '10', '1', '0', '2018-11-06 10:38:33', '0', '2018-11-06 10:38:33', '0', '0');
INSERT INTO `d_sys_wapp` VALUES ('1059637119087874049', '人员信息', 'employee', 'app_renyuan', 'sys/employee1', '1', '20', '1', '0', '2018-11-06 10:42:31', '0', '2018-11-06 10:42:31', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1059637995911319553', '门禁授权', 'app_auth', 'app_menjin', '/app/auth1', '1', '10', '2', '0', '2018-11-06 10:46:00', '0', '2018-11-06 10:46:00', '1', '1');
INSERT INTO `d_sys_wapp` VALUES ('1059639853069438977', 'ow迎宾', 'ow_camera', 'app_yingbin', '/device/camera1', '1', '10', '3', '0', '2018-11-06 10:53:23', '0', '2018-11-06 10:53:23', '1', '1');
INSERT INTO `d_sys_wapp` VALUES ('1059641900149837825', 'ow Pad', 'ow_pad', 'app_pad', '/device/pad1', '1', '20', '3', '0', '2018-11-06 11:01:31', '0', '2018-11-06 11:01:31', '1', '1');
INSERT INTO `d_sys_wapp` VALUES ('1059642264534192130', '签到大屏', 'sign', 'app_daping', '/device/sign1', '1', '30', '3', '0', '2018-11-06 11:02:58', '0', '2018-11-06 11:02:58', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1062948273161908226', '角色管理', 'role', 'app_fangke', 'sys/role1', '0', '40', '1', '0', '2018-11-15 13:59:51', '0', '2018-11-15 13:59:51', '0', '0');
INSERT INTO `d_sys_wapp` VALUES ('1064378603584548866', '系统账号', 'user', 'app_zhanghao', 'sys/user1', '0', '50', '1', '0', '2018-11-19 12:43:29', '0', '2018-11-19 12:43:29', '0', '0');
INSERT INTO `d_sys_wapp` VALUES ('1065799093087776770', '设备中心', 'device', 'app_daping', 'tenant/device1', '1', '60', '1', '0', '2018-11-23 10:48:00', '0', '2018-11-23 10:48:00', '0', '0');
INSERT INTO `d_sys_wapp` VALUES ('1066966567695118338', '抓拍记录', 'face', 'app_zhuapai', 'tenant/face1', '0', '70', '2', '0', '2018-11-26 16:07:08', '0', '2018-11-26 16:07:08', '0', '0');
INSERT INTO `d_sys_wapp` VALUES ('1068314328759705601', '签到统计', 'qiandao', 'app_qiandao', 'tenant/siginCount1', '1', '80', '2', '0', '2018-11-30 09:22:16', '0', '2018-11-30 09:22:16', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1068315308955967489', '抓拍详情', 'zhuapai', 'app_zhuapai', 'tenant/capture1', '1', '90', '2', '0', '2018-11-30 09:26:10', '0', '2018-11-30 09:26:10', '1', '1');
INSERT INTO `d_sys_wapp` VALUES ('1068315776327262210', '考勤管理', 'kaoqin', 'app_kaoqin', 'tenant/attence1', '1', '100', '2', '0', '2018-11-30 09:28:01', '0', '2018-11-30 09:28:01', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1068316382660042754', '人证核验', 'renzheng', 'app_renzheng', ' 人证 Witness1', '1', '110', '3', '0', '2018-11-30 09:30:26', '0', '2018-11-30 09:30:26', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1068316663804239873', '访客管理', 'fangke', 'app_fangke', 'tenant/visitor1', '1', '120', '2', '0', '2018-11-30 09:31:33', '0', '2018-11-30 09:31:33', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1068316842959740930', '智慧门禁', 'xiaoqu', 'app_xiaoqu', 'tenant/xiaoqu1', '1', '130', '3', '0', '2018-11-30 09:32:15', '0', '2018-11-30 09:32:15', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1128944245701414913', '4G相机', '4gcamera', 'app_4gcamera', 'device/camera', '1', '140', '3', '0', '2019-05-16 16:44:18', '0', '2019-05-16 16:44:18', '0', '0');
INSERT INTO `d_sys_wapp` VALUES ('1162263141718876161', '参数管理', 'configure', 'app_zuzhi', 'sys/configure', '1', '150', '1', '0', '2019-08-20 09:31:01', '0', '2019-08-20 09:31:01', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1182917713719201794', '产品需求', 'product', 'app_daping', 'app/product', '1', '160', '2', '0', '2019-10-12 15:15:35', '0', '2019-10-12 15:15:35', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1191917085139103746', '申请审批', 'audit', 'app_renyuan', 'app/audit', '1', '100', '2', '0', '2019-11-06 11:15:53', '0', '2019-11-06 11:15:53', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1196714082460368897', '方案设置', 'programme', 'app_zhanghao', 'programme/programme-setting', '1', '110', '2', '0', '2019-11-19 16:57:25', '0', '2019-11-19 16:57:25', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1196714082460368898', '黑名单管理', 'blacklist', 'app_xiaoqu', 'app/blacklist', '1', '120', '2', '0', '2019-11-19 16:57:25', '0', '2019-11-19 16:57:25', '0', '1');
INSERT INTO `d_sys_wapp` VALUES ('1196714082485121541', '体温监控', 'temperature', 'app_renyuan', 'temperature/monitoring', '1', '120', '2', '0', '2020-02-26 14:10:14', '0', '2020-02-26 14:10:14', '0', '1');

-- ----------------------------
-- Table structure for d_tenant
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant`;
CREATE TABLE `d_tenant` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'UUID主键',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT '名称',
  `alias` varchar(32) NOT NULL DEFAULT '' COMMENT '别名（简称）',
  `logo` varchar(1024) NOT NULL DEFAULT '' COMMENT 'logo',
  `area_id` int(11) NOT NULL DEFAULT '0' COMMENT '区域ID（外键）',
  `contact` varchar(20) NOT NULL DEFAULT '' COMMENT '联系人',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '联系电话',
  `address` varchar(1024) NOT NULL DEFAULT '' COMMENT '联系地址',
  `tenant_qr_image` varchar(64) NOT NULL DEFAULT '' COMMENT '小程序码，扫码添加访客使用',
  `qr_code` varchar(64) DEFAULT '' COMMENT '企业邀约码',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  `is_push` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否默认推送默认屏保（0-推送，1-不推送）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1297836259400355843 DEFAULT CHARSET=utf8 COMMENT='管理中心-租户管理';

-- ----------------------------
-- Records of d_tenant
-- ----------------------------
INSERT INTO `d_tenant` VALUES ('1297836259400355842', '默认机构', '', '', '0', '', '', '', '', null, '1', '2020-08-24 18:01:12', '1', '2020-08-24 18:01:12', '0', '0');

-- ----------------------------
-- Table structure for d_tenant_access_timetable
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_access_timetable`;
CREATE TABLE `d_tenant_access_timetable` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '时刻表名称',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '时刻表类型(0-星期，1-工作/节假日)',
  `timetable_data` text NOT NULL,
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户Id',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-通行时刻表';

-- ----------------------------
-- Records of d_tenant_access_timetable
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_alarm
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_alarm`;
CREATE TABLE `d_tenant_alarm` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `contrast_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '比对记录ID（外键）',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '姓名',
  `person_id` varchar(20) NOT NULL DEFAULT '' COMMENT '身份证号',
  `repository_id` int(11) NOT NULL DEFAULT '0' COMMENT '底库ID',
  `repository_image` varchar(1024) NOT NULL DEFAULT '' COMMENT '底库图片',
  `alarm_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '告警时间',
  `score` double NOT NULL DEFAULT '0' COMMENT '分数',
  `is_card_alarm` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否身份证告警',
  `is_capture_alarm` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否人脸库告警',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `device_name` varchar(64) NOT NULL DEFAULT '' COMMENT '设备名',
  `longitude` double NOT NULL DEFAULT '0' COMMENT '经度',
  `latitude` double NOT NULL DEFAULT '0' COMMENT '纬度',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '部署点位',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  `sex` tinyint(4) NOT NULL COMMENT '性别（0：女 1：男）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-告警记录';

-- ----------------------------
-- Records of d_tenant_alarm
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_app_collection
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_app_collection`;
CREATE TABLE `d_tenant_app_collection` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `photo` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `telphone` varchar(64) NOT NULL DEFAULT '' COMMENT '版本',
  `ip` varchar(64) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态（0：待审核 1：审核通过 2：审核不通过）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-APP-自定义界面';

-- ----------------------------
-- Records of d_tenant_app_collection
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_app_view
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_app_view`;
CREATE TABLE `d_tenant_app_view` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `device_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '设备类型',
  `app_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'App ID（外键）',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `version` varchar(64) NOT NULL DEFAULT '' COMMENT '版本',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '标题',
  `logo` varchar(1024) NOT NULL DEFAULT '' COMMENT 'logo',
  `param1` varchar(1024) DEFAULT '' COMMENT '其他参数',
  `param2` varchar(1024) DEFAULT '' COMMENT '其他参数',
  `param3` varchar(1024) DEFAULT '' COMMENT '其他参数',
  `param4` varchar(1024) DEFAULT '' COMMENT '其他参数',
  `param5` varchar(1024) DEFAULT '' COMMENT '其他参数',
  `tenant_id` bigint(20) DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-APP-自定义界面';

-- ----------------------------
-- Records of d_tenant_app_view
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_app_view_device_rel
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_app_view_device_rel`;
CREATE TABLE `d_tenant_app_view_device_rel` (
  `app_view_id` varchar(64) NOT NULL DEFAULT '' COMMENT '皮肤id（外键）',
  `device_id` varchar(64) NOT NULL DEFAULT '' COMMENT '设备id（外键）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='皮肤与设备对应关系';

-- ----------------------------
-- Records of d_tenant_app_view_device_rel
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_compare
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_compare`;
CREATE TABLE `d_tenant_compare` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `feature_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '特征ID（外键）',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '姓名',
  `sex` tinyint(4) NOT NULL DEFAULT '0' COMMENT '性别（0：女 1：男）',
  `dept_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '机构ID（外键）',
  `dept_name` varchar(64) NOT NULL DEFAULT '' COMMENT '机构名',
  `person_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '人员类型（0：员工 1：访客）',
  `comp_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '比对时间',
  `is_pass` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否通过（1：是 0：否）',
  `score` double NOT NULL DEFAULT '0' COMMENT '分数',
  `quality` double NOT NULL DEFAULT '0' COMMENT '人脸质量',
  `photo` varchar(1024) NOT NULL DEFAULT '' COMMENT '人脸照片',
  `capture` varchar(1024) NOT NULL DEFAULT '' COMMENT '抓拍图',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `device_name` varchar(64) NOT NULL DEFAULT '' COMMENT '设备名',
  `longitude` double NOT NULL DEFAULT '0' COMMENT '经度',
  `latitude` double NOT NULL DEFAULT '0' COMMENT '纬度',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '部署点位',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-比对记录';

-- ----------------------------
-- Records of d_tenant_compare
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_conf
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_conf`;
CREATE TABLE `d_tenant_conf` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '编码',
  `value` varchar(64) NOT NULL DEFAULT '' COMMENT '值',
  `summary` varchar(128) NOT NULL DEFAULT '' COMMENT '简介',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-租户配置';

-- ----------------------------
-- Records of d_tenant_conf
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_contrast
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_contrast`;
CREATE TABLE `d_tenant_contrast` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '姓名',
  `sex` tinyint(4) NOT NULL DEFAULT '0' COMMENT '性别（0：女 1：男）',
  `score` double NOT NULL DEFAULT '0' COMMENT '分数',
  `quality` double NOT NULL DEFAULT '0' COMMENT '人脸质量',
  `photo` varchar(1024) NOT NULL DEFAULT '' COMMENT '人脸照片',
  `capture` varchar(1024) NOT NULL DEFAULT '' COMMENT '抓拍图',
  `birth_date` varchar(20) NOT NULL DEFAULT '' COMMENT '出生年月日',
  `home_address` varchar(255) NOT NULL DEFAULT '' COMMENT '家庭住址',
  `person_id` varchar(20) NOT NULL DEFAULT '' COMMENT '身份证号',
  `organs` varchar(64) NOT NULL DEFAULT '' COMMENT '颁发组织机构',
  `start_date` varchar(20) NOT NULL DEFAULT '' COMMENT '证件有效日期',
  `expiration_date` varchar(20) NOT NULL DEFAULT '' COMMENT '证件有效日期',
  `nation` varchar(20) NOT NULL DEFAULT '' COMMENT '民族',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID（外键）',
  `device_name` varchar(64) NOT NULL DEFAULT '' COMMENT '设备名',
  `longitude` double NOT NULL DEFAULT '0' COMMENT '经度',
  `latitude` double NOT NULL DEFAULT '0' COMMENT '纬度',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '部署点位',
  `comp_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '比对时间',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-1V1比对记录';

-- ----------------------------
-- Records of d_tenant_contrast
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_dept
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_dept`;
CREATE TABLE `d_tenant_dept` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `pid` bigint(20) NOT NULL DEFAULT '0' COMMENT '父节点',
  `pid_name` varchar(64) DEFAULT NULL COMMENT '父节点名称',
  `area_code_ids` varchar(100) DEFAULT NULL COMMENT '区域文本id',
  `area_codes` varchar(100) DEFAULT '' COMMENT '区域文本',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `alias` varchar(32) NOT NULL DEFAULT '' COMMENT '别名（简称）',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理中心-机构管理';

-- ----------------------------
-- Records of d_tenant_dept
-- ----------------------------
INSERT INTO `d_tenant_dept` VALUES ('1297836259580710914', '0', '1', '110000,110100,110101', '北京市,市辖区,东城区', '1', '', '0', '', '1297836259400355842', '0', '2020-08-24 18:01:12', '0', '2020-08-24 18:01:12', '0');

-- ----------------------------
-- Table structure for d_tenant_device
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device`;
CREATE TABLE `d_tenant_device` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `device_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '设备类型',
  `manufacturer` tinyint(2) DEFAULT '0' COMMENT '(0:彭思)',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `sn` varchar(64) NOT NULL DEFAULT '' COMMENT 'S/N码',
  `mac` char(64) NOT NULL DEFAULT '' COMMENT 'mac地址',
  `url` varchar(1024) NOT NULL DEFAULT '' COMMENT 'url地址',
  `second_url` varchar(1024) NOT NULL DEFAULT '' COMMENT '备用地址',
  `longitude` double NOT NULL DEFAULT '0' COMMENT '经度',
  `latitude` double NOT NULL DEFAULT '0' COMMENT '纬度',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '部署点位',
  `auth_begin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '授权开始时间',
  `auth_over` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '授权结束时间',
  `last_on_line_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后一次在线时间',
  `on_line_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0:不在线 1：在线',
  `qr_code` varchar(64) NOT NULL DEFAULT '' COMMENT '小程序码',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态（0：未启用 1：使用中 2：授权逾期）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-设备中心';

-- ----------------------------
-- Records of d_tenant_device
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_configure
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_configure`;
CREATE TABLE `d_tenant_device_configure` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备id',
  `compare_threshold` float NOT NULL DEFAULT '0' COMMENT '比对阈值',
  `quality_threshold` float NOT NULL DEFAULT '0' COMMENT '质量阈值',
  `face_alive_threshold` float NOT NULL DEFAULT '0' COMMENT '活体阈值',
  `auto_upgrade` int(4) NOT NULL DEFAULT '0' COMMENT '是否自动更新（0 否  1是）',
  `face_alive_check` int(4) NOT NULL DEFAULT '0' COMMENT '是否开启活体检测 （0 否 1 是）',
  `param5` varchar(128) NOT NULL DEFAULT '',
  `param6` varchar(128) NOT NULL DEFAULT '',
  `param7` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-设备-配置';

-- ----------------------------
-- Records of d_tenant_device_configure
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_dept
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_dept`;
CREATE TABLE `d_tenant_device_dept` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) DEFAULT NULL COMMENT '设备ID',
  `dept_id` bigint(20) DEFAULT NULL COMMENT '部门ID',
  `tenant_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备授权';

-- ----------------------------
-- Records of d_tenant_device_dept
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_doc
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_doc`;
CREATE TABLE `d_tenant_device_doc` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT '类型',
  `file` varchar(64) NOT NULL DEFAULT '' COMMENT '文件',
  `summary` varchar(128) NOT NULL DEFAULT '' COMMENT '简介',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备使用说明';

-- ----------------------------
-- Records of d_tenant_device_doc
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_doorguard_screen
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_doorguard_screen`;
CREATE TABLE `d_tenant_device_doorguard_screen` (
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID',
  `doorguard_screen_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '门禁屏保id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of d_tenant_device_doorguard_screen
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_group
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_group`;
CREATE TABLE `d_tenant_device_group` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-设备组';

-- ----------------------------
-- Records of d_tenant_device_group
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_group_rel
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_group_rel`;
CREATE TABLE `d_tenant_device_group_rel` (
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '授权组ID（外键）',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-设备组-设备';

-- ----------------------------
-- Records of d_tenant_device_group_rel
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_info
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_info`;
CREATE TABLE `d_tenant_device_info` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备id',
  `app_ver` varchar(64) NOT NULL DEFAULT '0' COMMENT '软件版本code',
  `app_ver_name` varchar(128) NOT NULL DEFAULT '' COMMENT '软件版本name',
  `dev_rom_full` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备总容量',
  `dev_rom_free` bigint(20) NOT NULL DEFAULT '0' COMMENT '可用空间',
  `online_user_num` int(9) NOT NULL DEFAULT '0' COMMENT '推送用户数量',
  `offline_user_num` int(9) NOT NULL DEFAULT '0' COMMENT '本地录入用户数量',
  `guard_password` varchar(64) NOT NULL DEFAULT '' COMMENT '门禁密码',
  `manager_password` varchar(64) NOT NULL DEFAULT '' COMMENT '管理员密码',
  `sys_version` varchar(64) NOT NULL DEFAULT '' COMMENT '系统版本',
  `device_ip` varchar(64) NOT NULL DEFAULT '' COMMENT '设备ip',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-设备-信息';

-- ----------------------------
-- Records of d_tenant_device_info
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_scheme
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_scheme`;
CREATE TABLE `d_tenant_device_scheme` (
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备ID',
  `scheme_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '方案ID',
  `person_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '人员类型（0：员工 1：访客 2未识别人员 ）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-设备中心-方案';

-- ----------------------------
-- Records of d_tenant_device_scheme
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_device_timetable
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_device_timetable`;
CREATE TABLE `d_tenant_device_timetable` (
  `timetable_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '出入时刻表id',
  `device_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '设备id',
  `timetable_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '时刻表类型 0 星期 1 工作日'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-设备中心-时刻表';

-- ----------------------------
-- Records of d_tenant_device_timetable
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_doorguard_screen
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_doorguard_screen`;
CREATE TABLE `d_tenant_doorguard_screen` (
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户id',
  `doorguard_screen_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '屏保id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-默认屏保';

-- ----------------------------
-- Records of d_tenant_doorguard_screen
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_employee
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_employee`;
CREATE TABLE `d_tenant_employee` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `feature_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '特征ID（外键）',
  `dept_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '机构ID（外键）',
  `duty_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '职务ID（外键）',
  `job_no` varchar(32) NOT NULL DEFAULT '' COMMENT '工号',
  `IC_card` varchar(64) NOT NULL DEFAULT '' COMMENT 'IC卡',
  `ID_card` varchar(64) NOT NULL DEFAULT '' COMMENT 'ID卡',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-员工';

-- ----------------------------
-- Records of d_tenant_employee
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_employee_mark
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_employee_mark`;
CREATE TABLE `d_tenant_employee_mark` (
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）',
  `mark_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '标签ID（外键）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-人员-标签';

-- ----------------------------
-- Records of d_tenant_employee_mark
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_feature
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_feature`;
CREATE TABLE `d_tenant_feature` (
  `id` bigint(20) NOT NULL COMMENT 'UUID主键',
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT 'SDK groupID',
  `face_id` varchar(24) NOT NULL DEFAULT '' COMMENT '人像ID',
  `th_feature` longblob COMMENT '前端比对特征值',
  `finger_print` longblob COMMENT '指纹',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `photo` varchar(1024) NOT NULL DEFAULT '' COMMENT '照片',
  `card_photo_md5` varchar(64) DEFAULT '' COMMENT '身份证图片MD5',
  `id_number` varchar(64) DEFAULT '' COMMENT '身份证号',
  `sex` tinyint(4) NOT NULL DEFAULT '2' COMMENT '性别（0：女 1：男 2：未知）',
  `person_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '人员类型（0：员工 1：访客  2:设备上报人员  99 黑名单）',
  `phone` varchar(64) NOT NULL DEFAULT '' COMMENT '手机',
  `open_id` varchar(64) DEFAULT '' COMMENT '通行管理的openId',
  `open_id2` varchar(64) DEFAULT '' COMMENT '智慧通行的 openId',
  `system_time` bigint(20) DEFAULT '0' COMMENT '时间戳',
  `qr_code` varchar(64) DEFAULT '' COMMENT '用户小程序码',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-特征';

-- ----------------------------
-- Records of d_tenant_feature
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_group
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_group`;
CREATE TABLE `d_tenant_group` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '底库ID',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-底库';

-- ----------------------------
-- Records of d_tenant_group
-- ----------------------------
INSERT INTO `d_tenant_group` VALUES ('1297836259748483074', '1', '1', '1297836259400355842', '0', '2020-08-24 18:01:12', '0', '2020-08-24 18:01:12', '0');

-- ----------------------------
-- Table structure for d_tenant_holiday
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_holiday`;
CREATE TABLE `d_tenant_holiday` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `year` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `month` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `day` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `summary` varchar(128) NOT NULL DEFAULT '' COMMENT '简介',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-租户节假日';

-- ----------------------------
-- Records of d_tenant_holiday
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_lock
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_lock`;
CREATE TABLE `d_tenant_lock` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '部署点位',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '协议类型（0：UDP 1:TCP）',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '启用状态（0：否 1：是）',
  `begin_time` time NOT NULL DEFAULT '00:00:00' COMMENT '开始时间',
  `over_time` time NOT NULL DEFAULT '00:00:00' COMMENT '结束时间',
  `valid_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '有效状态（0：全年有效 1：仅工作日有效 ）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-网络开关';

-- ----------------------------
-- Records of d_tenant_lock
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_mark
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_mark`;
CREATE TABLE `d_tenant_mark` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-标签';

-- ----------------------------
-- Records of d_tenant_mark
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_outduty
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_outduty`;
CREATE TABLE `d_tenant_outduty` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `employee_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '员工ID（外键）',
  `dept_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '机构ID（外键）',
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '结束时间',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '不在岗类型',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤-不在岗';

-- ----------------------------
-- Records of d_tenant_outduty
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_role
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_role`;
CREATE TABLE `d_tenant_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `tenant_id` bigint(20) NOT NULL COMMENT '租户id',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1297836259727511554 DEFAULT CHARSET=utf8 COMMENT='角色';

-- ----------------------------
-- Records of d_tenant_role
-- ----------------------------
INSERT INTO `d_tenant_role` VALUES ('1297836259727511553', '初始管理员', null, '1297836259400355842', '1', '2020-08-24 18:00:52');

-- ----------------------------
-- Table structure for d_tenant_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_role_dept`;
CREATE TABLE `d_tenant_role_dept` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `dept_id` bigint(20) DEFAULT NULL COMMENT '部门ID',
  `tenant_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色与部门对应关系';

-- ----------------------------
-- Records of d_tenant_role_dept
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_role_menu`;
CREATE TABLE `d_tenant_role_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `menu_id` bigint(20) DEFAULT NULL COMMENT '菜单ID',
  `tenant_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色与菜单对应关系';

-- ----------------------------
-- Records of d_tenant_role_menu
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_role_wapp
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_role_wapp`;
CREATE TABLE `d_tenant_role_wapp` (
  `id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '角色ID（外键）',
  `wapp_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'WebApp ID（外键）',
  `tenant_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-角色授权wapp';

-- ----------------------------
-- Records of d_tenant_role_wapp
-- ----------------------------
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894116225026', '1297836259727511553', '1059636121808211969', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894120419329', '1297836259727511553', '1059637119087874049', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894120419330', '1297836259727511553', '1062948273161908226', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894124613633', '1297836259727511553', '1064378603584548866', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894124613634', '1297836259727511553', '1065799093087776770', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894128807938', '1297836259727511553', '1066966567695118338', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894128807939', '1297836259727511553', '1068315308955967489', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894128807940', '1297836259727511553', '1068315776327262210', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894128807941', '1297836259727511553', '1068316663804239873', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894133002241', '1297836259727511553', '1068316842959740930', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894133002242', '1297836259727511553', '1196714082460368897', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894133002243', '1297836259727511553', '1196714082460368898', '1297836259400355842');
INSERT INTO `d_tenant_role_wapp` VALUES ('1301704894133002244', '1297836259727511553', '1196714082485121541', '1297836259400355842');

-- ----------------------------
-- Table structure for d_tenant_unlock_record
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_unlock_record`;
CREATE TABLE `d_tenant_unlock_record` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `compare_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '比对记录ID（外键）',
  `lock_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '开关ID（外键）',
  `lock_name` varchar(64) NOT NULL DEFAULT '' COMMENT '开关名',
  `position` varchar(256) NOT NULL DEFAULT '' COMMENT '部署点位',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-开锁记录';

-- ----------------------------
-- Records of d_tenant_unlock_record
-- ----------------------------

-- ----------------------------
-- Table structure for d_tenant_user
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_user`;
CREATE TABLE `d_tenant_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `password` varchar(100) DEFAULT NULL COMMENT '密码',
  `dept_id` bigint(20) NOT NULL COMMENT '部门id',
  `salt` varchar(20) DEFAULT NULL COMMENT '盐',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) DEFAULT NULL COMMENT '手机号',
  `qr_image` varchar(64) DEFAULT '' COMMENT '小程序码图片',
  `open_id` varchar(64) DEFAULT '' COMMENT '微信小程序openId',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `tenant_id` bigint(20) NOT NULL COMMENT '租户id',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_admin` int(1) NOT NULL COMMENT '是否为租户管理员 0 是 1 不是',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1297836412240793602 DEFAULT CHARSET=utf8 COMMENT='系统用户';

-- ----------------------------
-- Records of d_tenant_user
-- ----------------------------
INSERT INTO `d_tenant_user` VALUES ('1297836412240793601', 'admin', 'admin', '7bd08cbec23889c570fae76f2780d1423bad685e30e0227367872f78f83a8fa6', '1297836259580710914', 'a2tGluXEEMdAGvsoy8wC', 'admin@admin.com', '18888888888', '', null, '1', '1297836259400355842', '1', '2020-08-24 18:01:28', '0');

-- ----------------------------
-- Table structure for d_tenant_user_role
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_user_role`;
CREATE TABLE `d_tenant_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `tenant_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1300609172620918787 DEFAULT CHARSET=utf8 COMMENT='用户与角色对应关系';

-- ----------------------------
-- Records of d_tenant_user_role
-- ----------------------------
INSERT INTO `d_tenant_user_role` VALUES ('1300609172620918786', '1297836412240793601', '1297836259727511553', null);

-- ----------------------------
-- Table structure for d_tenant_wapp
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_wapp`;
CREATE TABLE `d_tenant_wapp` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `wapp_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'WebApp ID（外键）',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租户-web-App';

-- ----------------------------
-- Records of d_tenant_wapp
-- ----------------------------
INSERT INTO `d_tenant_wapp` VALUES ('1301704893872955394', '1059636121808211969', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893881344002', '1059637119087874049', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893881344003', '1062948273161908226', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893885538305', '1064378603584548866', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893885538306', '1065799093087776770', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893889732610', '1066966567695118338', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893889732611', '1068315308955967489', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893893926913', '1068315776327262210', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893898121218', '1068316663804239873', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893898121219', '1068316842959740930', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893902315521', '1196714082460368897', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893902315522', '1196714082460368898', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');
INSERT INTO `d_tenant_wapp` VALUES ('1301704893902315523', '1196714082485121541', '1297836259400355842', '0', '2020-09-04 10:13:51', '0', '2020-09-04 10:13:51', '0');

-- ----------------------------
-- Table structure for d_tenant_work_time
-- ----------------------------
DROP TABLE IF EXISTS `d_tenant_work_time`;
CREATE TABLE `d_tenant_work_time` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'UUID主键',
  `begin_time` time NOT NULL DEFAULT '00:00:00' COMMENT '开始时间',
  `over_time` time NOT NULL DEFAULT '00:00:00' COMMENT '结束时间',
  `final_time` time NOT NULL DEFAULT '00:00:00' COMMENT '最终时间',
  `tenant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '租户ID（外键）',
  `create_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新者',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除（0：显示；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用中心-考勤-上下班时间';

-- ----------------------------
-- Records of d_tenant_work_time
-- ----------------------------

-- ----------------------------
-- Table structure for sys_captcha
-- ----------------------------
DROP TABLE IF EXISTS `sys_captcha`;
CREATE TABLE `sys_captcha` (
  `uuid` char(36) NOT NULL COMMENT 'uuid',
  `code` varchar(6) NOT NULL COMMENT '验证码',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统验证码';

-- ----------------------------
-- Records of sys_captcha
-- ----------------------------
INSERT INTO `sys_captcha` VALUES ('66813303-3715-448a-8df5-17aa6af45f09', 'xff46', '2020-08-24 17:53:55');
INSERT INTO `sys_captcha` VALUES ('79aeb919-b8a5-468c-8ab2-5494379d0e3e', 'm5g5f', '2020-09-01 11:56:30');
INSERT INTO `sys_captcha` VALUES ('851ed15d-88cc-495e-86ba-ad5f6af19e31', 'nn7mb', '2020-08-24 17:51:04');
INSERT INTO `sys_captcha` VALUES ('c7f2704e-6b3d-465a-8cc8-85b0f42ba3d8', 'a4y48', '2020-09-04 10:12:25');
INSERT INTO `sys_captcha` VALUES ('f0a8b875-75df-4e01-810d-95630fc75cb0', '5b66p', '2020-08-24 17:50:04');
INSERT INTO `sys_captcha` VALUES ('f370dd0f-2d2f-4356-8b32-44454142095b', '37fxw', '2020-08-27 10:14:41');

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `param_key` varchar(50) DEFAULT NULL COMMENT 'key',
  `param_value` varchar(2000) DEFAULT NULL COMMENT 'value',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态   0：隐藏   1：显示',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `param_key` (`param_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统配置信息表';

-- ----------------------------
-- Records of sys_config
-- ----------------------------

-- ----------------------------
-- Table structure for sys_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `time` bigint(20) NOT NULL COMMENT '执行时长(毫秒)',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 COMMENT='系统日志';

-- ----------------------------
-- Records of sys_log
-- ----------------------------
INSERT INTO `sys_log` VALUES ('217', 'admin', '保存用户', 'com.cimevue.cloud.terminal.modules.tenant.TenantUserController.save()', '[{\"userId\":1297836412240793601,\"username\":\"1\",\"password\":\"0312f51bad823ad3772199adb6a2f3e7318993db2e7be061cfe28cccd75b950a\",\"salt\":\"a2tGluXEEMdAGvsoy8wC\",\"email\":\"1@1.com\",\"mobile\":\"18556885471\",\"status\":1,\"roleIdList\":[1297836259727511553],\"createUserId\":1,\"createTime\":\"Aug 24, 2020 6:01:27 PM\",\"tenantId\":1297836259400355842,\"name\":\"1\",\"deptId\":1297836259580710914,\"isAdmin\":0}]', '457', '10.10.1.18', '2020-08-24 18:01:29');
INSERT INTO `sys_log` VALUES ('218', 'admin', '修改用户', 'com.cimevue.cloud.terminal.modules.tenant.TenantUserController.update()', '[{\"userId\":1297836412240793601,\"username\":\"admin\",\"password\":\"843dd5e77310635a8e403d690056ffa3ede3b873517e451ea4294849c1a26670\",\"salt\":\"a2tGluXEEMdAGvsoy8wC\",\"email\":\"admin@admin.com\",\"mobile\":\"18888888888\",\"status\":1,\"roleIdList\":[1297836259727511553],\"createUserId\":1,\"tenantId\":1297836259400355842,\"name\":\"admin\",\"isAdmin\":0}]', '262', '0:0:0:0:0:0:0:1', '2020-08-27 10:12:40');
INSERT INTO `sys_log` VALUES ('219', 'admin', '修改用户', 'com.cimevue.cloud.terminal.modules.tenant.TenantUserController.update()', '[{\"userId\":1297836412240793601,\"username\":\"admin\",\"password\":\"b0af01d5a76c541afb5eb1933be0a86be18593bbf5433188eb47a7579e7595c2\",\"salt\":\"a2tGluXEEMdAGvsoy8wC\",\"email\":\"admin@admin.com\",\"mobile\":\"18888888888\",\"status\":1,\"roleIdList\":[1297836259727511553],\"createUserId\":1,\"tenantId\":1297836259400355842,\"name\":\"admin\",\"isAdmin\":0}]', '392', '0:0:0:0:0:0:0:1', '2020-08-28 10:23:54');
INSERT INTO `sys_log` VALUES ('220', 'admin', '修改用户', 'com.cimevue.cloud.terminal.modules.tenant.TenantUserController.update()', '[{\"userId\":1297836412240793601,\"username\":\"admin\",\"password\":\"7bd08cbec23889c570fae76f2780d1423bad685e30e0227367872f78f83a8fa6\",\"salt\":\"a2tGluXEEMdAGvsoy8wC\",\"email\":\"admin@admin.com\",\"mobile\":\"18888888888\",\"status\":1,\"roleIdList\":[1297836259727511553],\"createUserId\":1,\"tenantId\":1297836259400355842,\"name\":\"admin\",\"isAdmin\":0}]', '283', '0:0:0:0:0:0:0:1', '2020-09-01 09:39:26');

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父菜单ID，一级菜单为0',
  `name` varchar(50) DEFAULT NULL COMMENT '菜单名称',
  `url` varchar(200) DEFAULT NULL COMMENT '菜单URL',
  `perms` varchar(500) DEFAULT NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` int(11) DEFAULT NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(50) DEFAULT NULL COMMENT '菜单图标',
  `order_num` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COMMENT='菜单管理';

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '0', '系统管理中心', null, null, '0', 'system', '100');
INSERT INTO `sys_menu` VALUES ('2', '1', '管理员列表', 'sys/user', null, '1', 'admin', '1');
INSERT INTO `sys_menu` VALUES ('3', '1', '角色管理', 'sys/role', null, '1', 'role', '2');
INSERT INTO `sys_menu` VALUES ('4', '1', '菜单管理', 'sys/menu', null, '1', 'menu', '3');
INSERT INTO `sys_menu` VALUES ('5', '1', 'SQL监控', 'http://localhost:8080/renren-fast/druid/sql.html', null, '1', 'sql', '4');
INSERT INTO `sys_menu` VALUES ('15', '2', '查看', null, 'sys:user:list,sys:user:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('16', '2', '新增', null, 'sys:user:save,sys:role:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('17', '2', '修改', null, 'sys:user:update,sys:role:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('18', '2', '删除', null, 'sys:user:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('19', '3', '查看', null, 'sys:role:list,sys:role:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('20', '3', '新增', null, 'sys:role:save,sys:menu:list', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('21', '3', '修改', null, 'sys:role:update,sys:menu:list', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('22', '3', '删除', null, 'sys:role:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('23', '4', '查看', null, 'sys:menu:list,sys:menu:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('24', '4', '新增', null, 'sys:menu:save,sys:menu:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('25', '4', '修改', null, 'sys:menu:update,sys:menu:select', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('26', '4', '删除', null, 'sys:menu:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('27', '1', '参数管理', 'sys/config', 'sys:config:list,sys:config:info,sys:config:save,sys:config:update,sys:config:delete', '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('29', '1', '系统日志', 'sys/log', 'sys:log:list', '1', 'log', '7');
INSERT INTO `sys_menu` VALUES ('30', '1', '文件上传', 'oss/oss', 'sys:oss:all', '1', 'oss', '6');
INSERT INTO `sys_menu` VALUES ('31', '36', '租户管理', 'tenant/tenant', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('32', '31', '查看', null, 'tenant:tenant:list,tenant:tenant:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('33', '31', '新增', null, 'tenant:tenant:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('34', '31', '修改', null, 'tenant:tenant:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('35', '31', '删除', null, 'tenant:tenant:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('36', '0', '租户管理中心', null, null, '0', 'shouye', '0');
INSERT INTO `sys_menu` VALUES ('42', '1', '区域管理', 'sys/area', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('43', '42', '查看', null, 'sys:area:list,sys:area:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('44', '42', '新增', null, 'sys:area:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('45', '42', '修改', null, 'sys:area:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('46', '42', '删除', null, 'sys:area:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('47', '31', '查看管理员', null, 'tenant:admin:info', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('48', '31', '新增管理员', null, 'tenant:admin:save', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('49', '31', '修改管理员', '', 'tenant:admin:update', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('50', '31', '删除管理员', '', 'tenant:admin:delete', '2', null, '0');
INSERT INTO `sys_menu` VALUES ('51', '0', '应用管理中心', null, null, '0', 'zonghe', '20');
INSERT INTO `sys_menu` VALUES ('57', '51', '云APP', 'app/wapp', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('58', '57', '查看', null, 'sys:wapp:list,sys:wapp:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('59', '57', '新增', null, 'sys:wapp:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('60', '57', '修改', null, 'sys:wapp:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('61', '57', '删除', null, 'sys:wapp:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('62', '1', '字典管理', 'sys/dict', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('63', '62', '查看', null, 'sys:dict:list,sys:dict:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('64', '62', '新增', null, 'sys:dict:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('65', '62', '修改', null, 'sys:dict:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('66', '62', '删除', null, 'sys:dict:delete', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('67', '51', '云设备', 'tenant/device', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('68', '67', '查看', null, 'tenant:device:list,tenant:device:info', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('69', '67', '新增', null, 'tenant:device:save', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('70', '67', '修改', null, 'tenant:device:update', '2', null, '6');
INSERT INTO `sys_menu` VALUES ('71', '67', '删除', '', 'tenant:device:delete', '2', '', '6');
INSERT INTO `sys_menu` VALUES ('72', '51', 'APP', 'app/app', '', '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('73', '72', '查看', '', 'sys:app:list,sys:app:info', '2', '', '6');
INSERT INTO `sys_menu` VALUES ('74', '72', '新增', '', 'sys:app:save', '2', '', '6');
INSERT INTO `sys_menu` VALUES ('75', '72', '修改', '', 'sys:app:update', '2', '', '6');
INSERT INTO `sys_menu` VALUES ('76', '72', '删除', '', 'sys:app:delete', '2', '', '6');
INSERT INTO `sys_menu` VALUES ('77', '51', '云数据', 'app/clouddata', null, '1', 'config', '6');
INSERT INTO `sys_menu` VALUES ('78', '0', '统计分析', null, null, '0', 'tubiao', '101');
INSERT INTO `sys_menu` VALUES ('79', '78', '抓拍分析', 'statistics/compare', null, '1', null, '0');
INSERT INTO `sys_menu` VALUES ('80', '0', '配置中心', null, null, '0', 'system', '30');
INSERT INTO `sys_menu` VALUES ('81', '80', '语音配置', 'app/voice', 'app:voice:list,app:voice:info,app:voice:save,app:voice:delete,app:voice:update', '1', 'shezhi', '1');
INSERT INTO `sys_menu` VALUES ('82', '80', '方案配置', 'app/programme-setting', 'app:scheme:list,app:scheme:info,app:scheme:queryVoiceList,app:scheme:save,app:scheme:update,app:scheme:delete', '1', 'zonghe', '2');
INSERT INTO `sys_menu` VALUES ('83', '80', '通行方式配置', 'app/pass-type', 'app:accessmode:list,app:accessmode:info,app:accessmode:save,app:accessmode:update,app:accessmode:delete,app:accessmode:queryAllPassMode', '1', 'log', '3');
INSERT INTO `sys_menu` VALUES ('84', '80', '屏保方案管理', 'app/doorguardscreen', 'app:doorguarscreen:list,app:doorguarscreen:info,app:doorguarscreen:save,app:doorguarscreen:update,app:doorguarscreen:delete', '1', 'zonghe', '5');
INSERT INTO `sys_menu` VALUES ('85', '80', '屏保库管理', 'app/doorguard-screen-material', 'app:doorguarpicture:list,app:doorguarpicture:info,app:doorguarpicture:save,app:doorguarpicture:update,app:doorguarpicture:delete', '1', 'zhedie', '6');

-- ----------------------------
-- Table structure for sys_oss
-- ----------------------------
DROP TABLE IF EXISTS `sys_oss`;
CREATE TABLE `sys_oss` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL COMMENT 'URL地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件上传';

-- ----------------------------
-- Records of sys_oss
-- ----------------------------

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色';

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', '管理员', null, '1', '2018-10-26 16:13:03');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `menu_id` bigint(20) DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8 COMMENT='角色与菜单对应关系';

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES ('88', '1', '1');
INSERT INTO `sys_role_menu` VALUES ('89', '1', '2');
INSERT INTO `sys_role_menu` VALUES ('90', '1', '15');
INSERT INTO `sys_role_menu` VALUES ('91', '1', '16');
INSERT INTO `sys_role_menu` VALUES ('92', '1', '17');
INSERT INTO `sys_role_menu` VALUES ('93', '1', '18');
INSERT INTO `sys_role_menu` VALUES ('94', '1', '3');
INSERT INTO `sys_role_menu` VALUES ('95', '1', '19');
INSERT INTO `sys_role_menu` VALUES ('96', '1', '20');
INSERT INTO `sys_role_menu` VALUES ('97', '1', '21');
INSERT INTO `sys_role_menu` VALUES ('98', '1', '22');
INSERT INTO `sys_role_menu` VALUES ('99', '1', '4');
INSERT INTO `sys_role_menu` VALUES ('100', '1', '23');
INSERT INTO `sys_role_menu` VALUES ('101', '1', '24');
INSERT INTO `sys_role_menu` VALUES ('102', '1', '25');
INSERT INTO `sys_role_menu` VALUES ('103', '1', '26');
INSERT INTO `sys_role_menu` VALUES ('104', '1', '5');
INSERT INTO `sys_role_menu` VALUES ('105', '1', '27');
INSERT INTO `sys_role_menu` VALUES ('106', '1', '29');
INSERT INTO `sys_role_menu` VALUES ('107', '1', '30');
INSERT INTO `sys_role_menu` VALUES ('108', '1', '42');
INSERT INTO `sys_role_menu` VALUES ('109', '1', '43');
INSERT INTO `sys_role_menu` VALUES ('110', '1', '44');
INSERT INTO `sys_role_menu` VALUES ('111', '1', '45');
INSERT INTO `sys_role_menu` VALUES ('112', '1', '46');
INSERT INTO `sys_role_menu` VALUES ('113', '1', '62');
INSERT INTO `sys_role_menu` VALUES ('114', '1', '63');
INSERT INTO `sys_role_menu` VALUES ('115', '1', '64');
INSERT INTO `sys_role_menu` VALUES ('116', '1', '65');
INSERT INTO `sys_role_menu` VALUES ('117', '1', '66');
INSERT INTO `sys_role_menu` VALUES ('118', '1', '36');
INSERT INTO `sys_role_menu` VALUES ('119', '1', '31');
INSERT INTO `sys_role_menu` VALUES ('120', '1', '32');
INSERT INTO `sys_role_menu` VALUES ('121', '1', '33');
INSERT INTO `sys_role_menu` VALUES ('122', '1', '34');
INSERT INTO `sys_role_menu` VALUES ('123', '1', '35');
INSERT INTO `sys_role_menu` VALUES ('124', '1', '47');
INSERT INTO `sys_role_menu` VALUES ('125', '1', '48');
INSERT INTO `sys_role_menu` VALUES ('126', '1', '49');
INSERT INTO `sys_role_menu` VALUES ('127', '1', '50');
INSERT INTO `sys_role_menu` VALUES ('128', '1', '51');
INSERT INTO `sys_role_menu` VALUES ('129', '1', '57');
INSERT INTO `sys_role_menu` VALUES ('130', '1', '58');
INSERT INTO `sys_role_menu` VALUES ('131', '1', '59');
INSERT INTO `sys_role_menu` VALUES ('132', '1', '60');
INSERT INTO `sys_role_menu` VALUES ('133', '1', '61');
INSERT INTO `sys_role_menu` VALUES ('134', '1', '67');
INSERT INTO `sys_role_menu` VALUES ('135', '1', '68');
INSERT INTO `sys_role_menu` VALUES ('136', '1', '69');
INSERT INTO `sys_role_menu` VALUES ('137', '1', '70');
INSERT INTO `sys_role_menu` VALUES ('138', '1', '71');
INSERT INTO `sys_role_menu` VALUES ('139', '1', '72');
INSERT INTO `sys_role_menu` VALUES ('140', '1', '73');
INSERT INTO `sys_role_menu` VALUES ('141', '1', '74');
INSERT INTO `sys_role_menu` VALUES ('142', '1', '75');
INSERT INTO `sys_role_menu` VALUES ('143', '1', '76');
INSERT INTO `sys_role_menu` VALUES ('144', '1', '-666666');
INSERT INTO `sys_role_menu` VALUES ('145', '3', '2');
INSERT INTO `sys_role_menu` VALUES ('146', '3', '15');
INSERT INTO `sys_role_menu` VALUES ('147', '3', '16');
INSERT INTO `sys_role_menu` VALUES ('148', '3', '17');
INSERT INTO `sys_role_menu` VALUES ('149', '3', '18');
INSERT INTO `sys_role_menu` VALUES ('150', '3', '3');
INSERT INTO `sys_role_menu` VALUES ('151', '3', '19');
INSERT INTO `sys_role_menu` VALUES ('152', '3', '20');
INSERT INTO `sys_role_menu` VALUES ('153', '3', '21');
INSERT INTO `sys_role_menu` VALUES ('154', '3', '22');
INSERT INTO `sys_role_menu` VALUES ('155', '3', '-666666');
INSERT INTO `sys_role_menu` VALUES ('156', '3', '1');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) DEFAULT NULL COMMENT '密码',
  `salt` varchar(20) DEFAULT NULL COMMENT '盐',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统用户';

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', 'admin', '2c8578de8fc31aaeca566f69f42c0e435340ac274974693c405c18a720de9c0d', 'YzcmCZNvbXocrsz9dm8e', 'root@renren.io', '13612345678', '1', '1', '2016-11-11 11:11:11');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户与角色对应关系';

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES ('2', '3', '1');
INSERT INTO `sys_user_role` VALUES ('3', '2', '1');
INSERT INTO `sys_user_role` VALUES ('4', '4', '1');

-- ----------------------------
-- Table structure for sys_user_token
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_token`;
CREATE TABLE `sys_user_token` (
  `user_id` bigint(20) NOT NULL,
  `token` varchar(100) NOT NULL COMMENT 'token',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `token` (`token`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统用户Token';

-- ----------------------------
-- Records of sys_user_token
-- ----------------------------
INSERT INTO `sys_user_token` VALUES ('1', '30db5eb4352ebdcdbe452459c6b63a4f', '2020-09-04 22:08:24', '2020-09-04 10:08:24');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `mobile` varchar(20) NOT NULL COMMENT '手机号',
  `password` varchar(64) DEFAULT NULL COMMENT '密码',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户';

-- ----------------------------
-- Records of tb_user
-- ----------------------------
