#!/bin/bash

echo "init mysql begin..."

docker cp ./sql mysql:/tmp

for item in `ls ./sql`; do
    echo "import sql $item"
    docker exec mysql //bin/bash -c "mysql -uroot -pcimevue@1234 < /tmp/sql/$item"
done

echo "init mysql end"
