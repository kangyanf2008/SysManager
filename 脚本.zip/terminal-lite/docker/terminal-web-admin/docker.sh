#!/bin/bash

export container_name=terminal-web-admin
export image_name=$container_name

function start() {
    docker run -d --restart always --name=$container_name \
        -p 8032:8032 \
        -v /$PWD/config:/config \
        --env LC_ALL=zh_CN.UTF-8 \
		-v /$PWD/../../data/app:/app \
		-v /$PWD/../../data/video:/video \
		-v /$PWD/../../data/image:/data/image \
        $image_name
}

function stop(){
    docker stop $container_name 2>/dev/null
    docker rm -vf $container_name 2>/dev/null
}

function enter() {
    docker exec -it $container_name bash
}

function log() {
    docker logs -f $container_name
}

function help() {
    echo "Usage: $0 start/stop/restart/enter/log"
}

case $1 in
    "start")
        start
        ;;
    "stop")
        stop
        ;;
    "restart")
        stop
        start
        ;;
    "enter")
        enter
        ;;
    "log")
        log
        ;;
    *)
        help
        ;;
esac
