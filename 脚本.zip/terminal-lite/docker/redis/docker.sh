#!/bin/bash

export container_name=redis

function start(){
    docker run -d --restart always --name=$container_name \
    -p 6379:6379 \
    -v /$PWD/../../data/docker/redis:/data \
    -v /$PWD/redis.conf:/config/redis/redis.conf \
    redis:3.2.9 \
    redis-server //config/redis/redis.conf
}

function stop(){
    docker stop $container_name 2>/dev/null
    docker rm -vf $container_name 2>/dev/null
}

function enter() {
    docker exec -it $container_name bash
}

function log() {
    docker logs -f $container_name
}

function help() {
    echo "Usage: $0 start/stop/restart/enter/log"
}

case $1 in
    "start")
        start
        ;;
    "stop")
        stop
        ;;
    "restart")
        stop
        start
        ;;
    "enter")
        enter
        ;;
    "log")
        log
        ;;
    *)
        help
        ;;
esac