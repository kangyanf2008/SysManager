#!/bin/bash

export container_name=emqx

function start(){
    docker run -d --restart=always --name $container_name \
    -p 1883:1883 -p 8083:8083 -p 8883:8883 -p 8084:8084 -p 18083:18083 \
    -e EMQX_LOADED_PLUGINS=emqx_management,emqx_rule_engine,emqx_recon,emqx_retainer,emqx_dashboard,emqx_auth_username \
    -e EMQX_AUTH__USER__1__USERNAME=admin \
    -e EMQX_AUTH__USER__1__PASSWORD=Pensees@1234 \
    emqx/emqx:v3.1.0
#    docker run -d --restart=always --name $container_name -p 1883:1883 -p 8083:8083 -p 8883:8883 -p 8084:8084 -p 18083:18083 emqx/emqx:v3.1.0
}

function stop(){
    docker stop $container_name 2>/dev/null
    docker rm -vf $container_name 2>/dev/null
}

function enter() {
    docker exec -it $container_name bash
}

function log() {
    docker logs -f $container_name
}

function help() {
    echo "Usage: $0 start/stop/restart/enter/log"
}

case $1 in
    "start")
        start
        ;;
    "stop")
        stop
        ;;
    "restart")
        stop
        start
        ;;
    "enter")
        enter
        ;;
    "log")
        log
        ;;
    *)
        help
        ;;
esac
