#!/bin/bash

export container_name=mongo

function start(){
    docker run -d --restart always --name=$container_name \
    -p 27017:27017 \
    -v /$PWD/mongod.conf:/etc/mongod.conf \
	-v mongo-single:/data/db \
    mongo:3.4.5 \
    mongod -f //etc/mongod.conf
}

function stop(){
    docker stop $container_name 2>/dev/null
    docker rm -vf $container_name 2>/dev/null
}

function enter() {
    docker exec -it $container_name bash
}

function log() {
    docker logs -f $container_name
}

function help() {
    echo "Usage: $0 start/stop/restart/enter/log"
}

function init() {
    docker cp $PWD/mongo.js mongo:/tmp
    docker exec mongo /bin/bash -c "mongo < /tmp/mongo.js"
}

case $1 in
    "start")
        start
        ;;
    "stop")
        stop
        ;;
    "restart")
        stop
        start
        ;;
    "enter")
        enter
        ;;
    "log")
        log
        ;;
    "init")
        init
        ;;
    *)
        help
        ;;
esac
