#!/bin/bash

export container_name=nginx_terminal

function start(){
    docker run -d --restart always --name=$container_name \
    -p 80:80 \
    -p 443:443 \
    -p 8899:8899 \
    -p 8810:8810 \
    -p 8012:8012 \
    -p 18123:18123 \
    -p 18122:18122 \
	-v /$PWD/../../data/image:/image \
	-v /$PWD/../../data/app:/app \
    -v /$PWD/../../data/video:/video \
    -v /$PWD/../../data/static:/wx/static \
    -v /$PWD/../../data/export/file:/export/file \
    -v /$PWD/../../docker/nginx/ssl:/ssl \
    -v /$PWD/../../docker/nginx/nginx:/etc/nginx \
    -v /$PWD/../../docker/nginx/logs:/var/log/nginx \
    -v /$PWD/../../docker/nginx/html:/usr/share/nginx/html \
    --add-host=master.cimevue.me:192.168.99.100 \
    nginx:1.12.0
}

function stop(){
    docker stop $container_name 2>/dev/null
    docker rm -vf $container_name 2>/dev/null
}

function reload() {
    docker exec $container_name nginx -s reload
}

function enter() {
    docker exec -it $container_name bash
}

function log() {
    docker logs -f $container_name
}

function help() {
    echo "Usage: $0 start/stop/restart/enter/log/reload"
}

case $1 in
    "start")
        start
        ;;
    "stop")
        stop
        ;;
    "restart")
        stop
        start
        ;;
    "reload")
        reload
        ;;
    "enter")
        enter
        ;;
    "log")
        log
        ;;
    *)
        help
        ;;
esac
